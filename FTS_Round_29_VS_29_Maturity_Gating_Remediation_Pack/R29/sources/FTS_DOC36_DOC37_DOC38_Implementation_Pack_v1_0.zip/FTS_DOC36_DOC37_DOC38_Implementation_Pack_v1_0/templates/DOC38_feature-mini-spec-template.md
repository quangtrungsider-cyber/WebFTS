# Feature Mini-Spec Template — VATM FTS

- feature_id:
- slice_id:
- size: XS|S|M|L|XL
- status: DRAFT|READY_FOR_CODE|BLOCKED|DONE_WITH_EVIDENCE
- boundary: Decision-support / Non-operational

## 1. Scope / out-of-scope
## 2. Source binding: DOC-35/DOC-39/DOC-37 rows
## 3. API/event/data/state/rule inventory
## 4. Data classification and security archetype
## 5. Implementation order
## 6. Test inventory and expected evidence
## 7. RUNTIME-GAPS / SPEC-GAPS / CONFLICTS
## 8. DoR / DoD
