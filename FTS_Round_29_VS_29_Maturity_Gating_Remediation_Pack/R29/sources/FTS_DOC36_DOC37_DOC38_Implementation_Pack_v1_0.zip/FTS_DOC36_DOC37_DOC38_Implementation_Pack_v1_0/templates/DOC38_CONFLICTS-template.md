# CONFLICTS.md

- conflict_id: CONF-YYYYMMDD-NNN
  detected_by: <name/bot>
  date_utc: YYYY-MM-DDTHH:mm:ssZ
  severity: P0|P1|P2|P3
  concern: api|event|data|lifecycle|business-rule|calculation|security|time|deterministic-math|ui|ops|runtime
  sources_in_conflict:
    - <doc/artifact/path + version>
    - <doc/artifact/path + version>
  authority_winner: H0|H1|H2|H3|H4|H5|H6|H7|H8
  decision: <what code/docs must follow>
  impacted_feature: <feature>
  impacted_paths: []
  safe_default: <block/mask/read-only/DETECT_ONLY/RUNTIME-GAP/etc.>
  owner: <role>
  due_date_utc: YYYY-MM-DD
  status: open|resolved|accepted-by-hierarchy
  evidence: <PR/test/log/link>
