# SPEC-GAPS.md

- gap_id: SG-YYYYMMDD-NNN
  domain: runtime|data|BADA|separation|ASM-App|workload|classification|PoC|airgap|UI
  description:
  searched_sources:
    - DOC-xx
    - artifact/path
  safe_default:
  authority_needed:
  impacted_slices: []
  status: open|resolved|deferred
  evidence:
