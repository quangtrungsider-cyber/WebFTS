# RUNTIME-GAP Template

- id: RG-YYYYMMDD-NNN
- slice: VS-xx
- missing_artifact:
- source_doc:
- blocked_claim:
- safe_default: block|disabled|test-harness-only|treat-as-L4|DETECT_ONLY
- owner:
- due_date:
- evidence_needed:
  - validation log
  - contract/schema/state/rule test
  - runtime smoke
- status: open

## Notes
Do not claim done/runtime-ready while this gap is open.
