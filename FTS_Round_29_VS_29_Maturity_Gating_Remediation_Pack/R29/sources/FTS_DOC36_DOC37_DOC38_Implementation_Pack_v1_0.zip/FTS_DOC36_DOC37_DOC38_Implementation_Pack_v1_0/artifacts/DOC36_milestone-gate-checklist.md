# DOC-36 Milestone Gate Checklist

| Phase | Khối build | Exit criteria |
| --- | --- | --- |
| 0 | Docs/runtime readiness | DOC-35/DOC-39/DOC-37/DOC-38 present, SPEC-GAPS/CONFLICTS ready, local setup log created. |
| 1 | Platform skeleton + guardrails CI | Docs lint, OpenAPI/AsyncAPI/schema validation, Semgrep/static scanners, Makefile targets. |
| 2 | Data foundation M-10 | DDL/Data Dictionary, migration dry-run, seed/reference manifest, object manifest smoke. |
| 3 | Scenario Manager M-02 | Create/validate/freeze/run state machine + API + tests pass. |
| 4 | Data import/QA M-11/M-10 | Direct-to-storage upload, import job, QA report, quarantine, manifest. |
| 5 | Performance/weather/trajectory M-03/M-04/M-01 | Deterministic trajectory fixture, performance fallback limitation, weather sample tests. |
| 6 | Separation/CD&R/ASM-App M-05 | DETECT_ONLY trước, RECOMMEND_ONLY, AUTO_APPLY_SIMULATED chỉ sau guard pass. |
| 7 | Async orchestration/worker pool M-14 | REST 202, progress, cancel/resume, DLQ, scenario.run.completed single emission. |
| 8 | Workload/KPI/report M-07/M-09 | KPI with CI/limitation, report manifest, export schemas. |
| 9 | Replay/UI M-08/M-13 | Watermark, 2D/3D/4D replay, trace tooltip, UI smoke/perf evidence. |
| 10 | Security/export/audit M-12 | L1-L4, ABAC negative tests, masked export, sanitized support, hash-chain audit. |
| 11 | PoC/V&V/DevOps hardening M-15/M-14 | FAT/SAT/UAT/PoC pack, signed images/SBOM, observability, runbook. |
