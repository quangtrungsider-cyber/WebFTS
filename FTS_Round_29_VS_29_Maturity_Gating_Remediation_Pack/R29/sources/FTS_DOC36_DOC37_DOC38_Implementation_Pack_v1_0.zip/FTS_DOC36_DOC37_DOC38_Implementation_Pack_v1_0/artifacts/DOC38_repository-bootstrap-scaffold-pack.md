# DOC-38 Repository Bootstrap & Scaffold Pack v1.0

## 1. Mục đích
DOC-38 cung cấp cấu trúc repo, lệnh bootstrap, Makefile, compose profile, env schema và scaffold feature để một coder bắt đầu từ repo trống đến local smoke/evidence mà không cần hỏi thêm cấu trúc.

## 2. Bootstrap sequence
```bash
make doctor
cp .env.local.example .env.local
make env-validate ENV_FILE=.env.local
make bootstrap
make compose-up PROFILE=core
make migrate
make testdata-load PROFILE=local-dev
make smoke-local
make evidence-local
```

## 3. Repository tree
```text
fts/
├── README.md
├── Makefile
├── .env.local.example
├── env.schema.json
├── .pre-commit-config.yaml
├── ci/
│   └── pipeline.yaml
├── docs/
│   ├── 00-operating-rules/
│   ├── 01-business-context/
│   ├── 02-technical-decisions/
│   ├── 03-interface/
│   ├── 04-data/
│   ├── 05-business-rules/
│   ├── 06-security-privacy/
│   ├── 07-domain-engine/
│   ├── 08-frontend-ux/
│   ├── 09-testing/
│   ├── 10-devops-ops/
│   ├── 35-master-index/
│   ├── 36-implementation/
│   ├── 37-materialization/
│   └── 39-decisions/
├── contracts/
│   ├── openapi/
│   ├── asyncapi/
│   ├── jsonschema/
│   ├── arrow/
│   ├── icd/
│   └── worker/
├── apps/
│   └── web/
├── services/
│   ├── api/
│   ├── scenario/
│   ├── dataset/
│   ├── simulation-orchestrator/
│   ├── report/
│   └── audit/
├── engine/
│   ├── rust-core/
│   └── python-science/
├── packages/
│   ├── fts-time/
│   ├── fts-units/
│   ├── fts-problem-details/
│   ├── fts-observability/
│   ├── fts-authz/
│   └── fts-generated-clients/
├── db/
│   └── migrations/
├── state-machines/
├── fixtures/
│   ├── reference/
│   ├── local-dev/
│   ├── ci-smoke/
│   ├── simulation-regression/
│   ├── perf-5k/
│   └── poc-sealed/
├── tests/
│   ├── contract/
│   ├── integration/
│   ├── gherkin/
│   ├── simulation-regression/
│   ├── security/
│   ├── time/
│   └── ui-e2e/
├── ops/
│   ├── compose/
│   ├── helm/
│   ├── k8s/
│   ├── observability/
│   ├── airgap/
│   └── runbooks/
├── tools/
│   ├── dev/
│   ├── scaffold/
│   ├── docs/
│   ├── contracts/
│   ├── data/
│   ├── rules/
│   ├── security/
│   ├── testdata/
│   ├── smoke/
│   ├── evidence/
│   ├── release/
│   └── policy/
└── features/
    └── <feature-name>/
        ├── <feature-name>-mini-spec.md
        ├── TRACEABILITY.md
        ├── <feature-name>-test-matrix.md
        ├── <feature-name>-security-evidence.md
        ├── <feature-name>-release-evidence.md
        ├── <feature-name>-ai-review.md
        ├── <feature-name>-property-tests.md
        └── daily-wip-handoff.md

```

## 4. Makefile targets tối thiểu
doctor, env-validate, bootstrap, compose-up, compose-down, migrate, db-lint-destructive, testdata-compile, testdata-load, testdata-reset, testdata-verify, lint, contract-openapi, contract-asyncapi, test-contract, test-simulation-regression, test-invariants, test-determinism-multi-arch, test-ui-e2e, test-ui-gpu, security-scan, smoke-local, evidence-local, evidence-pack, airgap-bundle, airgap-verify, obs-validate, runbook-link-check, poc-dynamic-salt, scaffold-feature, reset-time

## 5. Docker Compose core services
- postgres / timescale: metadata, PostGIS/time-series trajectory.
- redpanda: local event bus.
- minio: object storage, claim-check, evidence bundle.
- keycloak: mock IdP/OIDC.
- vault-dev: local secret simulation only.
- otel-collector, prometheus, grafana: observability profile.
- api, worker: placeholder application services.

## 6. Feature scaffold command
```bash
make scaffold-feature NAME=scenario-freeze SIZE=M
```

It generates:
- features/<feature>/<feature>-mini-spec.md
- features/<feature>/TRACEABILITY.md
- features/<feature>/<feature>-test-matrix.md
- features/<feature>/<feature>-security-evidence.md
- features/<feature>/<feature>-release-evidence.md
- features/<feature>/<feature>-ai-review.md
- features/<feature>/<feature>-property-tests.md
- features/<feature>/daily-wip-handoff.md

## 7. Environment policy
`env.schema.json` enforces non-operational/no-writeback defaults for local and CI. Any non-local profile must replace `ChangeMe-*` values and must not commit `.env.local` or secrets.

## 8. AI-assisted coding rules
Use `DOC38_cursorrules_template.txt` as the baseline for `.cursorrules` or equivalent IDE policy. The rule is simple: do not hallucinate formulas/minima/security/legal behavior; create SPEC-GAP/CONFLICT instead.

## 9. Failure triage
If bootstrap/smoke fails, stop coding and create `failure-triage.md` with command, log, suspected layer, DOC-37 matrix row and recovery action. Do not patch environment ad hoc without updating `.env.example`, Makefile or DOC-37.
