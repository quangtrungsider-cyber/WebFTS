# Emergency Change Procedure

1. Declare emergency reason and affected service/data/security scope.
2. Assign incident/change commander.
3. Capture current state and evidence before change.
4. Apply minimal safe fix.
5. Verify and monitor.
6. Create retroactive CR and ADR if architecture/behavior changed.
7. Record hotfix debt and due date.
8. Conduct PIR and close debt.
