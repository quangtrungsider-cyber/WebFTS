# Spec Freeze Checklist

- RTM coverage report generated.
- Open CRs triaged and blockers identified.
- API/event/DDL/rule/oracle/design-token versions frozen.
- DOC-39 decision blockers reviewed.
- DOC-45 security exceptions reviewed.
- DOC-51 legal/procurement exceptions reviewed.
- Rollback plan and evidence pack ready.
- Freeze exception approvers named.
