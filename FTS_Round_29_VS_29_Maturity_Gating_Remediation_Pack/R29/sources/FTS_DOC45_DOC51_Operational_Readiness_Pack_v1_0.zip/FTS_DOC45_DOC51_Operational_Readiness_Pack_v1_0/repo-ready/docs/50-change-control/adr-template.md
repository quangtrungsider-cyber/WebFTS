# ADR-NNN: Title

## Status
Proposed / Accepted / Superseded / Rejected

## Context
What problem is being solved and which DOC/RTM rows are affected?

## Decision
What is the chosen decision?

## Alternatives considered
List options and why rejected.

## Consequences
Implementation, security, data, ops, legal, UX and testing consequences.

## Rollback / expiration
How can this decision be reversed? Is it temporary?

## Sign-off references
DOC-39/DOC-45/DOC-51 sign-off IDs if required.
