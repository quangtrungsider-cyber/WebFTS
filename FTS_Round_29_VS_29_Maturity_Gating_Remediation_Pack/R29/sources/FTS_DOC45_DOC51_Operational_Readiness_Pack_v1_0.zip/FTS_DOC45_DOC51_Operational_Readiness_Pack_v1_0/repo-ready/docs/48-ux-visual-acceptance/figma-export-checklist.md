# Figma Export Checklist

- Figma page and frame names match screen-contracts.csv.
- Exported frames are 1440x900 unless the screen contract states otherwise.
- Tokens are mapped to design-tokens.json names.
- Classification badges and non-operational watermark are visible in relevant screens.
- Empty/loading/error/permission-denied states are exported or covered in Storybook.
- Pixel baseline PNG/SVG is committed with design-token version and date.
- UX owner signs the visual acceptance ledger.
