# UX Visual Acceptance Checklist

1. Screen contract exists and maps to API/event/table/rule/test/evidence.
2. Token usage is consistent with design-tokens.json.
3. The screen renders bilingual labels without clipping critical text.
4. Classification and limitation banners are visible.
5. Keyboard focus and disabled/error states are visible.
6. Visual regression baseline exists and passes threshold.
7. User representative signs acceptance or records issue.
