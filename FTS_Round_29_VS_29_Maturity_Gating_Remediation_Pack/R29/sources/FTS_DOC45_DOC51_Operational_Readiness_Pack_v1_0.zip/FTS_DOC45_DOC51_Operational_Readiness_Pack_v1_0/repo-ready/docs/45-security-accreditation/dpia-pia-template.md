# PIA/DPIA Template for FTS Data Use

## 1. Case information
- Case ID:
- Data owner:
- System owner:
- Security owner:
- Legal owner:
- Environment: PoC / UAT / SAT / Production

## 2. Data inventory
List each dataset, source, classification, subject/sensitive data categories, retention and recipients.

## 3. Processing purpose
Explain why the data is needed and why synthetic/masked data is not sufficient.

## 4. Risk assessment
Identify privacy, sensitive aviation, national security, vendor exposure, retention and export risks.

## 5. Controls
Classification, minimization, masking, ABAC, audit, SIEM, support restrictions, deletion/retention, legal hold.

## 6. Decision
Approved / Approved with conditions / Rejected. Include sign-off table and expiry date.
