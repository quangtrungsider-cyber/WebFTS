# RTM Coverage Report

- Release ID:
- Generated at:
- RTM version/hash:
- Total requirements:
- Implemented:
- Tested:
- Evidence ready:
- Approved:
- Blocking gaps:

## Blocking gaps
List any GAP status item touching security, legal, data, safety, acceptance or environment.
