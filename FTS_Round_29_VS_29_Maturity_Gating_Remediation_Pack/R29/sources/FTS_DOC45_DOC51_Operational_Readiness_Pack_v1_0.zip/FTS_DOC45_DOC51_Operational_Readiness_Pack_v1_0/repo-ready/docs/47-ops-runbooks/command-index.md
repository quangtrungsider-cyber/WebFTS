# Ops Command Index

Commands are placeholders to be wired to the final repo Makefile/Helm tooling:

- `make release-verify`
- `make deploy ENV=poc VERSION=<digest>`
- `make rollback ENV=poc VERSION=<previous>`
- `make smoke ENV=poc`
- `make backup-now ENV=poc`
- `make restore-drill ENV=drill`
- `make airgap-bundle-verify BUNDLE=<path>`
- `make cve-db-update OFFLINE_BUNDLE=<path>`
- `make vault-rotation-check`
- `make siem-spool-replay-check`
- `make worker-checkpoint-audit RUN_ID=<id>`
