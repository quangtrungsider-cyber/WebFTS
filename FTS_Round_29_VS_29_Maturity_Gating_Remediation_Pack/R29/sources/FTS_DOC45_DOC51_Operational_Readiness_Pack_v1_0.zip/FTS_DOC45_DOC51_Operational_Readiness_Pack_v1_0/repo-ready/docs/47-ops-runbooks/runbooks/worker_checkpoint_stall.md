# Runbook: Worker checkpoint stall

## Trigger
Simulation worker makes no checkpoint progress

## Preconditions
- Operator has approved access and ticket/incident/change ID.
- Evidence folder is created.
- Stop conditions are understood.

## Procedure
1. Identify run/worker
2. Check queue depth and worker logs
3. Pause run if needed
4. Reassign from last checkpoint
5. Verify idempotency
6. Record limitation if output affected

## Verification / exit criteria
- run resumes or fails clean
- no duplicate outputs
- evidence log attached

## Escalation
Escalate to Ops Lead, Security Owner, System Owner and VATM Authority when stop condition, data integrity, security, audit or legal risk is detected.

## Evidence to attach
- command log
- screenshots or dashboard snapshots where permitted
- manifest/hash evidence
- incident/change ID
- closure note
