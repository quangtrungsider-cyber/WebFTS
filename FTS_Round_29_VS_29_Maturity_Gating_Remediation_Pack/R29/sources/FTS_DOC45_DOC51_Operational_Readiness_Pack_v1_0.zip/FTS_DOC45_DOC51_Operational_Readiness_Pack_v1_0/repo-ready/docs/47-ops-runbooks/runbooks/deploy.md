# Runbook: Deploy release to PoC/Production

## Trigger
New approved release artifact is ready

## Preconditions
- Operator has approved access and ticket/incident/change ID.
- Evidence folder is created.
- Stop conditions are understood.

## Procedure
1. Confirm release freeze window and approvals
2. Verify image signatures and SBOM
3. Run database migration dry-run
4. Apply Helm/Kustomize release
5. Run smoke tests
6. Monitor SLO dashboard for observation window
7. Publish deployment evidence

## Verification / exit criteria
- CI green
- healthz/readyz ok
- smoke tests pass
- no critical alerts

## Escalation
Escalate to Ops Lead, Security Owner, System Owner and VATM Authority when stop condition, data integrity, security, audit or legal risk is detected.

## Evidence to attach
- command log
- screenshots or dashboard snapshots where permitted
- manifest/hash evidence
- incident/change ID
- closure note
