# Runbook: Disaster recovery drill

## Trigger
Scheduled DR exercise

## Preconditions
- Operator has approved access and ticket/incident/change ID.
- Evidence folder is created.
- Stop conditions are understood.

## Procedure
1. Declare drill scope
2. Freeze production changes if required
3. Restore to DR environment
4. Run smoke/oracle/security tests
5. Measure RPO/RTO
6. Issue action plan

## Verification / exit criteria
- RPO/RTO met or exception logged
- evidence package signed

## Escalation
Escalate to Ops Lead, Security Owner, System Owner and VATM Authority when stop condition, data integrity, security, audit or legal risk is detected.

## Evidence to attach
- command log
- screenshots or dashboard snapshots where permitted
- manifest/hash evidence
- incident/change ID
- closure note
