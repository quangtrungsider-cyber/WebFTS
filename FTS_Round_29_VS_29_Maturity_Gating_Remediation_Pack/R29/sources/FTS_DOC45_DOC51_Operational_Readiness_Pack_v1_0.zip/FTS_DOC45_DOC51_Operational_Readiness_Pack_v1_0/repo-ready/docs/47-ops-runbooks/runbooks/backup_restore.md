# Runbook: Backup and restore drill

## Trigger
Quarterly drill or pre-SAT gate

## Preconditions
- Operator has approved access and ticket/incident/change ID.
- Evidence folder is created.
- Stop conditions are understood.

## Procedure
1. Select restore target
2. Verify backup manifest and object lock
3. Restore DB/object store/Vault in isolated environment
4. Run hash/oracle checks
5. Record RPO/RTO measured
6. Close drill issues

## Verification / exit criteria
- restore completed
- hash verified
- RPO/RTO recorded

## Escalation
Escalate to Ops Lead, Security Owner, System Owner and VATM Authority when stop condition, data integrity, security, audit or legal risk is detected.

## Evidence to attach
- command log
- screenshots or dashboard snapshots where permitted
- manifest/hash evidence
- incident/change ID
- closure note
