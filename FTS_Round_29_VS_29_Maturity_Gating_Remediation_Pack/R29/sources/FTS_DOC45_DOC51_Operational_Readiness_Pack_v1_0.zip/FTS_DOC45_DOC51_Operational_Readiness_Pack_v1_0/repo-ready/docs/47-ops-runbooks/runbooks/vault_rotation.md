# Runbook: Vault/KMS secret/key rotation

## Trigger
Scheduled or incident-driven rotation

## Preconditions
- Operator has approved access and ticket/incident/change ID.
- Evidence folder is created.
- Stop conditions are understood.

## Procedure
1. Announce rotation window
2. Snapshot Vault metadata
3. Rotate transit keys/secrets
4. Restart dependent pods if required
5. Verify decrypt/sign operations
6. Archive rotation evidence

## Verification / exit criteria
- services healthy
- old secrets revoked
- evidence captured

## Escalation
Escalate to Ops Lead, Security Owner, System Owner and VATM Authority when stop condition, data integrity, security, audit or legal risk is detected.

## Evidence to attach
- command log
- screenshots or dashboard snapshots where permitted
- manifest/hash evidence
- incident/change ID
- closure note
