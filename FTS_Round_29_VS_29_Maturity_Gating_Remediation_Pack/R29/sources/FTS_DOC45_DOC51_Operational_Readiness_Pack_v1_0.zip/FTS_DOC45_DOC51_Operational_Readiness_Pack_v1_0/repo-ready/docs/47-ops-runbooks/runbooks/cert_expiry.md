# Runbook: Certificate expiry or rotation

## Trigger
TLS/PKI certificate near expiry or compromised

## Preconditions
- Operator has approved access and ticket/incident/change ID.
- Evidence folder is created.
- Stop conditions are understood.

## Procedure
1. Inventory affected certs
2. Generate/approve new certs
3. Deploy to ingress/services
4. Restart safely
5. Verify TLS chain and clients
6. Revoke old certs

## Verification / exit criteria
- TLS check pass
- old cert revoked

## Escalation
Escalate to Ops Lead, Security Owner, System Owner and VATM Authority when stop condition, data integrity, security, audit or legal risk is detected.

## Evidence to attach
- command log
- screenshots or dashboard snapshots where permitted
- manifest/hash evidence
- incident/change ID
- closure note
