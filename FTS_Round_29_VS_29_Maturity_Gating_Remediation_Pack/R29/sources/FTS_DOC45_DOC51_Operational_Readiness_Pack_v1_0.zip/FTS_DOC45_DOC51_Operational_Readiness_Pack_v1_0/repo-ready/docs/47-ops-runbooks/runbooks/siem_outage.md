# Runbook: SIEM outage spool/replay

## Trigger
SIEM unavailable or forwarding failure

## Preconditions
- Operator has approved access and ticket/incident/change ID.
- Evidence folder is created.
- Stop conditions are understood.

## Procedure
1. Confirm outage
2. Enable/verify local spool
3. Monitor spool size
4. Notify SOC/security
5. Replay events after recovery
6. Verify no event loss

## Verification / exit criteria
- spool hash valid
- replay count matches
- alert closed

## Escalation
Escalate to Ops Lead, Security Owner, System Owner and VATM Authority when stop condition, data integrity, security, audit or legal risk is detected.

## Evidence to attach
- command log
- screenshots or dashboard snapshots where permitted
- manifest/hash evidence
- incident/change ID
- closure note
