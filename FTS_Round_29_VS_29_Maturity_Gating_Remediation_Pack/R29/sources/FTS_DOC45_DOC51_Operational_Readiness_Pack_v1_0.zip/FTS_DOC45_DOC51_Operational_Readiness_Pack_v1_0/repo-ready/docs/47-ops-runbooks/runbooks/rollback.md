# Runbook: Rollback failed release

## Trigger
Smoke test or observation window fails

## Preconditions
- Operator has approved access and ticket/incident/change ID.
- Evidence folder is created.
- Stop conditions are understood.

## Procedure
1. Declare stop condition
2. Freeze new changes
3. Capture evidence
4. Rollback Helm release or restore previous image digests
5. Run schema compatibility check
6. Run smoke tests
7. Open PIR issue

## Verification / exit criteria
- previous version healthy
- data integrity check ok
- PIR ticket created

## Escalation
Escalate to Ops Lead, Security Owner, System Owner and VATM Authority when stop condition, data integrity, security, audit or legal risk is detected.

## Evidence to attach
- command log
- screenshots or dashboard snapshots where permitted
- manifest/hash evidence
- incident/change ID
- closure note
