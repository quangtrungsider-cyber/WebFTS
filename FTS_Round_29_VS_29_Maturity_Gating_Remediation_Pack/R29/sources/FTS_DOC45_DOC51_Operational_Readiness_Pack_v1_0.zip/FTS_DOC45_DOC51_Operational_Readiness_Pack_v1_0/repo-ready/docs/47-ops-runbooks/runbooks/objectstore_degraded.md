# Runbook: Object store degraded

## Trigger
MinIO/S3 unavailable or object lock failure

## Preconditions
- Operator has approved access and ticket/incident/change ID.
- Evidence folder is created.
- Stop conditions are understood.

## Procedure
1. Pause export/report jobs
2. Check cluster quorum and disks
3. Fail over if configured
4. Verify object lock and manifest
5. Resume jobs

## Verification / exit criteria
- no lost artifact
- manifest/hash pass

## Escalation
Escalate to Ops Lead, Security Owner, System Owner and VATM Authority when stop condition, data integrity, security, audit or legal risk is detected.

## Evidence to attach
- command log
- screenshots or dashboard snapshots where permitted
- manifest/hash evidence
- incident/change ID
- closure note
