# Runbook: CVE DB update and scan

## Trigger
Scheduled vulnerability data refresh

## Preconditions
- Operator has approved access and ticket/incident/change ID.
- Evidence folder is created.
- Stop conditions are understood.

## Procedure
1. Import signed CVE feed
2. Update scanner DB
3. Run image/dependency scans
4. Triage Critical/High findings
5. Open exceptions if needed

## Verification / exit criteria
- scanner timestamp updated
- critical/high disposition exists

## Escalation
Escalate to Ops Lead, Security Owner, System Owner and VATM Authority when stop condition, data integrity, security, audit or legal risk is detected.

## Evidence to attach
- command log
- screenshots or dashboard snapshots where permitted
- manifest/hash evidence
- incident/change ID
- closure note
