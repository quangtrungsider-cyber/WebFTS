# Runbook: Air-gap signed update

## Trigger
Patch/release in air-gapped environment

## Preconditions
- Operator has approved access and ticket/incident/change ID.
- Evidence folder is created.
- Stop conditions are understood.

## Procedure
1. Prepare signed artifact bundle
2. Mirror images/CVE DB/SBOM offline
3. Verify signatures and hashes
4. Update registry mirror
5. Deploy update
6. Run smoke and security checks

## Verification / exit criteria
- no public pull
- signature verified
- smoke pass

## Escalation
Escalate to Ops Lead, Security Owner, System Owner and VATM Authority when stop condition, data integrity, security, audit or legal risk is detected.

## Evidence to attach
- command log
- screenshots or dashboard snapshots where permitted
- manifest/hash evidence
- incident/change ID
- closure note
