# Runbook: Keycloak/IdP outage

## Trigger
Login/token validation failing

## Preconditions
- Operator has approved access and ticket/incident/change ID.
- Evidence folder is created.
- Stop conditions are understood.

## Procedure
1. Confirm IdP health
2. Switch to cached token validation only if policy allows
3. Block privileged changes if step-up unavailable
4. Notify users
5. Restore IdP
6. Review audit

## Verification / exit criteria
- auth restored
- no unauthorized bypass
- incident closed

## Escalation
Escalate to Ops Lead, Security Owner, System Owner and VATM Authority when stop condition, data integrity, security, audit or legal risk is detected.

## Evidence to attach
- command log
- screenshots or dashboard snapshots where permitted
- manifest/hash evidence
- incident/change ID
- closure note
