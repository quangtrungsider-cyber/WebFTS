# Runbook: Database failover

## Trigger
Primary DB unavailable or degraded

## Preconditions
- Operator has approved access and ticket/incident/change ID.
- Evidence folder is created.
- Stop conditions are understood.

## Procedure
1. Confirm failure
2. Promote replica per SOP
3. Repoint services
4. Run migration lock check
5. Verify data consistency
6. Capture RPO/RTO

## Verification / exit criteria
- API healthy
- data checksum ok
- RPO/RTO recorded

## Escalation
Escalate to Ops Lead, Security Owner, System Owner and VATM Authority when stop condition, data integrity, security, audit or legal risk is detected.

## Evidence to attach
- command log
- screenshots or dashboard snapshots where permitted
- manifest/hash evidence
- incident/change ID
- closure note
