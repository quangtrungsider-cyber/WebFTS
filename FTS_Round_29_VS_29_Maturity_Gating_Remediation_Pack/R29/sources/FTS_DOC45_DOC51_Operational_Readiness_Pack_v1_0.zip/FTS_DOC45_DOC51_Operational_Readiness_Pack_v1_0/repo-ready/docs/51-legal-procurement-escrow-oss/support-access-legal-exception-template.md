# Vendor Support Legal Exception Template

- Support case ID:
- Vendor/personnel:
- Reason:
- Requested access mode:
- Data classification involved:
- Raw data exposure requested? Yes/No
- Masking/sanitization applied:
- TTL:
- Approvers: Data Owner / Security / Legal / VATM Authority
- Session recording/logging evidence:
- Closure note and deletion certificate:
