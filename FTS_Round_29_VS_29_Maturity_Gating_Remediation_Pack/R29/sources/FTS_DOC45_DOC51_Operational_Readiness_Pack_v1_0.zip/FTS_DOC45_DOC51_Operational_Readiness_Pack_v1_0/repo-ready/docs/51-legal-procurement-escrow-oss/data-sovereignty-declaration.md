# Data Sovereignty Declaration Template

- Environment:
- Data classes in scope:
- Location of compute/storage/backup:
- External network dependencies:
- SaaS/cloud services used, if any:
- Legal/Security approval:
- Data owner approval:
- Retention and deletion plan:
- Support access constraints:

Decision: Approved / Approved with conditions / Rejected.
