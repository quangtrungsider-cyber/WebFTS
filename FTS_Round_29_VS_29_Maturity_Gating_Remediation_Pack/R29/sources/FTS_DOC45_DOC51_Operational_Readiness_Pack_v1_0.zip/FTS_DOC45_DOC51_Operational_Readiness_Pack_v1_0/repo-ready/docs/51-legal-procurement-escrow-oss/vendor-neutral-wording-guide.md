# Vendor-neutral Wording Guide

Use: "The system shall support 4D trajectory simulation with configurable aircraft performance models and declared fallback limitations."

Avoid: naming one commercial simulator as mandatory.

Use: "or equivalent" when referencing methodology or benchmark tools.

Use acceptance evidence: sealed scenario, fixture/oracle tests, RTM, security evidence, performance results.

Avoid acceptance by slide, brochure or non-repeatable demo.
