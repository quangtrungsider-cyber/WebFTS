# Escrow Materials Checklist

Required before production milestone unless formally waived:

- Custom source code for FTS services, UI, workers and scripts.
- OpenAPI, AsyncAPI, DDL, JSON schemas, XState/state machines.
- Helm/Kustomize, environment schema, CI/CD pipeline and Makefile.
- Ruleset YAML, calibration manifests, fixture/oracle pack.
- Build instructions, toolchain lock, image digests and signing procedure.
- Runbooks, RTM, mini-specs and evidence generation scripts.
- Data dictionary and migration/restore procedures.

Do not place raw secrets or prohibited raw L3/L4 data in escrow archive. Use approved secret custody and data handling procedure.
