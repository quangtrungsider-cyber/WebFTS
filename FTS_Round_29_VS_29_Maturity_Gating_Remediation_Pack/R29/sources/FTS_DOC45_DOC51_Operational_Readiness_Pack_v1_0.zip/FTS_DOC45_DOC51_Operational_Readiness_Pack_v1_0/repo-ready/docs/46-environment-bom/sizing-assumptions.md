# DOC-46 Sizing Assumptions

The BOM is not a final procurement order. It is a reference baseline to prevent vague deployment planning. All hardware quantities must be validated using DOC-41 fixture/oracle tests and DOC-44 witness scripts. Any selected profile must be written into environment-bom.yaml and included in acceptance evidence.

Key drivers: number of aircraft rendered/replayed, 24h replay volume, simulation replications, weather grid size, AIRAC/AIXM volume, retention duration, Parquet/object storage compression, report volume, evidence pack volume and backup/restore RPO/RTO.
