#!/usr/bin/env python3
import csv
import pathlib
import sys

path = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else pathlib.Path('docs/49-traceability-rtm/master-rtm.csv')
required = ['requirement_id','description','source','doc_refs','module','api','event','ddl','rule','test','code_path','evidence_path','status']
blocking = []
with path.open(encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for i, row in enumerate(reader, start=2):
        for key in required:
            if not row.get(key):
                blocking.append(f'line {i}: missing {key}')
        if row.get('status') == 'GAP' and any(x in row.get('description','').lower() for x in ['security','legal','data','acceptance','environment']):
            blocking.append(f"line {i}: blocking GAP {row.get('requirement_id')}")
if blocking:
    print('\n'.join(blocking))
    sys.exit(1)
print('RTM check passed')
