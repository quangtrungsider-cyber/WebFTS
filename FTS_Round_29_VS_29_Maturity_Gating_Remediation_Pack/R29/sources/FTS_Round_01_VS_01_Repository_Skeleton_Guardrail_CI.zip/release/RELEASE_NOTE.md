# FTS Round 01 / VS-01 Release Note

Generated: 2026-05-12

## Release identity

- Release: `R01-VS-01`
- Vertical slice: `VS-01 — Repository skeleton and guardrail CI`
- Baseline: full FTS source package + `FTS_Round_00_Project_Ingestion_Bootstrap.zip`
- Boundary: **Decision-support / Non-operational**

## Outcome

Round 01 converts the Round 00 bootstrap into an executable repository foundation. The repo now has importable source skeletons, contract placeholders, CI workflow, pre-commit hook definitions, Makefile targets, machine-readable guardrail policy, a local guardrail scanner, and tests proving the mandatory guardrails catch representative violations.

This round does **not** implement the production FTS app yet. It locks the repo and CI gates needed before implementing the data foundation and scenario lifecycle.

## Source references used

Round 01 used the same source hierarchy established in Round 00:

- AppSpec v8.5 and BRD/FRD v1.1 for product scope and functional intent.
- Tầng 0 for H0/H1 governance, hierarchy-of-truth, conflict and gap discipline.
- Tầng 2 for ADRs, deterministic math/time, no system-time/no-float guardrails and CI enforcement.
- Tầng 5 for business/calculation rules and no operational write-back / deterministic rule IDs.
- Tầng 6 for L1-L4 classification, secrets, masking, logging and security evidence.
- Tầng 9 for tests, deterministic fixtures, MockTimeProvider and evidence expectations.
- Tầng 10 for local development, CI/CD, observability and operational packaging.
- SOP-1CODER for solo-dev order, feature scaffolding and evidence packaging.
- DOC-35..DOC-39 and Round 00 for source map, vertical slices, runtime materialization and repository bootstrap.

Full hashes and zip entries are in `manifest/source_manifest_round01.json`.

## Materialized repository changes

- Added `pyproject.toml`, `.gitignore`, `.pre-commit-config.yaml`.
- Added Python package skeleton under `src/fts`.
- Added API placeholder under `services/api`.
- Added engine placeholder under `engine/core` using scaled-integer foundation types only.
- Added OpenAPI, AsyncAPI, state-machine and DDL placeholders.
- Added `tools/guardrails/rules.yaml`, `tools/guardrails/scan.py`, and `tools/guardrails/validate_policy.py`.
- Updated `Makefile` so `make guardrails-scan` runs without a Semgrep binary.
- Updated `.github/workflows/ci.yml` to run Round 01 executable gates.
- Added guardrail policy docs under `docs/05-rules` and log redaction policy under `docs/06-security`.
- Added tests for repository boundary, injected simulation time and guardrail detection.
- Added placeholder scripts for Makefile targets that were referenced but not materialized in Round 00.
- Ran the required scaffold command for `features/scenario-lifecycle` with `SIZE=L` and `SLICE=VS-03`.

## Guardrails enforced in Round 01

`make guardrails-scan` now fails closed for these P0 conditions:

1. Live ATC/ATFM write-back or operational command paths.
2. Wall-clock/system time in deterministic domain, engine, KPI and report-hash paths.
3. Float/double-style numeric types in deterministic decision paths.
4. Hard-coded separation, wake or LoA minima.
5. Raw L3/L4 payload logging.
6. Static credentials, private keys or real tokens.

## Evidence summary

| Command | Status | Evidence |
|---|---:|---|
| `make doctor PROFILE=core` | PASS | `evidence/final_make_doctor_PROFILE-core.log` |
| `make docs-validate` | PASS | `evidence/final_make_docs-validate.log` |
| `make guardrails-scan` | PASS | `evidence/final_make_guardrails-scan.log`, `repo/fts/artifacts/guardrails-report.json` |
| `make scaffold-feature NAME=scenario-lifecycle SIZE=L SLICE=VS-03` | PASS | `evidence/make_scaffold-feature_NAME-scenario-lifecycle_SIZE-L_SLICE-VS-03.log` |
| `pytest tests/security` | PASS | `evidence/pytest_tests-security.log`, `repo/fts/artifacts/junit-security.xml` |
| `make test-contract` | PASS | `evidence/final_make_test-contract.log`, `repo/fts/artifacts/junit-contract.xml` |
| `make test-time` | PASS | `evidence/final_make_test-time.log`, `repo/fts/artifacts/junit-time.xml` |
| `make security-evidence` | PASS | `evidence/final_make_security-evidence.log`, `repo/fts/artifacts/log-redaction-report.json` |
| `make evidence-pack RELEASE=R01-VS-01` | PASS | `repo/fts/artifacts/release-evidence-pack.zip` |
| `make evidence-local PROFILE=core` | PASS | `repo/fts/artifacts/local-evidence.zip` |

## Known limitations

- Production FTS services, database runtime, workers, UI and simulation engine are not implemented in Round 01.
- `docker` was not available in the execution environment, so `make compose-up` was not run.
- The decision register still reports 54 open decisions; Round 01 uses safe defaults and does not code affected production behavior.
- `migrate`, `testdata-*`, PoC and audit-chain tools are materialized as placeholders; they become executable in later vertical slices.
- The `scenario-lifecycle` feature scaffold is ready, but full implementation should wait until the VS-02 data foundation dependency is completed.
