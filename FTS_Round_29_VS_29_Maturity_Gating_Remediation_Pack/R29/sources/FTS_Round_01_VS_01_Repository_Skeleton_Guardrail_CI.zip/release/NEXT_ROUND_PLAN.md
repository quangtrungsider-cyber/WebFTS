# Proposed Round 02 Plan — VS-02 Data Foundation

## Why VS-02 next

The source vertical-slice roadmap says `VS-03 Scenario lifecycle` depends on `VS-02 Data foundation`. Round 01 created the requested `scenario-lifecycle` scaffold, but the next implementation round should complete VS-02 before coding the scenario lifecycle API and persistence.

## Round 02 release target

- Release: `R02-VS-02`
- Slice: `VS-02 — Data foundation: DDL, dictionary, object manifest and audit seed`
- Boundary: Decision-support / Non-operational
- Primary goal: replace Round 01 data placeholders with executable schema/data-governance artifacts and tests.

## Scope for Round 02

1. **Data foundation artifacts**
   - Create initial schema artifacts for scenario bundle, scenario run, dataset manifest, object manifest, audit event and ruleset reference.
   - Keep all schema decisions traceable to DOC-12, DOC-13, DOC-14, DOC-15, DOC-16, DOC-22, DOC-24 and DOC-37.
   - Use migration files only; no ad-hoc DB scripts.

2. **Data dictionary and classification**
   - Add `docs/data/data-dictionary.yaml` or equivalent repo-approved path.
   - Every persisted field gets owner, type, unit where applicable, classification default and retention note.
   - Unknown classification must fail closed as L4 pending review.

3. **Object manifest and hash policy**
   - Add object manifest schema for uploaded/imported artifacts.
   - Require SHA-256, size, content type, source, classification, effective date when applicable and lineage references.
   - Add tests that missing hash/classification/effective-time fails validation.

4. **Audit seed**
   - Replace placeholder `tools/audit/verify_hash_chain.py` with a deterministic verifier for a minimal append-only audit chain fixture.
   - Add `fixtures/audit/minimal-chain.json` sanitized fixture and expected hash.

5. **Makefile and CI hardening**
   - Keep `make doctor`, `make docs-validate`, `make guardrails-scan` green.
   - Make `make migrate PROFILE=core` perform a real validation path for the initial schema. If no live Postgres is available, provide offline SQL/schema validation and keep compose execution optional.
   - Add `make test-data-foundation` or route tests through existing contract/security gates.

6. **Guardrail extensions**
   - Add scanner checks for missing classification on fixture/schema examples.
   - Add scanner or validator checks that no source code embeds airport/sector/route/procedure reference lists outside approved reference-data artifacts.
   - Keep existing six P0 rules unchanged and passing.

7. **Evidence and release packaging**
   - Produce `R02-VS-02` zip with release note, changelog, evidence manifest, logs and next-round plan.
   - Include all command outputs and JSON/JUnit reports.

## Round 02 acceptance criteria

- `make doctor PROFILE=core` passes.
- `make docs-validate` passes.
- `make guardrails-scan` passes with zero findings.
- `make migrate PROFILE=core` passes using the Round 02 data-foundation validation path.
- Data dictionary validator passes.
- Object manifest validator passes.
- Audit chain verifier passes on sanitized fixture.
- Security/log-redaction evidence passes.
- No live ATC/ATFM write-back path, system-time deterministic leak, float/double deterministic path, hard-coded separation minima, raw L3/L4 logging or static secret is introduced.

## Suggested Round 02 command sequence

```bash
make doctor PROFILE=core
make docs-validate
make guardrails-scan
make migrate PROFILE=core
pytest tests/data --junitxml=artifacts/junit-data-foundation.xml
make test-contract
make test-time
make security-evidence
make evidence-pack RELEASE=R02-VS-02
```

## Prompt for the next session

Thực hiện Round 02 / VS-02 cho app FTS: dựa trên toàn bộ nguồn project, gói Round 00 và gói Round 01, hoàn thiện Data Foundation gồm DDL/schema ban đầu, data dictionary, object manifest schema, classification fail-closed, audit hash-chain seed và validator. Không triển khai scenario lifecycle đầy đủ trước khi VS-02 pass. Giữ nguyên boundary Decision-support / Non-operational và các guardrail CI đã có. Chạy `make doctor PROFILE=core`, `make docs-validate`, `make guardrails-scan`, `make migrate PROFILE=core`, test data-foundation, `make test-contract`, `make test-time`, `make security-evidence`, `make evidence-pack RELEASE=R02-VS-02`; đóng gói release note, changelog, evidence manifest, logs và kế hoạch Round 03 trong file zip.
