# FTS Round 01 / VS-01 Changelog

## Added

- `tools/guardrails/rules.yaml` with six mandatory P0 guardrail rules.
- `tools/guardrails/scan.py` local scanner with JSON report output.
- `tools/guardrails/validate_policy.py` policy validator included in `make docs-validate`.
- `src/fts` package skeleton with scope boundary, classification and simulation time provider.
- `src/fts/domain/scenario_lifecycle.py` minimal deterministic state transition helper for future VS-03 use.
- `services/api/app.py` health skeleton that returns the non-operational boundary.
- `engine/core` placeholder with scaled-value primitives.
- `openapi/fts-openapi.v1.yaml`, `asyncapi/fts-asyncapi.v1.yaml`, `state-machines/scenario-lifecycle.xstate.json` and `db/migrations/0001_foundation_schema.sql` placeholders.
- `tests/security/test_guardrails_scan.py`, `tests/contracts/test_round01_foundation.py` and `tests/time/test_simulation_time_provider.py`.
- `docs/05-rules/guardrail-ci-policy.md`, `docs/06-security/log-redaction-policy.md` and `docs/00-governance/ROUND01_READBACK.md`.
- Placeholder scripts for Makefile targets: migration, testdata compile/load/verify, WIP handoff and PoC salt data.
- Feature scaffold for `features/scenario-lifecycle` with mini-spec, traceability, test matrix, security evidence, risk register and runbook fragment.

## Changed

- `Makefile` guardrails target now uses the local Python scanner instead of a hard dependency on Semgrep.
- `Makefile` docs validation now also validates the guardrail policy.
- `Makefile` `security-evidence` now enforces guardrails, security tests, log-redaction scan and hash-chain verifier placeholder.
- `.github/workflows/ci.yml` now focuses on executable Round 01 gates: doctor, docs validation, guardrails, security tests, contract tests, time tests and evidence pack.
- `README.md` updated from Round 00 bootstrap wording to Round 01 executable skeleton wording.
- `tools/semgrep/README.md` clarified that Semgrep can be added later as a supplementary scanner.

## Verified

- `make doctor PROFILE=core` passes.
- `make docs-validate` passes.
- `make guardrails-scan` passes with zero findings.
- `pytest tests/security` passes and proves the six guardrail classes are detectable.
- `make test-contract` passes.
- `make test-time` passes.
- `make security-evidence` passes.
- `make scaffold-feature NAME=scenario-lifecycle SIZE=L SLICE=VS-03` creates the requested feature scaffold.
- `make evidence-pack RELEASE=R01-VS-01` and `make evidence-local PROFILE=core` generate evidence archives.

## Not changed / intentionally deferred

- No production ATC/ATFM integration.
- No production DB migration execution.
- No actual simulation worker, trajectory engine or UI implementation.
- No real operational, L3/L4 or sensitive aviation payloads added.
- No hard-coded separation minima or rule thresholds added.
