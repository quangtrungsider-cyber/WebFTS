# Round 01 Source Inventory

Generated: 2026-05-12

Round 01 references the full source package and the Round 00 bootstrap package. Hashes are SHA-256.

| File | Kind | Size | SHA-256 prefix | Notes |
|---|---:|---:|---|---|
| AT04_FTS_AppSpec_VATM_v8_5_NextGen_MasterBlueprint.docx | docx | 70295 | 8cf0b426ff78b595 |  |
| VATM_FTS_BRD_FRD_De_xuat_v1_1_Zero_Loophole_Developer_Ready_05_2026.docx | docx | 104387 | b070d12a27cc045a |  |
| FTS_Tang_0_DOC00_DOC00_1_Quy_tac_van_hanh_Toi_thuong_v2_5.docx | docx | 63991 | e7c44916fed4f809 |  |
| FTS_Tang_1_DOC01_DOC04_Hoan_thien_v2_3.docx | docx | 388460 | 7e1f063cf1d8f08b |  |
| FTS_Tang_2_DOC05_DOC07_Hoan_thien_v2_7_Production_Hardened.docx | docx | 75177 | 50769ef9707084ac |  |
| FTS_Tang_3_DOC08_DOC11_5_Interface_Contracts_Hoan_thien_v2_9_Extreme_Scale_Hardened.docx | docx | 65493 | 03cc08110f41e5c3 |  |
| FTS_Tang_4_DOC12_DOC16_Data_Specification_Hoan_thien_v3_1_Extreme_Scale_Data_Layer.docx | docx | 62343 | 189c00c1705df551 |  |
| FTS_Tang_5_DOC17_DOC19_5_Business_Rules_Calculation_Hoan_thien_v3_3_Ultimate_Logic_Realism_Hardened.docx | docx | 81472 | 8ea11f3b44d1b35a |  |
| FTS_Tang_6_DOC20_DOC22_Security_Privacy_Implementation_Pack_v1_1_Military_Grade_Hardened.docx | docx | 83942 | 73b5c1512dd4c7a6 |  |
| FTS_Tang_7_DOC23_DOC25_Domain_Simulation_Engine_Protocol_Pack_v1_1_Ultimate_Domain_Physics_Hardened.docx | docx | 87092 | 4298981285bfee79 |  |
| FTS_Tang_8_DOC26_DOC28_Frontend_UX_Implementation_Hoan_thien_v3_1_Extreme_Performance_ATCO_Grade_UI.docx | docx | 87363 | cf720393e362071f |  |
| FTS_Tang_9_DOC29_DOC30_DOC30_5_Testing_Reference_Ultimate_Test_Hardened_v1_1.docx | docx | 94007 | 6e581e1e4c64e12a |  |
| FTS_Tang_10_DOC31_DOC34_DevOps_Operations_Reference_Ultimate_Enterprise_Ops_Hardened_v1_1.docx | docx | 94055 | c5c2e1bf882572c1 |  |
| FTS_Quy_trinh_chuan_1_coder_v1_1_Ultimate_Solo_Dev_Survival_Hardened.docx | docx | 89414 | c9b651d8ce1481cf |  |
| FTS_DOC35_DOC39_Implementation_Pack_v1_0.zip | zip | 121672 | 66a783fb2f2e54de | 6 zip entries |
| FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0.zip | zip | 212896 | d9c94a115acd2643 | 62 zip entries |
| FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0.zip | zip | 417614 | d1e74f142ffe1007 | 174 zip entries |
| FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0.zip | zip | 578932 | 3fccdf5703b08031 | 94 zip entries |
| FTS_Round_00_Project_Ingestion_Bootstrap.zip | zip | 140267 | 409fee6fde76b5fd | 69 zip entries |
