# FTS Round 01 / VS-01 Package

This zip contains the Round 01 implementation package for VATM FTS.

## Contents

- `repo/fts/` — executable repository skeleton and guardrail CI.
- `release/RELEASE_NOTE.md` — Round 01 release note.
- `release/CHANGELOG.md` — detailed changelog.
- `release/NEXT_ROUND_PLAN.md` — full proposed Round 02 plan.
- `release/EVIDENCE_MANIFEST.yaml` — commands, logs, artifacts and known limitations.
- `evidence/` — command logs from Round 01.
- `manifest/` — source inventory, hashes and repo file tree.

## Re-run core checks

```bash
cd repo/fts
make doctor PROFILE=core
make docs-validate
make guardrails-scan
make scaffold-feature NAME=scenario-lifecycle SIZE=L SLICE=VS-03
```

## Boundary

FTS remains Decision-support / Non-operational. Round 01 does not introduce production operational control behavior.
