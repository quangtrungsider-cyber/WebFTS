# Sanitized Fixtures

Round 01 does not include operational aviation data. Later fixtures must carry dataset manifest, classification labels and oracle hashes.
