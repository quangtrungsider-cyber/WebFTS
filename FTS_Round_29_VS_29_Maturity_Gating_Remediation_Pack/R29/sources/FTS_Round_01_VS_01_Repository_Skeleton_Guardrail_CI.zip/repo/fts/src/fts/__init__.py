"""VATM FTS application package.

Round 01 includes only repository skeleton, guardrail CI and non-operational
foundation types. Production services are materialized in later vertical slices.
"""

BOUNDARY = "Decision-support / Non-operational"
