from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from fts.shared.time_provider import EpochMillis, SimulationTimeProvider


class ScenarioState(str, Enum):
    DRAFT = "DRAFT"
    VALIDATED = "VALIDATED"
    FROZEN = "FROZEN"
    SUBMITTED = "SUBMITTED"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    ARCHIVED = "ARCHIVED"


_ALLOWED_TRANSITIONS: dict[ScenarioState, set[ScenarioState]] = {
    ScenarioState.DRAFT: {ScenarioState.VALIDATED},
    ScenarioState.VALIDATED: {ScenarioState.FROZEN},
    ScenarioState.FROZEN: {ScenarioState.SUBMITTED, ScenarioState.ARCHIVED},
    ScenarioState.SUBMITTED: {ScenarioState.RUNNING},
    ScenarioState.RUNNING: {ScenarioState.COMPLETED},
    ScenarioState.COMPLETED: {ScenarioState.ARCHIVED},
    ScenarioState.ARCHIVED: set(),
}


@dataclass(frozen=True)
class ScenarioLifecycleDecision:
    from_state: ScenarioState
    to_state: ScenarioState
    simulation_time_ms: EpochMillis
    accepted: bool
    reason: str


def transition(
    current: ScenarioState,
    requested: ScenarioState,
    clock: SimulationTimeProvider,
) -> ScenarioLifecycleDecision:
    accepted = requested in _ALLOWED_TRANSITIONS[current]
    return ScenarioLifecycleDecision(
        from_state=current,
        to_state=requested,
        simulation_time_ms=clock.epoch_millis(),
        accepted=accepted,
        reason="allowed" if accepted else "transition_not_allowed",
    )
