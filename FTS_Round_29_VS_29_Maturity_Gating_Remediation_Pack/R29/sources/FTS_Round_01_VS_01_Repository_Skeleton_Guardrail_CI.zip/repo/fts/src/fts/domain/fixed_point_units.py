from __future__ import annotations

from typing import NewType

NmE6 = NewType("NmE6", int)
FtE3 = NewType("FtE3", int)
DegE3 = NewType("DegE3", int)
Millis = NewType("Millis", int)


def nm_e6(value: int) -> NmE6:
    return NmE6(value)


def ft_e3(value: int) -> FtE3:
    return FtE3(value)
