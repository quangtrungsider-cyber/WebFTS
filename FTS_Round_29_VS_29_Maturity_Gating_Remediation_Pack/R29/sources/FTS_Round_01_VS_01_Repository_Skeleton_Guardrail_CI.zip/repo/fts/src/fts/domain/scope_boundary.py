from __future__ import annotations

from dataclasses import dataclass

BOUNDARY_WATERMARK = "Decision-support / Non-operational"


@dataclass(frozen=True)
class ScopeBoundary:
    non_operational_mode: bool = True
    live_writeback_enabled: bool = False
    watermark_text: str = BOUNDARY_WATERMARK

    def validate(self) -> None:
        if not self.non_operational_mode:
            raise ValueError("FTS boundary requires non-operational mode")
        if self.live_writeback_enabled:
            raise ValueError("FTS boundary forbids live operational integration")
        if self.watermark_text != BOUNDARY_WATERMARK:
            raise ValueError("FTS boundary watermark mismatch")
