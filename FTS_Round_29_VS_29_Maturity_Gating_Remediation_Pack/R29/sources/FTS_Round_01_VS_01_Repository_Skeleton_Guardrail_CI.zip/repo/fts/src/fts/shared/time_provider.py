from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, NewType

EpochMillis = NewType("EpochMillis", int)


class SimulationTimeProvider(Protocol):
    """Provides simulation time for deterministic FTS paths."""

    def epoch_millis(self) -> EpochMillis:
        """Return simulation epoch milliseconds from the scenario/run clock."""


@dataclass(frozen=True)
class FrozenSimulationTimeProvider:
    """Immutable test/provider implementation for reproducible runs."""

    value: EpochMillis

    def epoch_millis(self) -> EpochMillis:
        return self.value
