from __future__ import annotations

from enum import Enum


class DataClassification(str, Enum):
    L1_PUBLIC = "L1"
    L2_INTERNAL = "L2"
    L3_RESTRICTED = "L3"
    L4_PENDING_REVIEW = "L4"


def default_classification(label: str | None) -> DataClassification:
    """Fail closed: unknown or absent labels are handled as the most restrictive default."""
    if label in {item.value for item in DataClassification}:
        return DataClassification(label)
    return DataClassification.L4_PENDING_REVIEW
