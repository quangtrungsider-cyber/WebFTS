#!/usr/bin/env python3
import argparse

ap = argparse.ArgumentParser()
ap.add_argument("--profile", default="core")
args = ap.parse_args()
print(f"testdata compile placeholder ok: profile={args.profile}; no binary fixtures in Round 01")
