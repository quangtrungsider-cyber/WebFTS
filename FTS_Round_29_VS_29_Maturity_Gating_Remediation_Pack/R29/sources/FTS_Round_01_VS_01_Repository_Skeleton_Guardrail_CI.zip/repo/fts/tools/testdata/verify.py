#!/usr/bin/env python3
import argparse

ap = argparse.ArgumentParser()
ap.add_argument("--profile", default="core")
ap.add_argument("--checks", default="hash,classification,baseline")
args = ap.parse_args()
print(f"testdata verify placeholder ok: profile={args.profile}; checks={args.checks}")
