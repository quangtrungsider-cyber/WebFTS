#!/usr/bin/env python3
import argparse

ap = argparse.ArgumentParser()
ap.add_argument("--profile", default="core")
args = ap.parse_args()
print(f"testdata load placeholder ok: profile={args.profile}; sanitized fixtures only in Round 01")
