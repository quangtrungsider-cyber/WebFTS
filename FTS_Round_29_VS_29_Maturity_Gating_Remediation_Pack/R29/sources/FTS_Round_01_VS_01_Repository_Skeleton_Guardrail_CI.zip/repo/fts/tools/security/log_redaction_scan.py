#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

PATTERNS = [
    ("raw-payload", re.compile(r"(?i)raw[_-]?(l3|l4|asterix|fdp|payload)")),
    ("payload-log", re.compile(r"(?i)(logger|logging|console\.log|print).{0,120}payload")),
    ("private-key", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")),
    ("static-token", re.compile(r"(?i)(api[_-]?key|client[_-]?secret|access[_-]?token|password)\s*[:=]\s*['\"][^'\"]{8,}['\"]")),
]
ALLOW = re.compile(r"(?i)(placeholder|dummy|example|change_me|dev_only|__REDACTED__|not-a-secret)")


def scan_path(path: Path) -> list[dict[str, object]]:
    findings: list[dict[str, object]] = []
    if not path.exists():
        return findings
    files = [path] if path.is_file() else [p for p in path.rglob("*") if p.is_file()]
    for file_path in files:
        if file_path.stat().st_size > 1_000_000:
            continue
        try:
            text = file_path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        for name, rx in PATTERNS:
            for match in rx.finditer(text):
                excerpt = " ".join(text[max(0, match.start()-80):match.end()+80].split())
                if ALLOW.search(excerpt):
                    continue
                findings.append({"rule": name, "path": file_path.as_posix(), "excerpt": excerpt})
    return findings


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("paths", nargs="*", default=["artifacts", "logs"])
    ap.add_argument("--output", default="artifacts/log-redaction-report.json")
    args = ap.parse_args()
    findings: list[dict[str, object]] = []
    for item in args.paths:
        findings.extend(scan_path(Path(item)))
    report = {"status": "PASS" if not findings else "FAIL", "findings_count": len(findings), "findings": findings}
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"status": report["status"], "findings_count": report["findings_count"]}, ensure_ascii=False))
    return 2 if findings else 0


if __name__ == "__main__":
    raise SystemExit(main())
