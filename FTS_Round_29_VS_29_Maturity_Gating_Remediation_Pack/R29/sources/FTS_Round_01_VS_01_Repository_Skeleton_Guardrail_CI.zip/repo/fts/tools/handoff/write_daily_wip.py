#!/usr/bin/env python3
import argparse
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument("--output", default="daily-wip-handoff.md")
args = ap.parse_args()
Path(args.output).write_text("# Daily WIP Handoff\n\n- Round: R01\n- Status: skeleton/guardrails ready\n", encoding="utf-8")
print(f"wrote {args.output}")
