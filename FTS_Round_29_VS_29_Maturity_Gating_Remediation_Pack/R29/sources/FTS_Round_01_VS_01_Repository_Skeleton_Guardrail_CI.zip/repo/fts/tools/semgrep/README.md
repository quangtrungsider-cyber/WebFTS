# Semgrep compatibility note

Round 01 replaces the hard dependency on a local Semgrep binary with the Python guardrail scanner in `tools/guardrails` so `make guardrails-scan` is runnable in minimal and air-gapped environments.

Future rounds may add Semgrep packs here as an additional scanner, but the Round 01 gate remains `tools/guardrails/scan.py`.
