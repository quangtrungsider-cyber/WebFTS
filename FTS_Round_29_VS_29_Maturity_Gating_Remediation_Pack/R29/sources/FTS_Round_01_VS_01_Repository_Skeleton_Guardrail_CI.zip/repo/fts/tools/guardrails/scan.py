#!/usr/bin/env python3
"""FTS guardrail policy scanner.

The scanner is intentionally dependency-light and fail-closed. It materializes the
Round 01 policy as an executable gate instead of keeping H0 and deterministic
rules as prose only.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

import yaml


@dataclass(frozen=True)
class Finding:
    rule_id: str
    severity: str
    path: str
    line: int
    column: int
    message: str
    excerpt: str

    def as_dict(self) -> dict[str, object]:
        return {
            "rule_id": self.rule_id,
            "severity": self.severity,
            "path": self.path,
            "line": self.line,
            "column": self.column,
            "message": self.message,
            "excerpt": self.excerpt,
        }


def _load_policy(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    if not isinstance(data, dict):
        raise ValueError(f"policy is not a mapping: {path}")
    return data


def _compile_many(patterns: Sequence[str] | None) -> list[re.Pattern[str]]:
    return [re.compile(p) for p in (patterns or [])]


def _is_binary_or_unreadable(path: Path) -> bool:
    try:
        chunk = path.read_bytes()[:4096]
    except OSError:
        return True
    return b"\x00" in chunk


def _iter_files(root: Path, requested: Sequence[str], policy: dict[str, object]) -> Iterable[Path]:
    scan_cfg = policy.get("scan") or {}
    if not isinstance(scan_cfg, dict):
        scan_cfg = {}
    ignore_dirs = set(scan_cfg.get("ignore_dirs") or [])
    exts = set(scan_cfg.get("file_extensions") or [])
    max_bytes = int(scan_cfg.get("max_file_bytes") or 1_000_000)

    for item in requested:
        p = (root / item).resolve()
        if not p.exists():
            continue
        if p.is_file():
            candidates = [p]
        else:
            candidates = []
            for dirpath, dirnames, filenames in os.walk(p):
                rel_dir = Path(dirpath).resolve().relative_to(root.resolve()).as_posix()
                dirnames[:] = [d for d in dirnames if d not in ignore_dirs and f"{rel_dir}/{d}" not in ignore_dirs]
                for name in filenames:
                    candidates.append(Path(dirpath) / name)
        for file_path in candidates:
            try:
                rel = file_path.resolve().relative_to(root.resolve()).as_posix()
            except ValueError:
                continue
            if any(part in ignore_dirs for part in Path(rel).parts):
                continue
            suffixes = file_path.suffixes
            suffix = file_path.suffix
            if suffix not in exts and not any(s in exts for s in suffixes) and file_path.name not in {".env.example"}:
                continue
            try:
                if file_path.stat().st_size > max_bytes:
                    continue
            except OSError:
                continue
            if _is_binary_or_unreadable(file_path):
                continue
            yield file_path


def _line_col(text: str, offset: int) -> tuple[int, int]:
    line = text.count("\n", 0, offset) + 1
    prev = text.rfind("\n", 0, offset)
    column = offset + 1 if prev < 0 else offset - prev
    return line, column


def _excerpt(text: str, start: int, end: int) -> str:
    left = max(0, start - 80)
    right = min(len(text), end + 80)
    return " ".join(text[left:right].split())


def _allowed(match_text: str, allow_patterns: list[re.Pattern[str]]) -> bool:
    return any(p.search(match_text) for p in allow_patterns)


def run_scan(
    root: str | Path,
    rules_path: str | Path,
    scan_roots: Sequence[str] | None = None,
    output_path: str | Path | None = None,
) -> dict[str, object]:
    root = Path(root).resolve()
    policy = _load_policy(Path(rules_path))
    scan_cfg = policy.get("scan") or {}
    if not isinstance(scan_cfg, dict):
        scan_cfg = {}
    requested = list(scan_roots or scan_cfg.get("default_roots") or [])

    findings: list[Finding] = []
    files_scanned = 0
    rules = policy.get("rules") or []
    if not isinstance(rules, list):
        raise ValueError("policy.rules must be a list")

    prepared_rules = []
    for rule in rules:
        if not isinstance(rule, dict):
            continue
        include = re.compile(str(rule.get("include_path_regex") or ".*"))
        exclude = re.compile(str(rule.get("exclude_path_regex") or r"$^"))
        prepared_rules.append(
            {
                "id": str(rule.get("id")),
                "severity": str(rule.get("severity") or "P2"),
                "message": str(rule.get("message") or "guardrail violation"),
                "include": include,
                "exclude": exclude,
                "regexes": _compile_many(rule.get("regexes") or []),
                "allow": _compile_many(rule.get("allow_context_regexes") or []),
            }
        )

    for file_path in _iter_files(root, requested, policy):
        rel = file_path.resolve().relative_to(root).as_posix()
        try:
            text = file_path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            text = file_path.read_text(encoding="utf-8", errors="replace")
        files_scanned += 1
        for rule in prepared_rules:
            if not rule["include"].search(rel) or rule["exclude"].search(rel):
                continue
            for regex in rule["regexes"]:
                for match in regex.finditer(text):
                    context = _excerpt(text, match.start(), match.end())
                    if _allowed(context, rule["allow"]):
                        continue
                    line, col = _line_col(text, match.start())
                    findings.append(
                        Finding(
                            rule_id=rule["id"],
                            severity=rule["severity"],
                            path=rel,
                            line=line,
                            column=col,
                            message=rule["message"],
                            excerpt=context,
                        )
                    )

    report = {
        "policy_id": policy.get("policy_id"),
        "boundary": policy.get("boundary"),
        "root": root.as_posix(),
        "scan_roots": requested,
        "files_scanned": files_scanned,
        "findings_count": len(findings),
        "findings": [f.as_dict() for f in findings],
        "status": "PASS" if not findings else "FAIL",
    }
    if output_path is not None:
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    return report


def main(argv: Sequence[str] | None = None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    ap.add_argument("--rules", default="tools/guardrails/rules.yaml")
    ap.add_argument("--paths", nargs="*", help="Override scan roots")
    ap.add_argument("--output", default="artifacts/guardrails-report.json")
    ap.add_argument("--no-fail", action="store_true", help="Write report but return success")
    args = ap.parse_args(argv)
    report = run_scan(args.root, args.rules, args.paths, args.output)
    print(json.dumps({k: report[k] for k in ("policy_id", "status", "files_scanned", "findings_count")}, ensure_ascii=False))
    if report["findings_count"]:
        for finding in report["findings"][:20]:
            print(
                f"{finding['severity']} {finding['rule_id']} {finding['path']}:{finding['line']}:{finding['column']} - {finding['message']}",
                file=sys.stderr,
            )
        return 0 if args.no_fail else 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
