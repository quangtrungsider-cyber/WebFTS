# FTS Guardrail CI

Round 01 materializes the P0 guardrails as a local scanner and CI gate.

The scanner fails closed for:

1. live ATC/ATFM write-back or operational command paths;
2. wall-clock/system time in deterministic domain, engine, KPI and report-hash paths;
3. float/double-style numeric types in deterministic decision paths;
4. hard-coded separation/wake/LoA minima;
5. raw L3/L4 payload logging;
6. static credentials and committed secrets.

Run:

```bash
make guardrails-scan
```

The machine report is written to `artifacts/guardrails-report.json`.
