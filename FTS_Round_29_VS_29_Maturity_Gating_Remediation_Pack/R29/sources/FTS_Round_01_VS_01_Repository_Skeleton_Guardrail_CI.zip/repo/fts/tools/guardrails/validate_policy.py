#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import yaml


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("path")
    args = ap.parse_args()
    data = yaml.safe_load(Path(args.path).read_text(encoding="utf-8"))
    errors: list[str] = []
    if not isinstance(data, dict):
        print("guardrail policy invalid: root is not mapping", file=sys.stderr)
        return 2
    rules = data.get("rules") or []
    required = set(data.get("required_rule_ids") or [])
    ids = [r.get("id") for r in rules if isinstance(r, dict)]
    if len(ids) != len(set(ids)):
        errors.append("duplicate rule id")
    missing = sorted(required - set(ids))
    if missing:
        errors.append("missing required rules: " + ", ".join(missing))
    for r in rules:
        if not isinstance(r, dict):
            errors.append("non-map rule")
            continue
        if not r.get("id") or not r.get("severity") or not r.get("regexes"):
            errors.append(f"{r.get('id')} missing id/severity/regexes")
    scan = data.get("scan") or {}
    if not scan.get("default_roots"):
        errors.append("scan.default_roots missing")
    if errors:
        print("guardrail policy invalid: " + "; ".join(errors), file=sys.stderr)
        return 2
    print(f"guardrail policy ok: {len(ids)} rules; required={len(required)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
