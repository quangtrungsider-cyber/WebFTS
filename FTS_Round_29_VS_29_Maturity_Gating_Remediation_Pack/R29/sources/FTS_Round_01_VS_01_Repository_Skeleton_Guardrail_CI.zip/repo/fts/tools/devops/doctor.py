#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import platform
import shutil
import sys
from pathlib import Path

import yaml


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", default="core")
    args = ap.parse_args()
    root = Path.cwd()
    required = [
        "docs/00-governance/docs-map.yaml",
        "docs/00-governance/decision-register.yaml",
        "docs/00-governance/vertical-slices.yaml",
        "docs/00-governance/runtime-materialization-matrix.yaml",
        "docs/00-governance/ROUND01_READBACK.md",
        "tools/guardrails/rules.yaml",
        "tools/guardrails/scan.py",
        "tools/guardrails/validate_policy.py",
        "src/fts/domain/scope_boundary.py",
        "src/fts/shared/time_provider.py",
        "openapi/fts-openapi.v1.yaml",
        "asyncapi/fts-asyncapi.v1.yaml",
        "state-machines/scenario-lifecycle.xstate.json",
        ".github/workflows/ci.yml",
        "Makefile",
        "pyproject.toml",
    ]
    missing = [p for p in required if not (root / p).exists()]
    guardrail_rule_count = 0
    required_guardrails_missing: list[str] = []
    policy_path = root / "tools/guardrails/rules.yaml"
    if policy_path.exists():
        policy = yaml.safe_load(policy_path.read_text(encoding="utf-8"))
        rules = policy.get("rules") or []
        guardrail_rule_count = len(rules)
        ids = {r.get("id") for r in rules if isinstance(r, dict)}
        required_ids = set(policy.get("required_rule_ids") or [])
        required_guardrails_missing = sorted(required_ids - ids)
    report = {
        "profile": args.profile,
        "round": "R01-VS-01",
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "docker_present": shutil.which("docker") is not None,
        "git_present": shutil.which("git") is not None,
        "missing_required_files": missing,
        "guardrail_rule_count": guardrail_rule_count,
        "required_guardrails_missing": required_guardrails_missing,
        "boundary": "Decision-support / Non-operational",
    }
    Path("artifacts").mkdir(exist_ok=True)
    Path("artifacts/doctor-report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    if missing or required_guardrails_missing:
        print("doctor failed:", json.dumps(report, ensure_ascii=False), file=sys.stderr)
        return 2
    print("doctor ok:", json.dumps(report, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
