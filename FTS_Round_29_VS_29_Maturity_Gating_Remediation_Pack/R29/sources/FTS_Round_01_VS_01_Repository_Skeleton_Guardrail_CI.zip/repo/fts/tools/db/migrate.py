#!/usr/bin/env python3
import argparse

ap = argparse.ArgumentParser()
ap.add_argument("--profile", default="core")
args = ap.parse_args()
print(f"migration placeholder ok: profile={args.profile}; no runtime DB migration in Round 01")
