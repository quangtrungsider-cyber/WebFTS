# VATM FTS — Round 01 Repository Skeleton + Guardrail CI

Generated: 2026-05-12

This repository is the Round 01 / VS-01 implementation foundation for VATM FTS. It is not a production app yet. It is the executable skeleton used to continue sequential implementation.

## Start here

```bash
make doctor PROFILE=core
make docs-validate
make guardrails-scan
make scaffold-feature NAME=scenario-lifecycle SIZE=L SLICE=VS-03
```

## Current status

- Round 00 source inventory and governance artifacts preserved.
- Python package skeleton, API placeholder, engine placeholder, OpenAPI/AsyncAPI/state-machine/DDL placeholders added.
- Guardrail CI materialized with local scanner and policy file.
- Security tests verify that each mandatory guardrail catches a representative violation.
- Scenario lifecycle feature scaffold created by the required Round 01 command.

## Non-operational boundary

FTS remains decision-support / non-operational. Do not add live ATC/ATFM write paths, operational command paths, live phraseology, or hidden operational integrations.
