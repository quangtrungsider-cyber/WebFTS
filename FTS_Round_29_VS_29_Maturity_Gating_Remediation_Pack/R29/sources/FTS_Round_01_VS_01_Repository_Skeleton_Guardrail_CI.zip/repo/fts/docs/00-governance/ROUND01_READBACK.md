# Round 01 Readback — VS-01 Repository Skeleton + Guardrail CI

Round 01 starts from the Round 00 repository and hardens it into an executable skeleton.

## Accepted source binding

- DOC-35/DOC-39 remain the source map and decision ledger.
- DOC-36/DOC-37/DOC-38 remain the implementation order, materialization matrix and bootstrap source.
- Tầng 0, Tầng 2, Tầng 5, Tầng 6, Tầng 9, Tầng 10 and SOP-1CODER are used for H0 boundary, deterministic math/time, security, testing, CI and solo-dev workflow.
- Round 00 package is used as the immediate baseline.

## Materialized in this round

- Python package skeleton under `src/fts`.
- API and engine placeholders that are importable and testable.
- OpenAPI/AsyncAPI/state-machine/DDL placeholders.
- Guardrail CI policy and scanner.
- Security and contract smoke tests.
- Feature scaffold for `scenario-lifecycle` under `features/scenario-lifecycle`.

## Preserved boundary

FTS remains decision-support / non-operational. No production service, live integration or operational write path is introduced in Round 01.
