# Guardrail CI Policy — Round 01

This policy materializes the source-package guardrails into executable CI checks. The active machine policy is `tools/guardrails/rules.yaml`.

## Enforced checks

- H0 boundary: no live ATC/ATFM command or write-back path.
- Deterministic time: domain/engine/KPI/report-hash paths must use injected simulation time.
- Deterministic numeric path: trajectory, CD&R, ASM branching and KPI decision paths must use scaled integer/fixed-point values.
- Ruleset authority: separation, wake and LoA minima must come from approved ruleset artifacts, not code constants.
- Data handling: raw L3/L4 payloads and sensitive aviation data must not be logged.
- Secrets: static credentials, private keys and real tokens are forbidden in repository, logs and fixtures.

## Round 01 status

The scanner is intentionally conservative and currently focuses on repository code/config/fixtures/tests. Prose documents are excluded to avoid failing on policy descriptions; they remain governed by docs validation and source-of-truth review.
