# Log Redaction Policy — Round 01

Logs and evidence files must not contain raw L3/L4 payloads, ASTERIX/FDP data, sensitive coordinates or static credentials.

The local gate is:

```bash
python tools/security/log_redaction_scan.py artifacts logs
```

The scan is also called by `make security-evidence` after the static guardrail scan and security tests.
