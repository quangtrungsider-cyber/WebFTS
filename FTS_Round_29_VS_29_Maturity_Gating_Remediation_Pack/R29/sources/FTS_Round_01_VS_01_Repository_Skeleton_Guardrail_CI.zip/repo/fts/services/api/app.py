from __future__ import annotations

from fts import BOUNDARY
from fts.domain.scope_boundary import ScopeBoundary


def healthz() -> dict[str, str | bool]:
    ScopeBoundary().validate()
    return {
        "status": "ok",
        "boundary": BOUNDARY,
        "non_operational": True,
    }
