# API Service Skeleton

Round 01 provides only the minimum importable API skeleton used by tests and future FastAPI wiring.
