# Engine Core Placeholder

The deterministic engine will be materialized in later rounds. Round 01 locks the skeleton and guardrail CI.

Current invariant: deterministic decision paths use scaled integer units and injected simulation time.
