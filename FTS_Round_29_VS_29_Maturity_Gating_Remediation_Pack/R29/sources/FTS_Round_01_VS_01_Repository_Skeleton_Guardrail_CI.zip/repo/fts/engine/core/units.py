from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ScaledDistance:
    value: int
    scale: str


@dataclass(frozen=True)
class ScaledAltitude:
    value: int
    scale: str
