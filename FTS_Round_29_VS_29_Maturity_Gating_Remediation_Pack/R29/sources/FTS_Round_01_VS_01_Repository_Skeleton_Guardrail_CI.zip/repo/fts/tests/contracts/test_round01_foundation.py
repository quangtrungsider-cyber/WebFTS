from fts import BOUNDARY
from fts.domain.scope_boundary import ScopeBoundary
from services.api.app import healthz


def test_boundary_watermark_constant():
    assert BOUNDARY == "Decision-support / Non-operational"


def test_scope_boundary_defaults_are_safe():
    ScopeBoundary().validate()


def test_api_healthz_reports_non_operational_boundary():
    payload = healthz()
    assert payload["status"] == "ok"
    assert payload["non_operational"] is True
    assert payload["boundary"] == BOUNDARY
