from pathlib import Path

from tools.guardrails.scan import run_scan

RULES = Path(__file__).resolve().parents[2] / "tools" / "guardrails" / "rules.yaml"


def _write(root: Path, rel: str, parts: list[str]) -> None:
    p = root / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text("".join(parts), encoding="utf-8")


def _ids_for(tmp_path: Path, rel: str, parts: list[str]) -> set[str]:
    scan_root = tmp_path / "scanroot"
    _write(scan_root, rel, parts)
    report = run_scan(scan_root, RULES, scan_roots=[rel.split("/", 1)[0]])
    return {finding["rule_id"] for finding in report["findings"]}


def test_detects_live_operational_path(tmp_path):
    ids = _ids_for(tmp_path, "services/api/bad.py", ["def bad():\n    ", "write", "_back_to_", "atc", "()\n"])
    assert "FTS-H0-NO-LIVE-WRITEBACK" in ids


def test_detects_wall_clock_in_deterministic_path(tmp_path):
    ids = _ids_for(tmp_path, "engine/core/bad.py", ["import datetime\n", "datetime", ".now", "()\n"])
    assert "FTS-TIME-NO-SYSTEM-TIME-IN-DETERMINISTIC-PATH" in ids


def test_detects_non_scaled_numeric_type(tmp_path):
    ids = _ids_for(tmp_path, "engine/core/bad.py", ["def bad(speed: ", "flo", "at", ") -> int:\n    return 1\n"])
    assert "FTS-NUMERIC-NO-FLOAT-DOUBLE-IN-DETERMINISTIC-PATH" in ids


def test_detects_hard_coded_rule_value(tmp_path):
    ids = _ids_for(tmp_path, "src/fts/domain/bad.py", ["SEP", "ARATION_MIN", "IMA_NM", " = 5\n"])
    assert "FTS-RULES-NO-HARD-CODED-SEPARATION-MINIMA" in ids


def test_detects_payload_logging(tmp_path):
    ids = _ids_for(tmp_path, "services/api/bad.py", ["def bad(payload):\n    ", "log", "ger.info", "(", "payload", ")\n"])
    assert ("FTS-" + "LOG" + "GING-NO-RAW-" + "L" + "3" + "-" + "L" + "4" + "-PAYLOAD") in ids


def test_detects_static_credential(tmp_path):
    ids = _ids_for(tmp_path, "ops/compose/bad.yaml", ["service:\n  ", "api", "_key", ": '", "abcd", "1234", "efgh", "5678", "'\n"])
    assert "FTS-SECRETS-NO-STATIC-CREDENTIALS" in ids
