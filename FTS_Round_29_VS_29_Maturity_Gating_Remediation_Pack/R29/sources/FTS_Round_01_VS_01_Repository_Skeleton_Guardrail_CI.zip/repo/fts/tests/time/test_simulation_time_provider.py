from fts.domain.scenario_lifecycle import ScenarioState, transition
from fts.shared.time_provider import EpochMillis, FrozenSimulationTimeProvider


def test_lifecycle_uses_injected_simulation_time():
    provider = FrozenSimulationTimeProvider(EpochMillis(1_900_000_000_000))
    decision = transition(ScenarioState.DRAFT, ScenarioState.VALIDATED, provider)
    assert decision.accepted is True
    assert int(decision.simulation_time_ms) == 1_900_000_000_000


def test_lifecycle_rejects_invalid_transition():
    provider = FrozenSimulationTimeProvider(EpochMillis(1_900_000_000_000))
    decision = transition(ScenarioState.DRAFT, ScenarioState.RUNNING, provider)
    assert decision.accepted is False
    assert decision.reason == "transition_not_allowed"
