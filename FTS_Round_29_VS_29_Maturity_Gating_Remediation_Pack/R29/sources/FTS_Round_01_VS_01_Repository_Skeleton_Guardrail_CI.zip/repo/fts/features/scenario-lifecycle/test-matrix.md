
# Test Matrix
| Test class | Required? | Test IDs | Command | Evidence |
| --- | --- | --- | --- | --- |
| Unit/component | yes | TBD | pytest tests/unit | junit |
| Contract | if API/event/schema | TBD | make test-contract | junit |
| Integration | if service wiring | TBD | make test-integration | junit/traces |
| Simulation regression | if engine/KPI/CDR | TBD | make test-simulation-regression | hashes |
| Security/privacy | if data/export/log/auth | TBD | make security-evidence | security-evidence.md |
| UI/UX | if frontend/report | TBD | make test-ui-e2e | screenshots |
| Evidence pack | yes | TBD | make evidence-local | zip/manifest |
