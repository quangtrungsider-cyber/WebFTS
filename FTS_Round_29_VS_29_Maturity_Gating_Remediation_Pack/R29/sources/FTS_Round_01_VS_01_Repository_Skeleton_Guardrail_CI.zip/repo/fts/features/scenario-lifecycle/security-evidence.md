
# Security Evidence
- classification_default: L4
- auth_model: RBAC/ABAC TBD
- export_policy: fail-closed until approved
- log_policy: strict redaction
- secret_policy: no secrets in repo/logs/prompts

## Negative tests
| Case | Expected |
| --- | --- |
| Missing clearance | deny |
| Unknown classification | treat as L4 or block |
| Raw export attempt | deny/sanitize |
| Full payload log attempt | scanner fails |
