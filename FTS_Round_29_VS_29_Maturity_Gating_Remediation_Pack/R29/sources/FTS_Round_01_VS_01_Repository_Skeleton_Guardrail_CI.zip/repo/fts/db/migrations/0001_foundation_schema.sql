-- Round 01 foundation migration placeholder.
-- Scenario lifecycle persistence is materialized in Round 02 after mini-spec approval.
CREATE TABLE IF NOT EXISTS fts_foundation_marker (
    id text PRIMARY KEY,
    boundary text NOT NULL,
    created_by_round text NOT NULL
);
