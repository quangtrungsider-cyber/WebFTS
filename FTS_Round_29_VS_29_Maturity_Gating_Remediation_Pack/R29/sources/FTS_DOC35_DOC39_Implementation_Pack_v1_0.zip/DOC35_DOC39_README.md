# FTS DOC-35 / DOC-39 Implementation Pack

Generated on: 2026-05-12

Files:
- DOC-35_FTS_Master_Index_Source_of_Truth_Map_v1_0.docx
- DOC-35_docs-map.yaml
- DOC-35_source-of-truth-matrix.md
- DOC-39_FTS_Decision_Register_VATM_Signoff_Ledger_v1_0.docx
- DOC-39_decision-register.yaml

Usage: import DOC-35_docs-map.yaml and DOC-39_decision-register.yaml into the repo under /docs/00-governance/ and wire docs-lint to them.
