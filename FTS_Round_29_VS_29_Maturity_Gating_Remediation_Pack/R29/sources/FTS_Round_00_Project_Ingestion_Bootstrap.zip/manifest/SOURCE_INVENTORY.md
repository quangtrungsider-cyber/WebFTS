# FTS Round 00 — Source Inventory & Trace Baseline

Generated: 2026-05-12

## 1. Current project source set

| # | File | Role | Size | SHA-256 prefix | Notes |
|---:|---|---|---:|---|---|
| 1 | `AT04_FTS_AppSpec_VATM_v8_5_NextGen_MasterBlueprint.docx` | AppSpec/Master Blueprint v8.5; scope, modules M-01..M-18, non-operational boundary, PoC stress tests. | 70295 | `8cf0b426ff78b595` | 94 paragraphs, 36 tables |
| 2 | `FTS_DOC35_DOC39_Implementation_Pack_v1_0.zip` | DOC-35 source-of-truth map and DOC-39 decision register/signoff ledger. | 121672 | `66a783fb2f2e54de` | 6 entries |
| 3 | `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0.zip` | DOC-36 vertical slice plan, DOC-37 runtime materialization, DOC-38 repository bootstrap. | 212896 | `d9c94a115acd2643` | 62 entries |
| 4 | `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0.zip` | DOC-40..45 evidence pack: mini-specs, fixtures/oracles, licensing, calibration, witness scripts, security accreditation. | 417614 | `d1e74f142ffe1007` | 174 entries |
| 5 | `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0.zip` | DOC-46..51 operational readiness: BOM, runbooks, UX visual acceptance, RTM, change control, legal/procurement/OSS. | 578932 | `3fccdf5703b08031` | 94 entries |
| 6 | `FTS_Quy_trinh_chuan_1_coder_v1_1_Ultimate_Solo_Dev_Survival_Hardened.docx` | Solo-dev SOP; one-coder workflow, mini-spec, evidence handoff, release discipline. | 89414 | `c9b651d8ce1481cf` | 285 paragraphs, 43 tables |
| 7 | `FTS_Tang_0_DOC00_DOC00_1_Quy_tac_van_hanh_Toi_thuong_v2_5.docx` | Tầng 0; hierarchy/source-of-truth, docs-as-code, conflicts/gaps and H0 guardrails. | 63991 | `e7c44916fed4f809` | 105 paragraphs, 40 tables |
| 8 | `FTS_Tang_10_DOC31_DOC34_DevOps_Operations_Reference_Ultimate_Enterprise_Ops_Hardened_v1_1.docx` | Tầng 10; local setup, CI/CD, observability, environment configuration. | 94055 | `c5c2e1bf882572c1` | 737 paragraphs, 32 tables |
| 9 | `FTS_Tang_1_DOC01_DOC04_Hoan_thien_v2_3.docx` | Tầng 1; business context, glossary, C4 context/container. | 388460 | `7e1f063cf1d8f08b` | 312 paragraphs, 25 tables |
| 10 | `FTS_Tang_2_DOC05_DOC07_Hoan_thien_v2_7_Production_Hardened.docx` | Tầng 2; ADR, tech stack, coding standards. | 75177 | `50769ef9707084ac` | 611 paragraphs, 34 tables |
| 11 | `FTS_Tang_3_DOC08_DOC11_5_Interface_Contracts_Hoan_thien_v2_9_Extreme_Scale_Hardened.docx` | Tầng 3; OpenAPI/AsyncAPI, semantic profile, ICD, sequence diagrams. | 65493 | `03cc08110f41e5c3` | 781 paragraphs, 18 tables |
| 12 | `FTS_Tang_4_DOC12_DOC16_Data_Specification_Hoan_thien_v3_1_Extreme_Scale_Data_Layer.docx` | Tầng 4; DDL, data dictionary, state machines, migration/ingest, seed/reference data. | 62343 | `189c00c1705df551` | 468 paragraphs, 27 tables |
| 13 | `FTS_Tang_5_DOC17_DOC19_5_Business_Rules_Calculation_Hoan_thien_v3_3_Ultimate_Logic_Realism_Hardened.docx` | Tầng 5; business rules, calculation logic, error/notification contracts. | 81472 | `8ea11f3b44d1b35a` | 110 paragraphs, 43 tables |
| 14 | `FTS_Tang_6_DOC20_DOC22_Security_Privacy_Implementation_Pack_v1_1_Military_Grade_Hardened.docx` | Tầng 6; security checklist, cryptography/key management, data classification/handling. | 83942 | `73b5c1512dd4c7a6` | 126 paragraphs, 40 tables |
| 15 | `FTS_Tang_7_DOC23_DOC25_Domain_Simulation_Engine_Protocol_Pack_v1_1_Ultimate_Domain_Physics_Hardened.docx` | Tầng 7; simulation engine protocol, aviation dataset governance, V&V/PoC validation. | 87092 | `4298981285bfee79` | 101 paragraphs, 42 tables |
| 16 | `FTS_Tang_8_DOC26_DOC28_Frontend_UX_Implementation_Hoan_thien_v3_1_Extreme_Performance_ATCO_Grade_UI.docx` | Tầng 8; design system, screen specs, i18n baseline, ATCO-grade UI constraints. | 87363 | `cf720393e362071f` | 377 paragraphs, 42 tables |
| 17 | `FTS_Tang_9_DOC29_DOC30_DOC30_5_Testing_Reference_Ultimate_Test_Hardened_v1_1.docx` | Tầng 9; test cases, test data, deterministic time/time-travel controls. | 94007 | `6e581e1e4c64e12a` | 124 paragraphs, 37 tables |
| 18 | `VATM_FTS_BRD_FRD_De_xuat_v1_1_Zero_Loophole_Developer_Ready_05_2026.docx` | BRD/FRD v1.1; business/functional requirements, backlog and acceptance expectations. | 104387 | `b070d12a27cc045a` | 66 paragraphs, 45 tables |

## 2. DOCX heading samples

### AT04_FTS_AppSpec_VATM_v8_5_NextGen_MasterBlueprint.docx
First paragraphs:
- AT04-FTS-APPSPEC-VATM-v8.4-FULLDEEP / ĐẶC TẢ ỨNG DỤNG MÔ PHỎNG THỜI GIAN NHANH (FTS) / phục vụ thiết kế vùng trời, phân chia sector và mô phỏng cụm TSN/VVTS - LTIA
- Phiên bản: v8.4 - Full Deep Feature Decomposition / RFP-Final-Ready
- Đơn vị áp dụng dự kiến: Tổng công ty Quản lý bay Việt Nam (VATM)
Heading sample:
- 1. Tóm tắt điều hành và nguyên tắc hợp nhất v8.1 + v8.2
- 2. Phạm vi, loại trừ và nguyên tắc không vận hành trực tiếp
- 3. Các nội dung lõi v8.1 phải giữ nguyên và làm rõ trong v8.4
- 4. Cấu trúc phân rã yêu cầu 4 lớp
- 5. Module Deep Feature Catalogue
- M-01. Simulation Engine
- M-02. Scenario Manager
- M-03. Aircraft Performance Service

### FTS_Quy_trinh_chuan_1_coder_v1_1_Ultimate_Solo_Dev_Survival_Hardened.docx
First paragraphs:
- TỔNG CÔNG TY QUẢN LÝ BAY VIỆT NAM / VATM FAST-TIME SIMULATION (FTS)
- QUY TRÌNH CHUẨN / CHO 1 CODER PHÁT TRIỂN APP FTS
- Bản v1.1 - Ultimate Solo-Dev Survival Hardened - Implementation-ready - Docs-as-Code - Evidence-driven
Heading sample:
- Mục lục tĩnh
- 10. Thứ tự build toàn hệ thống khuyến nghị cho 1 coder
- 11. Quy trình chuẩn 0-10 cho một feature
- 12. Trình tự code bắt buộc bên trong feature
- 13. Phase 0 Data Readiness và historical ingest
- 14. Protocol riêng cho ASM-App / Auto Separation Minima
- 15. Security, privacy, classification và export control
- 16. Frontend/UX 4D và reporting

### FTS_Tang_0_DOC00_DOC00_1_Quy_tac_van_hanh_Toi_thuong_v2_5.docx
First paragraphs:
- TỔNG CÔNG TY QUẢN LÝ BAY VIỆT NAM / VATM FAST-TIME SIMULATION (FTS)
- TẦNG 0 - QUY TẮC VẬN HÀNH TỐI THƯỢNG
- Hoàn thiện DOC-00 và DOC-00.1 / Docs-as-Code / Zero-Loophole / ASM-App aware / Deterministic Math / Break-Glass Hotfix / AI Traceability / CI Enforcement
Heading sample:
- TẦNG 0 - QUY TẮC VẬN HÀNH TỐI THƯỢNG
- 0. Thông tin kiểm soát tài liệu
- 0.1. Nguồn đã rà soát
- 0.2. Phạm vi của Tầng 0
- Tầng 0 không mô tả nghiệp vụ FTS chi tiết; nó quy định cách đọc, cách ưu tiên, cách xử lý mâu thuẫn, cách vận hành /docs và cách cưỡng chế các quy tắc bằng CI/CD.
- Tầng 0 không thay thế OpenAPI, AsyncAPI, DDL, XState, Business Rules hay Calculation Rules; nó quy định artifact nào thắng khi có mâu thuẫn.
- Tầng 0 áp dụng cho toàn bộ vòng đời: requirement, code, test, review, CI/CD, nghiệm thu, vận hành, hotfix, cập nhật tài liệu và AI-assisted coding.
- Tầng 0 cũng áp dụng cho AI code assistant: AI không được suy diễn nghiệp vụ hàng không ngoài /docs và phải trace code về Business Rule ID.

### FTS_Tang_10_DOC31_DOC34_DevOps_Operations_Reference_Ultimate_Enterprise_Ops_Hardened_v1_1.docx
First paragraphs:
- VATM FTS
- TẦNG 10 - DEVOPS & OPERATIONS REFERENCE
- DOC-31 Local Development Setup Guide | DOC-32 CI/CD Pipeline Specification | DOC-33 Observability Specification | DOC-34 Environment Configuration Reference
Heading sample:
- TẦNG 10 - DEVOPS & OPERATIONS REFERENCE
- DOC-31 Local Development Setup Guide | DOC-32 CI/CD Pipeline Specification | DOC-33 Observability Specification | DOC-34 Environment Configuration Reference
- 0. Thông tin kiểm soát tài liệu
- 0.1. Nguồn đã rà soát và điểm kế thừa
- 0.2. Quy ước bắt buộc của tài liệu
- Tầng 10 không mô tả lại thuật toán FTS; nó định nghĩa cách dựng, chạy, kiểm thử, triển khai, quan sát, đóng gói và chứng minh kết quả bằng evidence.
- 0.3. Mục lục tĩnh
- 1. Tóm tắt điều hành

### FTS_Tang_1_DOC01_DOC04_Hoan_thien_v2_3.docx
First paragraphs:
- TỔNG CÔNG TY QUẢN LÝ BAY VIỆT NAM / VATM FAST-TIME SIMULATION (FTS)
- TẦNG 1 - HIỂU BÀI TOÁN TRƯỚC KHI CODE
- Bộ tài liệu hoàn thiện DOC-01 đến DOC-04 / Docs-as-Code / Developer-Ready / ASM-App aware
Heading sample:
- TẦNG 1 - HIỂU BÀI TOÁN TRƯỚC KHI CODE
- 0. Thông tin kiểm soát tài liệu
- 0.1. Nguồn đã rà soát và nguyên tắc tiếp thu
- 0.2. Nhật ký rà soát và chỉnh lý Tầng 1
- 0.3. Cấu trúc Tầng 1 sau khi hoàn thiện
- 0.4. Gate trước khi chuyển sang Tầng 2
- DOC-01 - FTS Business Context Brief
- 1.1. Front matter đề xuất

### FTS_Tang_2_DOC05_DOC07_Hoan_thien_v2_7_Production_Hardened.docx
First paragraphs:
- VATM FTS
- Tầng 2 - Quyết định kỹ thuật đã được chốt
- DOC-05 Architecture Decision Records | DOC-06 Tech Stack Specification | DOC-07 Coding Standards & Conventions
Heading sample:
- Tầng 2 - Quyết định kỹ thuật đã được chốt
- DOC-05 Architecture Decision Records | DOC-06 Tech Stack Specification | DOC-07 Coding Standards & Conventions
- Mục lục tĩnh
- 1. Định vị Tầng 2 và nguyên tắc biên soạn
- Tầng 2 là lớp biến nhận thức nghiệp vụ ở Tầng 1 và guardrails ở Tầng 0 thành quyết định kỹ thuật có thể code, test, lint và enforce bằng CI/CD. Tầng này không giải thích lại bài toán FTS; nó khóa cách triển khai để dev không tự chọn stack, không tự suy diễn kiến trúc và không đưa các lựa chọn làm gi
- 2. DOC-05 - Architecture Decision Records
- DOC-05 là sổ quyết định kiến trúc của VATM FTS. Nó không phải bài thuyết minh chung; nó là bộ ADR nhỏ, rõ, kiểm được bằng máy, có owner, status, tác động artifact và rule CI. Khi DOC-06 hoặc DOC-07 đưa ra một quyết định kỹ thuật, quyết định đó phải trace ngược được về một ADR accepted hoặc proposed.
- 2.1. Template ADR bắt buộc

### FTS_Tang_3_DOC08_DOC11_5_Interface_Contracts_Hoan_thien_v2_9_Extreme_Scale_Hardened.docx
First paragraphs:
- TONG CONG TY QUAN LY BAY VIET NAM (VATM)
- BO TAI LIEU FTS - TANG 3
- Interface & Interaction Specification
Heading sample:
- DOC-08 OpenAPI 3.1 | DOC-09 AsyncAPI 3.0 | DOC-10 FTS Semantic/KPI/Arrow Profile | DOC-11 Integration Contracts | DOC-11.5 Distributed Sequence Diagrams
- 0. Can cu nguon va pham vi hoan thien
- 0.1. Danh muc tai lieu Tang 3
- 0.2. Delta v2.8 -> v2.9
- 0.3. Guardrails xuyen suot Tang 3
- DOC-08 - OpenAPI 3.1 Specification
- DOC-08 là source of truth cho REST/control-plane API. Nếu narrative text khác OpenAPI, theo Tầng 0 thì OpenAPI thắng. Bản v2.9 biến các ràng buộc extreme-scale thành rule bắt buộc trong contract, không để dev tự quyết định.
- 1.1. OpenAPI skeleton bắt buộc

### FTS_Tang_4_DOC12_DOC16_Data_Specification_Hoan_thien_v3_1_Extreme_Scale_Data_Layer.docx
First paragraphs:
- VATM FTS / TANG 4 - DATA SPECIFICATION / DOC-12 / DOC-13 / DOC-14 / DOC-15 / DOC-16 / Version 3.1 - Extreme Scale Data Layer
- Hoàn thiện Data Layer cho FTS: DDL, Data Dictionary, State Machines, Historical Ingest, Seed & Reference Data.
- Static Table of Contents
Heading sample:
- Static Table of Contents
- DOC-12 - Database Schema Scripts (DDL)
- DOC-13 - Data Dictionary
- DOC-14 - State Machine Specification
- DOC-15 - Data Migration / Historical Ingest Specification
- DOC-16 - Seed Data and Reference Data Package
- 0. Source alignment and Layer 4 scope
- 0.1. Căn cứ nguồn dự án

### FTS_Tang_5_DOC17_DOC19_5_Business_Rules_Calculation_Hoan_thien_v3_3_Ultimate_Logic_Realism_Hardened.docx
First paragraphs:
- VATM FTS / TẦNG 5 - BUSINESS RULES & CALCULATION LOGIC
- DOC-17 | DOC-18 | DOC-19 | DOC-19.5 / Bản v3.3 - Ultimate Logic & Realism Hardened
- Căn cứ: AppSpec FTS VATM v8.5, BRD/FRD Developer-Ready, Tầng 0-4 đã hoàn thiện / Ngày lập: 2026-05-10
Heading sample:
- DOC-17 | DOC-18 | DOC-19 | DOC-19.5 / Bản v3.3 - Ultimate Logic & Realism Hardened
- Mục lục tóm tắt
- 1. Phạm vi Tầng 5 và nguyên tắc khóa logic
- 1.1. Vai trò của Tầng 5
- Tầng 5 biến các capability FTS thành logic tính toán, business rules, notification và error contracts đủ rõ để dev viết unit test mà không phải hỏi nghiệp vụ. Tài liệu này không thay thế OpenAPI, AsyncAPI, DDL, XState; nó mô tả thuật toán và quyết định nghiệp vụ mà các artifact đó phải thực thi.
- 1.2. Bốn tài liệu thuộc Tầng 5
- 1.3. Căn cứ nguồn đã dùng
- 1.4. Non-negotiables của Tầng 5

### FTS_Tang_6_DOC20_DOC22_Security_Privacy_Implementation_Pack_v1_1_Military_Grade_Hardened.docx
First paragraphs:
- TỔNG CÔNG TY QUẢN LÝ BAY VIỆT NAM / VATM FAST-TIME SIMULATION (FTS)
- BỘ TÀI LIỆU TẦNG 6 / SECURITY & PRIVACY IMPLEMENTATION PACK
- DOC-20 Security Implementation Checklist theo feature / DOC-21 Cryptography & Key Management Specification / DOC-22 Data Classification & Handling Rules
Heading sample:
- DOC-20 Security Implementation Checklist theo feature / DOC-21 Cryptography & Key Management Specification / DOC-22 Data Classification & Handling Rules
- 0. Thông tin kiểm soát tài liệu
- 0.1. Căn cứ nguồn và cách hợp nhất
- 0.2. Tóm tắt điều hành
- Tầng 6 là lớp biến các nguyên tắc bảo mật và quyền riêng tư thành các checklist, chính sách mã hóa, quy tắc xử lý dữ liệu và bằng chứng kiểm thử có thể đưa trực tiếp vào CI/CD, FAT/SAT/UAT và hồ sơ nghiệm thu. Tầng này không chỉ là “security review sau cùng”; nó phải được mở ngay khi viết mini-spec 
- DOC-20 buộc mỗi feature chọn archetype bảo mật, liệt kê control ID, chạy negative tests và nộp security evidence trước khi merge.
- DOC-21 khóa thuật toán, key hierarchy, Vault/KMS path, signing, hashing, crypto-shredding và xử lý secret trong môi trường on-prem/air-gapped.
- DOC-22 khóa L1-L4, phân loại theo field/object/event, masking, export, retention, vendor support, AI-tool handling và policy inheritance.

### FTS_Tang_7_DOC23_DOC25_Domain_Simulation_Engine_Protocol_Pack_v1_1_Ultimate_Domain_Physics_Hardened.docx
First paragraphs:
- VATM FTS / TẦNG 7 - FTS DOMAIN / SIMULATION ENGINE
- DOC-23 Simulation Engine & Worker Protocol Specification / DOC-24 Aviation Dataset Governance Specification / DOC-25 PoC, V&V & Operational Validation Protocol
- Phiên bản v1.1 - Ultimate Domain & Physics Hardened / Zero-Loophole Draft
Heading sample:
- DOC-23 Simulation Engine & Worker Protocol Specification / DOC-24 Aviation Dataset Governance Specification / DOC-25 PoC, V&V & Operational Validation Protocol
- Mục lục tĩnh
- 0. Khung tổng thể Tầng 7
- Tầng 7 chuyển toàn bộ yêu cầu nghiệp vụ, kiến trúc, hợp đồng giao tiếp, dữ liệu, rule, bảo mật và testing của FTS thành đặc tả domain hàng không đủ chi tiết để nhà thầu hoặc đội phát triển hiện thực hóa lõi mô phỏng. Đây là tầng khóa “mô phỏng có đúng hay không”, không phải tầng UI, DevOps hay tài l
- 0.1. Bộ tài liệu Tầng 7 đề xuất
- 0.2. Các bất biến Tầng 7
- 0.3. Ranh giới module domain M-01 đến M-18
- 0.4. Sáu điểm mù nghiệp vụ/lõi mô phỏng đã khóa trong v1.1

### FTS_Tang_8_DOC26_DOC28_Frontend_UX_Implementation_Hoan_thien_v3_1_Extreme_Performance_ATCO_Grade_UI.docx
First paragraphs:
- TỔNG CÔNG TY QUẢN LÝ BAY VIỆT NAM (VATM) / BỘ TÀI LIỆU FTS - TẦNG 8 / Frontend & UX Implementation / DOC-26 Design System & 4D Component Library / DOC-27 Screen Specification with Annotated Mockups / DOC-28 Localization String File i18n Baseline / Phiên bản đề xuất: v3.1 - Extreme Performance & ATCO-Grade UI / Zero-Loophole / ASM-App aware / Hà Nội
- Watermark bắt buộc cho toàn bộ UI, báo cáo, export và mockup: “Decision-support / Non-operational”. FTS không phải hệ thống điều hành bay trực tiếp, không phát huấn lệnh ATC, không write-back sang hệ thống operational và không thay thế RTS/MOC/safety approval.
- 0. Thông tin kiểm soát tài liệu
Heading sample:
- 0. Thông tin kiểm soát tài liệu
- 0.1. Căn cứ nguồn dự án đã hợp nhất
- 0.2. Mục lục tĩnh
- DOC-26 - Design System & 4D Component Library
- DOC-27 - Screen Specification with Annotated Mockups
- DOC-28 - Localization String File i18n Baseline
- 0.3. Phạm vi Tầng 8 trong bộ 11 tầng
- 0.4. Nguyên tắc xử lý mâu thuẫn

### FTS_Tang_9_DOC29_DOC30_DOC30_5_Testing_Reference_Ultimate_Test_Hardened_v1_1.docx
First paragraphs:
- TỔNG CÔNG TY QUẢN LÝ BAY VIỆT NAM (VATM)
- VATM FAST-TIME SIMULATION (FTS)
- TẦNG 9 - TESTING REFERENCE
Heading sample:
- TẦNG 9 - TESTING REFERENCE
- DOC-29 Test Case Specification / DOC-30 Test Data Specification / DOC-30.5 Time & Time-Travel Specification
- 0. Thông tin kiểm soát tài liệu
- 0.1. Nguồn đã rà soát và điểm kế thừa
- 0.2. Quy ước bắt buộc của tài liệu
- 0.3. Mục lục tĩnh
- 0.4. Gói vá v1.1 - Ultimate Test-Hardened
- 1. Tóm tắt điều hành

### VATM_FTS_BRD_FRD_De_xuat_v1_1_Zero_Loophole_Developer_Ready_05_2026.docx
First paragraphs:
- TỔNG CÔNG TY QUẢN LÝ BAY VIỆT NAM / VATM FAST-TIME SIMULATION (FTS)
- ĐỀ XUẤT BRD/FRD TƯƠNG ỨNG / Business Requirements Document / Functional Requirements Document / Bản v1.1 Zero-Loophole Developer-Ready - tiếp thu Delta kỹ thuật sâu về Async/Big Data, PoC chống gian lận, AIXM Temporality và Resilience
- Định vị tài liệu
Heading sample:
- Định vị tài liệu
- Thông tin kiểm soát tài liệu
- Tóm tắt điều hành
- 0. Căn cứ nguồn và nguyên tắc diễn giải
- PHẦN A - BRD: YÊU CẦU NGHIỆP VỤ
- 1. Bối cảnh nghiệp vụ và vấn đề cần giải quyết
- 2. Mục tiêu nghiệp vụ và kết quả mong muốn
- 3. Phạm vi nghiệp vụ

## 3. ZIP internal entry summary

### FTS_DOC35_DOC39_Implementation_Pack_v1_0.zip
Entries: 6
- `DOC-35_FTS_Master_Index_Source_of_Truth_Map_v1_0.docx` (50259 bytes)
- `DOC-35_docs-map.yaml` (36675 bytes)
- `DOC-35_source-of-truth-matrix.md` (7654 bytes)
- `DOC-39_FTS_Decision_Register_VATM_Signoff_Ledger_v1_0.docx` (49447 bytes)
- `DOC-39_decision-register.yaml` (52311 bytes)
- `DOC35_DOC39_README.md` (422 bytes)

### FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0.zip
Entries: 62
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/artifacts/DOC35_docs-map_addendum_DOC36_DOC37_DOC38.yaml` (1492 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/artifacts/DOC36_DOC37_DOC38_README.md` (675 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/artifacts/DOC36_implementation-master-plan.md` (11595 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/artifacts/DOC36_milestone-gate-checklist.md` (1486 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/artifacts/DOC36_vertical-slices.yaml` (24560 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/artifacts/DOC37_materialization-status.csv` (8413 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/artifacts/DOC37_runtime-materialization-matrix.csv` (8413 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/artifacts/DOC37_runtime-materialization-matrix.yaml` (21248 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/artifacts/DOC37_validation-commands.yaml` (3106 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/artifacts/DOC38_Makefile` (3642 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/artifacts/DOC38_ci-pipeline-skeleton.yml` (1242 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/artifacts/DOC38_cursorrules.txt` (849 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/artifacts/DOC38_docker-compose.core.yaml` (1638 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/artifacts/DOC38_env.example` (748 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/artifacts/DOC38_env.schema.json` (1638 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/artifacts/DOC38_helm-values-local.yaml` (1281 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/artifacts/DOC38_repo-tree.yaml` (7293 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/artifacts/DOC38_repository-bootstrap-scaffold-pack.md` (5383 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/artifacts/DOC38_repository-bootstrap.md` (7959 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/artifacts/DOC38_scaffold-pack.yaml` (2387 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/artifacts/DOC38_scaffold_feature.py` (5364 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/artifacts/DOC38_stack-lock.yaml` (1050 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/bootstrap/.cursorrules` (849 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/bootstrap/.env.example` (748 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/bootstrap/.github/workflows/ci.yml` (1242 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/bootstrap/Makefile` (3642 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/bootstrap/artifacts/.gitkeep` (1 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/bootstrap/asyncapi/.gitkeep` (1 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/bootstrap/db/migrations/.gitkeep` (1 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/bootstrap/docs/00-governance/.gitkeep` (1 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/bootstrap/docs/05-rules/.gitkeep` (1 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/bootstrap/docs/06-security/.gitkeep` (1 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/bootstrap/evidence/.gitkeep` (1 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/bootstrap/features/.gitkeep` (1 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/bootstrap/fixtures/.gitkeep` (1 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/bootstrap/infra/helm/fts/values.local.yaml` (1281 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/bootstrap/openapi/.gitkeep` (1 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/bootstrap/ops/compose/docker-compose.core.yaml` (1638 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/bootstrap/stack-lock.yaml` (1050 bytes)
- `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0/bootstrap/state-machines/.gitkeep` (1 bytes)
- ... see `manifest/source_manifest.json` for all 62 entries

### FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0.zip
Entries: 174
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/DOC-40_Per-Feature_Mini-Spec_Library_v1_0.docx` (40882 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/DOC-41_Executable_Test_Fixture_Oracle_Pack_v1_0.docx` (39841 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/DOC-42_External_Data_Source_Licensing_Pack_v1_0.docx` (39684 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/DOC-43_Domain_Calibration_Ruleset_Approval_Pack_v1_0.docx` (39231 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/DOC-44_FAT_SAT_UAT_PoC_Witness_Script_Pack_v1_0.docx` (39723 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/DOC-45_Security_Accreditation_Data_Handling_Pack_v1_0.docx` (39824 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/DOC35_docs-map_addendum_DOC40_DOC45.yaml` (1396 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/FTS_DOC40_DOC45_PACK_MANIFEST.yaml` (1883 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/FTS_DOC40_DOC45_Review_Proposal_v1_0.docx` (39161 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/FTS_DOC40_DOC45_Review_Proposal_v1_0.md` (2287 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/PACK_FILE_INVENTORY.yaml` (25008 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/README.md` (831 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/acceptance/dynamic-salt-policy.yaml` (509 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/acceptance/evidence-manifest.schema.json` (591 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/acceptance/pass-fail-thresholds.yaml` (593 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/acceptance/scoring-rubric.yaml` (1355 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/acceptance/sealed-scenario-manifest.yaml` (261 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/acceptance/witness-runbook.yaml` (357 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/calibration/atco-panel-register.yaml` (197 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/calibration/atco-validation-protocol.md` (520 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/calibration/calibration-datasets.yaml` (139 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/calibration/calibration-manifest.yaml` (233 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/calibration/calibration-results-template.md` (275 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/calibration/sensitivity-plan.yaml` (251 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/calibration/target-metrics.yaml` (165 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/docs/40-mini-spec-library/M-01-simulation-engine-4d-trajectory.md` (5094 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/docs/40-mini-spec-library/M-02-scenario-manager-doe.md` (4845 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/docs/40-mini-spec-library/M-03-aircraft-performance-service.md` (4842 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/docs/40-mini-spec-library/M-04-weather4d-service.md` (4828 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/docs/40-mini-spec-library/M-05-separation-wake-cd-r.md` (4731 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/docs/40-mini-spec-library/M-06-aman-dman-flow-behaviour.md` (4609 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/docs/40-mini-spec-library/M-07-workload-complexity.md` (4754 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/docs/40-mini-spec-library/M-08-replay-heatmap-pir.md` (4697 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/docs/40-mini-spec-library/M-09-kpi-reporting.md` (4664 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/docs/40-mini-spec-library/M-10-data-platform-storage.md` (4841 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/docs/40-mini-spec-library/M-11-external-integration-icd-layer.md` (4739 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/docs/40-mini-spec-library/M-12-security-privacy-audit.md` (4848 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/docs/40-mini-spec-library/M-13-ui-ux-4d-visualization.md` (4405 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/docs/40-mini-spec-library/M-14-devops-operations.md` (4687 bytes)
- `FTS_DOC40_DOC45_Implementation_Evidence_Pack_v1_0/docs/40-mini-spec-library/M-15-procurement-poc-contract-controls.md` (4467 bytes)
- ... see `manifest/source_manifest.json` for all 174 entries

### FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0.zip
Entries: 94
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/DOCS/DOC-45_Security_Accreditation_Data_Handling_Pack_v1_1.docx` (41648 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/DOCS/DOC-46_Production_PoC_Environment_Bill_of_Materials_v1_0.docx` (40816 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/DOCS/DOC-47_Ops_Runbook_Pack_v1_0.docx` (40013 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/DOCS/DOC-48_UX_Visual_Acceptance_Design_Asset_Pack_v1_0.docx` (40206 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/DOCS/DOC-49_Traceability_Master_RTM_v1_0.docx` (38983 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/DOCS/DOC-50_Change_Control_ADR_Spec_Freeze_Playbook_v1_0.docx` (39763 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/DOCS/DOC-51_Legal_Procurement_Escrow_OSS_License_Pack_v1_0.docx` (39995 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/DOCS/FTS_DOC45_DOC51_Review_Proposal_v1_0.docx` (38684 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/PACK_FILE_INVENTORY.csv` (12518 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/PACK_MANIFEST.yaml` (15645 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/PACK_VALIDATION_REPORT.md` (181 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/README.md` (680 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/45-security-accreditation/data-classification-matrix.yaml` (929 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/45-security-accreditation/data-handling-register.csv` (529 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/45-security-accreditation/dpia-pia-template.md` (768 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/45-security-accreditation/export-approval-policy.yaml` (540 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/45-security-accreditation/masking-deidentification-policy.yaml` (739 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/45-security-accreditation/security-accreditation-ledger.csv` (722 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/45-security-accreditation/security-control-matrix.yaml` (1555 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/45-security-accreditation/threat-model.yaml` (1897 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/45-security-accreditation/vendor-support-exception.yaml` (668 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/46-environment-bom/backup-target-matrix.yaml` (507 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/46-environment-bom/bill-of-materials.csv` (1272 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/46-environment-bom/environment-bom.yaml` (2694 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/46-environment-bom/helm-values-poc.yaml` (343 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/46-environment-bom/k8s-node-pools.yaml` (1984 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/46-environment-bom/keycloak-realm-requirements.yaml` (292 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/46-environment-bom/network-zone-map.yaml` (861 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/46-environment-bom/siem-integration.yaml` (236 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/46-environment-bom/sizing-assumptions.md` (594 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/46-environment-bom/storage-sizing.yaml` (543 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/46-environment-bom/vault-kms-profile.yaml` (277 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/47-ops-runbooks/command-index.md` (492 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/47-ops-runbooks/incident-severity-matrix.yaml` (588 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/47-ops-runbooks/runbook-index.yaml` (2945 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/47-ops-runbooks/runbooks/airgap_update.md` (822 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/47-ops-runbooks/runbooks/backup_restore.md` (841 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/47-ops-runbooks/runbooks/cert_expiry.md` (802 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/47-ops-runbooks/runbooks/cve_db_update.md` (792 bytes)
- `FTS_DOC45_DOC51_Operational_Readiness_Pack_v1_0/repo-ready/docs/47-ops-runbooks/runbooks/db_failover.md` (775 bytes)
- ... see `manifest/source_manifest.json` for all 94 entries
