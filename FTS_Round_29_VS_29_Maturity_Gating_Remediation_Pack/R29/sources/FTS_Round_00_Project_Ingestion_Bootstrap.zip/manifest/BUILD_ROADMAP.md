# FTS Sequential Build Roadmap — derived from DOC-36

Generated: 2026-05-12

## Operating rules for all rounds

- WIP limit: one vertical slice per implementation round.
- Contract-first before public API/event/state/rule code.
- Docs-as-code and evidence-driven outputs are mandatory.
- H0 guardrails are non-negotiable: decision-support/non-operational, no live ATC/ATFM write-back, watermark on UI/report/export, no hard-coded minima, no L3/L4 leak.
- Deterministic core: no wall-clock business logic and no float/double in decision paths.
- At the end of every round: release note, changelog, evidence manifest, full next-round plan and zip package.

## Phases

| Phase | Name | Exit / focus |
|---|---|---|
| 0 | Docs/runtime readiness | DOC-35/DOC-39/DOC-37/DOC-38 present, SPEC-GAPS/CONFLICTS ready, local setup log created. |
| 1 | Platform skeleton + guardrails CI | Docs lint, OpenAPI/AsyncAPI/schema validation, Semgrep/static scanners, Makefile targets. |
| 2 | Data foundation M-10 | DDL/Data Dictionary, migration dry-run, seed/reference manifest, object manifest smoke. |
| 3 | Scenario Manager M-02 | Create/validate/freeze/run state machine + API + tests pass. |
| 4 | Data import/QA M-11/M-10 | Direct-to-storage upload, import job, QA report, quarantine, manifest. |
| 5 | Performance/weather/trajectory M-03/M-04/M-01 | Deterministic trajectory fixture, performance fallback limitation, weather sample tests. |
| 6 | Separation/CD&R/ASM-App M-05 | DETECT_ONLY trước, RECOMMEND_ONLY, AUTO_APPLY_SIMULATED chỉ sau guard pass. |
| 7 | Async orchestration/worker pool M-14 | REST 202, progress, cancel/resume, DLQ, scenario.run.completed single emission. |
| 8 | Workload/KPI/report M-07/M-09 | KPI with CI/limitation, report manifest, export schemas. |
| 9 | Replay/UI M-08/M-13 | Watermark, 2D/3D/4D replay, trace tooltip, UI smoke/perf evidence. |
| 10 | Security/export/audit M-12 | L1-L4, ABAC negative tests, masked export, sanitized support, hash-chain audit. |
| 11 | PoC/V&V/DevOps hardening M-15/M-14 | FAT/SAT/UAT/PoC pack, signed images/SBOM, observability, runbook. |

## Vertical slices

| Slice | Priority | Size | Name | Depends on | DoD summary |
|---|---|---|---|---|---|
| VS-00 | P0 | S | Foundation readback, source map and runtime truth gate | - | foundation-readback.md có chữ ký nội bộ; SPEC-GAPS/CONFLICTS templates tồn tại; Mọi P0 unresolved có safe default block/disable |
| VS-01 | P0 | M | Repository skeleton and guardrail CI | VS-00 | make doctor pass; make docs-validate pass; Semgrep no-float/no-system-time/no-live-writeback enabled |
| VS-02 | P0 | L | Data foundation: DDL, dictionary, object manifest and audit seed | VS-01 | Migration dry-run pass; Data dictionary validates; Object put/get + hash manifest pass |
| VS-03 | P0 | L | Scenario lifecycle: create, validate, freeze and hash | VS-02 | Create/validate/freeze/run request routes pass contract tests; Frozen scenario immutable; Hash/provenance generated and stored |
| VS-04 | P0 | L | Direct-to-storage import and quarantine QA | VS-02, VS-03 | Pre-signed upload issued; Import job status and QA report created; Dirty data quarantined |
| VS-05 | P0 | M | AIRAC, rule-set and reference data registry | VS-02, VS-04 | Scenario references exact AIRAC and rule-set hash; Cross-AIRAC policy enforced; No hard-coded minima scanner passes |
| VS-06 | P0 | L | Aircraft performance and Weather4D sampling | VS-04, VS-05 | Performance lookup pass/fallback audited; Weather interpolation tests pass; No silent defaults |
| VS-07 | P0 | XL | Deterministic 4D trajectory core minimal | VS-06 | Trajectory fixture reproduces by hash; Invariants pass; No system time/no float scanner pass |
| VS-08 | P0 | L | Async run orchestration, worker checkpoint and scatter-gather | VS-03, VS-07 | 202/control-plane works; Cancel/resume/DLQ tested; scenario.run.completed emitted once |
| VS-09 | P0 | L | Separation minima resolver and conflict detection DETECT_ONLY | VS-05, VS-07 | Conflict detection matches fixtures; DETECT_ONLY mode cannot alter trajectory; Report limitation shows rule-set |
| VS-10 | P0 | XL | Simulated CD&R / ASM-App guard chain | VS-09, VS-07 | RECOMMEND_ONLY pass; AUTO_APPLY_SIMULATED enabled only when all guards pass; Discarded action logged |
| VS-11 | P1 | L | Workload and complexity service | VS-09 | Workload series generated; Sensitivity +/-10% available; Limitation shown if panel not approved |
| VS-12 | P1 | L | KPI package, comparison and CI95 | VS-08, VS-11 | KPI package validates; CI95 shown or limitation; Comparison report no hidden assumptions |
| VS-13 | P0 | L | Report/export package with watermark, lineage and manifest | VS-12 | Report preview/package includes watermark; ABAC/masking negative tests pass; Hash/audit event created |
| VS-14 | P1 | XL | Replay, heatmap and PIR UI shell | VS-08, VS-13 | Scenario list/run/replay/report flows render; Watermark visible; No forbidden live lexicon |
| VS-15 | P0 | XL | Security baseline: ABAC, masking, audit hash-chain and support package | VS-02, VS-13, VS-14 | ABAC negative tests pass; Masking/export fail closed; Support package sanitized |
| VS-16 | P1 | L | Observability, release evidence and air-gap package skeleton | VS-01, VS-08, VS-15 | Release evidence pack created; SBOM/signature logs exist; Helm lint/dry-run pass |
| VS-17 | P1 | XL | PoC sealed/V&V witness rehearsal | VS-10, VS-13, VS-14, VS-16 | Original + salted runs produce expected evidence; Evaluator manifest created; No-go criteria enforce H0/security/determinism |
| VS-18 | P2 | L | Extended surface/environment/AAM option readiness | VS-12, VS-14 | Option fixtures and schema stubs exist; Core roadmap unaffected; Limitations explicit |

## Round packaging standard

Every round zip must include:

- `release/RELEASE_NOTE.md`
- `release/CHANGELOG.md`
- `release/NEXT_ROUND_PLAN.md`
- `release/EVIDENCE_MANIFEST.yaml`
- `repo/fts/...` implementation delta
- `evidence/...` validation logs, generated manifests, screenshots if UI is touched
- `manifest/source_manifest.json` and updated traceability references
