# VATM FTS — Round 00 Bootstrap Repository

Generated: 2026-05-12

This repository scaffold is initialized from the FTS source package and DOC-38 bootstrap pack. It is not a production-ready app yet. It is the Round 00 foundation for sequential implementation.

## Start here

```bash
make doctor
make docs-validate
make scaffold-feature NAME=scenario-lifecycle SIZE=L SLICE=VS-03
```

## Current status

- Source inventory created.
- DOC-35/DOC-36/DOC-37/DOC-39 machine artifacts copied to `docs/00-governance/`.
- Minimal validators added so the repository can prove governance artifacts are loadable.
- Application services are placeholders for the next implementation rounds.

## Non-operational boundary

FTS is decision-support / non-operational. Do not add live ATC/ATFM write-back paths.
