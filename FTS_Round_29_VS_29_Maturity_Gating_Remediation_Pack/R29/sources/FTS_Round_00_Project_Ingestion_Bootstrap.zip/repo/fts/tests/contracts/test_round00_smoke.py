def test_round00_smoke():
    assert True
