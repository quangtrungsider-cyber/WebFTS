#!/usr/bin/env python3
import argparse, yaml, sys
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('path'); args=ap.parse_args()
    data=yaml.safe_load(Path(args.path).read_text(encoding='utf-8'))
    decisions=data.get('decisions') or []
    statuses=set((data.get('status_definitions') or {}).keys())
    errors=[]
    if not decisions: errors.append('decisions missing')
    ids=[]
    for d in decisions:
        ids.append(d.get('id'))
        if d.get('status') not in statuses: errors.append(f"{d.get('id')} unknown status {d.get('status')}")
        if not d.get('criticality'): errors.append(f"{d.get('id')} missing criticality")
    if len(ids)!=len(set(ids)): errors.append('duplicate decision id')
    if errors:
        print('decision-register invalid:', '; '.join(errors), file=sys.stderr); return 2
    print(f'decision-register ok: {len(decisions)} decisions; open={sum(1 for d in decisions if d.get("status") == "OPEN")}')
    return 0
if __name__=='__main__': raise SystemExit(main())
