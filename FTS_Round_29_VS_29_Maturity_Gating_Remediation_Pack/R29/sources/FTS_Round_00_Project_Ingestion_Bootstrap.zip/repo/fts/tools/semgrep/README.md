# Guardrail rules placeholder

Round 01 should add concrete rules for:

- no live ATC/ATFM write-back
- no system time in domain logic
- no float/double in decision paths
- no hard-coded separation minima
- no secrets or raw L3/L4 logging
