#!/usr/bin/env python3
import argparse, yaml, sys
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('path'); args=ap.parse_args()
    data=yaml.safe_load(Path(args.path).read_text(encoding='utf-8'))
    slices=data.get('vertical_slices') or []
    errors=[]
    if not slices: errors.append('vertical_slices missing')
    ids=[s.get('id') for s in slices]
    if len(ids)!=len(set(ids)): errors.append('duplicate slice id')
    known=set(ids)
    for s in slices:
        for dep in s.get('depends_on') or []:
            if dep not in known: errors.append(f"{s.get('id')} unknown dependency {dep}")
        if not s.get('priority'): errors.append(f"{s.get('id')} missing priority")
    if errors:
        print('vertical-slices invalid:', '; '.join(errors), file=sys.stderr); return 2
    print(f'vertical-slices ok: {len(slices)} slices')
    return 0
if __name__=='__main__': raise SystemExit(main())
