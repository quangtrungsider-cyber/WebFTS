#!/usr/bin/env python3
import argparse, yaml, sys
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('path'); args=ap.parse_args()
    p=Path(args.path); data=yaml.safe_load(p.read_text(encoding='utf-8'))
    errors=[]
    if not isinstance(data, dict): errors.append('not a yaml map')
    if not data.get('documents'): errors.append('documents missing')
    if not data.get('source_package_manifest'): errors.append('source_package_manifest missing')
    ids=[d.get('doc_id') for d in data.get('documents',[]) if isinstance(d,dict)]
    if len(ids)!=len(set(ids)): errors.append('duplicate doc_id')
    if errors:
        print('docs-map invalid:', '; '.join(errors), file=sys.stderr); return 2
    print(f'docs-map ok: {len(ids)} documents')
    return 0
if __name__=='__main__': raise SystemExit(main())
