#!/usr/bin/env python3
import argparse, yaml, sys
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('path'); args=ap.parse_args()
    data=yaml.safe_load(Path(args.path).read_text(encoding='utf-8'))
    entries=data.get('entries') or []
    lifecycle={x.get('state') for x in data.get('lifecycle',[]) if isinstance(x,dict)}
    errors=[]
    if not entries: errors.append('entries missing')
    ids=[e.get('id') for e in entries]
    if len(ids)!=len(set(ids)): errors.append('duplicate materialization id')
    for e in entries:
        if e.get('status') not in lifecycle: errors.append(f"{e.get('id')} unknown status {e.get('status')}")
        if not e.get('repo_path'): errors.append(f"{e.get('id')} missing repo_path")
    if errors:
        print('materialization invalid:', '; '.join(errors), file=sys.stderr); return 2
    print(f'materialization ok: {len(entries)} entries')
    return 0
if __name__=='__main__': raise SystemExit(main())
