#!/usr/bin/env python3
import argparse, zipfile
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--release', default='local-dev'); ap.add_argument('--output', default='artifacts/release-evidence-pack.zip'); ap.add_argument('--profile', default='core')
    args=ap.parse_args(); out=Path(args.output); out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('release.txt', f'release={args.release}\nprofile={args.profile}\n')
        for p in Path('artifacts').glob('*'):
            if p.is_file() and p != out:
                z.write(p, 'artifacts/'+p.name)
    print(f'wrote {out}')
if __name__=='__main__': main()
