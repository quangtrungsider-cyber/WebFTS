#!/usr/bin/env python3
import argparse, zipfile
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--profile', default='core'); ap.add_argument('--output', default='artifacts/local-evidence.zip'); args=ap.parse_args()
    out=Path(args.output); out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in Path('artifacts').glob('*'):
            if p.is_file() and p != out:
                z.write(p, p.name)
        z.writestr('README.txt', f'Local evidence pack for profile={args.profile}\n')
    print(f'wrote {out}')
if __name__=='__main__': main()
