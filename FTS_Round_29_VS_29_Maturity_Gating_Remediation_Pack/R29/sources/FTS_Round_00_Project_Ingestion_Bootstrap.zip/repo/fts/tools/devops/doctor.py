#!/usr/bin/env python3
import argparse, shutil, sys, platform, json
from pathlib import Path

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--profile', default='core')
    args = ap.parse_args()
    root = Path.cwd()
    required = ['docs/00-governance/docs-map.yaml','docs/00-governance/decision-register.yaml','docs/00-governance/vertical-slices.yaml','docs/00-governance/runtime-materialization-matrix.yaml','Makefile']
    missing = [p for p in required if not (root/p).exists()]
    report = {
        'profile': args.profile,
        'python': sys.version.split()[0],
        'platform': platform.platform(),
        'docker_present': shutil.which('docker') is not None,
        'git_present': shutil.which('git') is not None,
        'missing_required_files': missing,
    }
    Path('artifacts').mkdir(exist_ok=True)
    Path('artifacts/doctor-report.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    if missing:
        print('doctor failed; missing:', ', '.join(missing), file=sys.stderr)
        return 2
    print('doctor ok:', json.dumps(report, ensure_ascii=False))
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
