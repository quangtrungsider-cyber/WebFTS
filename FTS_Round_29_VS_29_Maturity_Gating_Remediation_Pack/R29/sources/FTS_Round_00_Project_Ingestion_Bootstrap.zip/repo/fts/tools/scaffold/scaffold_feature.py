#!/usr/bin/env python3
"""Generate a VATM FTS feature scaffold.
Usage: python tools/scaffold/scaffold_feature.py --name scenario-lifecycle --size L
"""
from __future__ import annotations
import argparse, os, re, textwrap, yaml
from datetime import datetime, timezone

SIZES = {"XS", "S", "M", "L", "XL"}

def slugify(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")

def write(path: str, text: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text.rstrip() + "\n")

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True)
    ap.add_argument("--size", default="M", choices=sorted(SIZES))
    ap.add_argument("--slice", default="VS-xx")
    args = ap.parse_args()
    name = slugify(args.name)
    base = os.path.join("features", name)
    now = datetime.now(timezone.utc).isoformat()

    mini = f"""
# Feature Mini-Spec — {name}

- feature_id: FEAT-{name}
- slice_id: {args.slice}
- size: {args.size}
- created_at_utc: {now}
- boundary: Decision-support / Non-operational
- status: DRAFT

## 1. Scope
Describe exactly what is included.

## 2. Out of scope
List anything that would imply live ATC/ATFM write-back, live instruction, hidden data access, or unapproved rule-set.

## 3. Source binding
| Concern | Artifact / DOC | ID/path | Status |
| --- | --- | --- | --- |
| H0 guardrail | DOC-00 / DOC-35 | TBD | TBD |
| Decision blocker | DOC-39 | TBD | TBD |
| API/Event/DDL/State | DOC-37 matrix | TBD | TBD |
| Business/calculation rule | DOC-17/18 | BR-FTS-TBD | TBD |
| Security/data handling | DOC-20/21/22 | TBD | TBD |
| Test/fixture | DOC-29/30/30.5 | TC-TBD | TBD |

## 4. Data classification
Default unknown data to L4 until confirmed.

## 5. Implementation order
1. Materialize missing artifact.
2. Write failing tests.
3. Implement domain/application logic.
4. Wire API/event/persistence.
5. Add UI/observability/security evidence if applicable.

## 6. Stop conditions
- Missing rule/threshold/classification/license/fallback.
- Required artifact missing from DOC-37.
- P0 decision pending in DOC-39.
- Test/evidence cannot be produced.
"""
    trace = """
# TRACEABILITY
| Requirement / BR / Decision | API/Event/Table/Screen | Code path | Test ID | Evidence |
| --- | --- | --- | --- | --- |
| TBD | TBD | TBD | TBD | TBD |
"""
    test_matrix = """
# Test Matrix
| Test class | Required? | Test IDs | Command | Evidence |
| --- | --- | --- | --- | --- |
| Unit/component | yes | TBD | pytest tests/unit | junit |
| Contract | if API/event/schema | TBD | make test-contract | junit |
| Integration | if service wiring | TBD | make test-integration | junit/traces |
| Simulation regression | if engine/KPI/CDR | TBD | make test-simulation-regression | hashes |
| Security/privacy | if data/export/log/auth | TBD | make security-evidence | security-evidence.md |
| UI/UX | if frontend/report | TBD | make test-ui-e2e | screenshots |
| Evidence pack | yes | TBD | make evidence-local | zip/manifest |
"""
    sec = """
# Security Evidence
- classification_default: L4
- auth_model: RBAC/ABAC TBD
- export_policy: fail-closed until approved
- log_policy: strict redaction
- secret_policy: no secrets in repo/logs/prompts

## Negative tests
| Case | Expected |
| --- | --- |
| Missing clearance | deny |
| Unknown classification | treat as L4 or block |
| Raw export attempt | deny/sanitize |
| Full payload log attempt | scanner fails |
"""
    gaps = """
# Open Gaps and Conflicts
## SPEC-GAPS
None yet.

## RUNTIME-GAPS
None yet.

## CONFLICTS
None yet.
"""
    manifest = {
        "schema_version": "1.0",
        "feature": name,
        "slice_id": args.slice,
        "size": args.size,
        "boundary": "Decision-support / Non-operational",
        "evidence": {
            "commands_run": [],
            "logs": [],
            "screenshots": [],
            "hashes": [],
            "open_gaps": []
        }
    }
    write(os.path.join(base, "mini-spec.md"), mini)
    write(os.path.join(base, "TRACEABILITY.md"), trace)
    write(os.path.join(base, "test-matrix.md"), test_matrix)
    write(os.path.join(base, "security-evidence.md"), sec)
    write(os.path.join(base, "open-gaps-and-conflicts.md"), gaps)
    write(os.path.join(base, "ai-review.md"), "# AI Review\n\n- AI used: no\n- Prompt contained sensitive data: no\n- Human review completed: TBD\n")
    write(os.path.join(base, "release-evidence", "manifest.yaml"), yaml.safe_dump(manifest, allow_unicode=True, sort_keys=False))
    write(os.path.join(base, "evidence", ".gitkeep"), "")
    if args.size in {"M", "L", "XL"}:
        write(os.path.join(base, "daily-wip-handoff.md"), "# Daily WIP Handoff\n\n- last safe commit:\n- how to resume:\n- open blockers:\n")
    if args.size in {"L", "XL"}:
        write(os.path.join(base, "risk-register.md"), "# Risk Register\n\n| Risk | Severity | Mitigation | Owner |\n| --- | --- | --- | --- |\n")
        write(os.path.join(base, "runbook-fragment.md"), "# Runbook Fragment\n\n- health check:\n- rollback/forward-fix:\n- evidence path:\n")
        write(os.path.join(base, "rubber-duck-video-link.md"), "# Rubber Duck Video Review\n\n- link:\n- PR:\n- reviewer:\n")
    print(f"Created {base}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
