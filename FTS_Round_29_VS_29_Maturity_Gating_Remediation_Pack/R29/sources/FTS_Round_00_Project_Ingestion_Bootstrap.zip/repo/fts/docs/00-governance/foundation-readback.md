# Foundation Readback — Round 00

Generated: 2026-05-12

## Accepted operating baseline

FTS development will proceed sequentially from the source package using the following baseline:

- AppSpec v8.5 and BRD/FRD v1.1 define product scope and business/functional intent.
- Tầng 0 defines operating guardrails and conflict/gap discipline.
- Tầng 1–10 define context, architecture, contracts, data, rules, security, domain engine, UX, testing and operations.
- DOC-35 and DOC-39 are the meta-controls for source map and signoff/decision status.
- DOC-36, DOC-37 and DOC-38 define implementation order, materialization states and repository bootstrap.
- DOC-40..45 and DOC-46..51 extend acceptance, evidence, operational readiness, RTM and change control.

## Round policy

At the end of every session, produce a zip with release note, changelog, evidence manifest and a full next-round plan.

## Current round outcome

Round 00 created source inventory, source manifest, sequential roadmap, governance templates and a bootstrap repo skeleton derived from DOC-38.

## Next round target

Round 01 should execute VS-01: Repository skeleton and guardrail CI, hardening `make doctor`, `make docs-validate`, `make scaffold-feature`, and basic guardrail scans.
