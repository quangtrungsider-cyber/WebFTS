# DOC-35 Source-of-Truth Matrix

Generated on: 2026-05-12

| Concern ID | Concern | Authoritative Source | Runtime Artifact | Guardrail |
|---|---|---|---|---|
| scope_boundary | Ranh giới FTS: offline decision-support, no live ATC/ATFM, no write-back | APPSPEC-v8.5, DOC-00, DOC-01 | requirements-index.yaml / H0 guardrail checklist | Không dùng UI/story/report/SOP để mở rộng phạm vi vận hành. |
| requirements_brd_frd | BRD/FRD, business objectives, features, BDD/UAT | BRD-FRD-v1.1, APPSPEC-v8.5 | brd-frd-requirements.yaml, bdd-acceptance-index.yaml | Nếu BRD/FRD mâu thuẫn H0 hoặc contracts runtime, log conflict và ưu tiên nguồn cao hơn. |
| terminology | Thuật ngữ nghiệp vụ/kỹ thuật/song ngữ | DOC-02 | glossary.yaml | Không tự đặt thuật ngữ mới trong code/UI/report nếu chưa cập nhật glossary/i18n. |
| system_context | Actor, external systems, trust boundaries | DOC-03 | c4-context.mmd | Không thêm external integration hoặc write-back ngoài context map. |
| container_ownership | Service/container/data ownership | DOC-04, DOC-06 | c4-container.mmd, service-ownership-matrix.yaml | Không service nào ghi trực tiếp DB của service khác. |
| architecture_decision | ADR, kiến trúc, supersede/deprecate | DOC-05 | adr-index.yaml, adrs/*.md | Không đổi architecture/stack bằng code diff nếu chưa có ADR. |
| tech_stack | Runtime/framework/database/broker/storage/tools | DOC-06 | stack-lock.yaml | Không tự chọn framework/tool khác vì tiện. |
| coding_guardrails | Coding standards, deterministic math, no system time, AI rules | DOC-07, DOC-00.1 | pre-commit, semgrep, .cursorrules | Không để guardrail chỉ là văn xuôi; phải có enforcement hoặc checklist. |
| http_api | HTTP endpoints, DTO, status, auth, pagination | DOC-08 | contracts/openapi/fts-openapi.v1.yaml | Code không tạo endpoint/field/status ngoài OpenAPI. |
| events_topics | Kafka/event contracts, payload, claim-check, DLQ | DOC-09 | contracts/asyncapi/fts-asyncapi.v1.yaml | Consumer không tự định nghĩa payload/topic. |
| semantic_kpi_arrow | KPI names, units, Arrow IPC, binary payload | DOC-10, DOC-17 | kpi-catalog.yaml, arrow-ipc-schema.json | Không đổi unit/format mà không version schema/KPI. |
| external_icd_mocks | External ICDs, mock servers, contract tests | DOC-11 | contracts/icd/*.yaml, mocks/* | Không nối hệ thật ở dev nếu chưa có mock/ICD approved. |
| sequence_behaviour | Distributed sequence happy/failure/alt paths | DOC-11.5 | sequence/*.mmd | Không bỏ qua alt path, retry, compensation hoặc DLQ nếu sequence đã nêu. |
| database_schema | DDL, constraints, indexes, migrations | DOC-12 | db/migrations/*.sql | Không sửa DB bằng script ngoài migration/DDL. |
| data_dictionary | Field meanings, units, classification, ownership | DOC-13, DOC-22 | data-dictionary.yaml | Không thêm field vào payload/DB nếu dictionary chưa có. |
| state_machine | Lifecycle, transition guards, frozen/archived states | DOC-14 | state-machines/*.xstate.json | State machine thắng prose khi mâu thuẫn. |
| historical_ingest | Historical ingest, QA, quarantine, reprocess | DOC-15, DOC-24 | ingest-pipelines/*.yaml, quarantine-rules.yaml | Không import dữ liệu lỗi critical vào scenario trừ khi override được phê duyệt. |
| seed_reference | Seed/reference data, code lists, AIRAC reference | DOC-16, DOC-24 | reference-data/*.yaml, seed/*.yaml | Không hard-code airport/sector/route/procedure list trong source code. |
| calculation_rules | Simulation/KPI formulas, methodology, tolerance | DOC-17 | calculation-rules.yaml | Không code công thức nếu thiếu rule/KPI ID. |
| business_rules | BR-FTS rules, thresholds, guardrails | DOC-18 | business-rules.yaml, br-index.json | Mọi if/else nghiệp vụ phải trace BR-ID. |
| notifications | Notification, alert, severity, recipients | DOC-19 | notifications.yaml | Frontend/backend không tự tạo message nghiệp vụ ngoài notification spec. |
| errors | Global error code dictionary | DOC-19.5 | error-codes.yaml | Backend chỉ trả error code đã định nghĩa; UI map qua i18n. |
| security_feature | Feature-level security checklist/evidence | DOC-20 | security-checklist.yaml | Feature chưa có security evidence không qua gate. |
| crypto_key | Crypto, key, signing, hashing, crypto-shredding | DOC-21 | crypto-policy.yaml, vault-paths.yaml | Không dùng crypto home-grown, static secret, hoặc key path tự chế. |
| classification_handling | Data classification L1-L4, export/masking/retention | DOC-22 | classification-policy.yaml, retention-policy.yaml | Dữ liệu thiếu nhãn xử lý như L4_PENDING_REVIEW và fail closed. |
| engine_protocol | Simulation engine/worker protocol, checkpoint/resume | DOC-23 | worker-protocol.yaml, run-manifest.schema.json | Không thay đổi worker lifecycle mà không update state/contract/test. |
| dataset_governance | Aviation dataset source/AIRAC/effective time/lineage | DOC-24 | dataset-manifest.schema.json | Không chạy scenario nếu dataset manifest/hash/validity thiếu. |
| poc_validation | PoC, V&V, operational validation, anti-gaming | DOC-25, DOC-29, DOC-30 | poc-witness-script.yaml | Không nghiệm thu bằng demo giấy; phải có sealed scenario/evidence. |
| design_system | UI tokens/components/accessibility/storybook | DOC-26 | tokens.json, component-contracts.yaml | Component không chứa text hard-code hoặc logic nghiệp vụ. |
| screen_contracts | Routes/screens/fields/API/event mapping/mockups | DOC-27, DOC-08, DOC-22 | screen-contracts.yaml | Nếu screen muốn render L3/L4 nhưng policy chặn, UI fail-closed. |
| i18n_text | vi-VN/en-US strings, watermark, error text | DOC-28, DOC-19.5 | i18n/*.json | Không hard-code user-facing text. |
| test_cases | Test cases/suite matrix/acceptance evidence | DOC-29 | test-cases.yaml, gherkin/*.feature | Feature chưa có negative/auth/time/audit tests tương ứng không qua gate. |
| fixtures_oracles | Test data, fixture manifest, expected oracle/hash | DOC-30 | fixtures/dataset-manifest.yaml | Không dùng dữ liệu thật nhạy cảm làm fixture nếu chưa masking/approval. |
| time | TimeProvider, MockTimeProvider, time-travel, no system time | DOC-30.5, DOC-07 | time-provider-contract.yaml, time-lint-rules.yaml | Không gọi Date.now()/datetime.now()/time.time() trong domain/engine/KPI/report hash. |
| local_dev | Local bootstrap, compose, env examples, smoke | DOC-31 | Makefile, docker-compose, .env.example | Không sửa tay env/secret không có example/validation. |
| pipeline_release | CI/CD gates, SBOM/signature, air-gapped package | DOC-32, DOC-07, DOC-20 | ci/*.yaml, release-manifest.schema.json | Không release unsigned image/no SBOM/no provenance. |
| observability | Metrics/logs/traces/alerts/SIEM evidence | DOC-33 | observability/*.yaml, dashboards/*.json | Feature high-impact không có telemetry/alert route là blocker. |
| environment_config | Env matrix, Helm, secrets/config ownership | DOC-34 | env-matrix.yaml, helm/values*.yaml | Không hard-code config; config drift phải fail gate. |
| solo_dev_process | Thứ tự đọc, mini-spec, feature workflow, evidence | SOP-1CODER, DOC-35 | mini-spec-template.md, traceability-template.md | SOP không thay thế authority source; chỉ điều phối thao tác. |
| decision_signoff | Open decisions, sign-off ledger, authority chain | DOC-39 | decision-register.yaml, approval-ledger.yaml | Không implement quyết định P0/P1 nếu trạng thái vẫn OPEN. |
