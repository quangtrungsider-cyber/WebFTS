# DOC-36 — Implementation Master Plan & Vertical Slice Roadmap cho VATM FTS

**Phiên bản:** v1.0  
**Ngày:** 2026-05-12  
**Trạng thái:** Generated draft / chờ VATM review & sign-off  
**Boundary:** Decision-support / Non-operational

## 1. Mục đích

DOC-36 chuyển bộ AppSpec, BRD/FRD, Tầng 0-10, DOC-35 và DOC-39 thành kế hoạch triển khai tuần tự theo vertical slice. Tài liệu này dành cho mô hình 1 coder hoặc một nhóm rất nhỏ: coder không phải tự suy luận build gì trước, mở tài liệu nào, tạo artifact gì, test gì và dừng ở đâu khi gặp gap.

DOC-36 không thay thế DOC-35/DOC-39. Nếu roadmap này mâu thuẫn với hierarchy/source-of-truth hoặc decision đã ký, DOC-35/DOC-39 thắng. Nếu một slice phụ thuộc artifact chưa materialize trong DOC-37, coder phải ghi `RUNTIME-GAP` và chỉ làm phần không phụ thuộc gap.

## 2. Nguyên tắc triển khai

- WIP limit = 1 vertical slice đang code; không nhảy giữa engine, UI, data và DevOps trong cùng một buổi nếu chưa đóng evidence.
- Contract-first: OpenAPI/AsyncAPI/DDL/XState/BR/Error/i18n phải có trước code public API/event/state/rule.
- Docs-as-code first: DOCX là baseline biên soạn; repo artifact máy kiểm được mới là runtime truth.
- Evidence-driven: mỗi slice có DoR, DoD, tests và evidence pack riêng.
- H0 luôn thắng: không live ATC/ATFM write-back, mọi UI/report/export có watermark, không hard-code minima, không lộ L3/L4.
- Security fail-closed: thiếu classification/clearance/export policy thì block hoặc treat as L4.
- Deterministic core: engine/CD&R/KPI không dùng wall-clock hoặc float/double trong decision path.

## 3. Module map M-01 đến M-18

| Module | Tên / mục tiêu | Phạm vi | Coder đọc trước | Điểm khóa |
| --- | --- | --- | --- | --- |
| M-01 | Simulation Engine | 4D trajectory, Monte Carlo, conflict/workload/raw KPI | DOC-17, DOC-23, DOC-29 | Không float/double trong decision path; deterministic output. |
| M-02 | Scenario Manager | create -> validate -> freeze -> run -> compare -> archive | DOC-08, DOC-14, DOC-18 | Scenario immutable sau freeze/submit; hash/provenance bắt buộc. |
| M-03 | Aircraft Performance Service | BADA/OpenAP, envelope, aircraft mapping | DOC-17, DOC-23, DOC-39 | BADA ưu tiên; fallback phải log/limitation. |
| M-04 | Weather4D Service | GRIB2/NetCDF, 4D grid, interpolation, CB/SIGMET | DOC-15, DOC-17, DOC-24 | Missing weather không silent default. |
| M-05 | Separation, Wake and CD&R | Minima resolver, conflict detection, ASM-App simulated action | DOC-17, DOC-18, DOC-23 | Minima từ versioned rule-set; không hard-code. |
| M-06 | AMAN/DMAN & Flow Behaviour | Arrival/departure stream, capacity and flow proxies | AppSpec, BRD/FRD, DOC-17 | Research simulation only; không thay thế AMAN/ATFM thật. |
| M-07 | Workload & Complexity | Task-time model, complexity and ATCO calibration | DOC-17, DOC-25 | Task-time-based; cần ATCO/SME validation. |
| M-08 | Replay, Heatmap & PIR | 2D/3D/4D replay, heatmaps, PIR dossier | DOC-13, DOC-26/27, DOC-29 | Replay có trace/hash/limitation/watermark. |
| M-09 | KPI & Reporting | KPI package, CI95, comparison, report/export | DOC-10, DOC-17, DOC-28 | KPI có methodology/version/uncertainty. |
| M-10 | Data Platform & Storage | PostGIS/Timescale/Object/Parquet/audit | DOC-12..16 | Big data không qua BFF/Kafka payload. |
| M-11 | Integration & ICD Layer | AIXM/ASTERIX/FDP/Weather/ATFM/IdP/SIEM adapters | DOC-08..11.5 | ICD + mock + contract tests; no write-back. |
| M-12 | Security & Privacy | L1-L4, RBAC/ABAC, masking, sanitized support, crypto | DOC-20..22 | Fail-closed nếu thiếu classification/clearance. |
| M-13 | UI/UX 4D Visualization | Scenario wizard, replay, dashboard, report center | DOC-26..28 | Watermark, generated client, no engine math in UI. |
| M-14 | DevOps/Ops | Local setup, CI/CD, observability, signed images, air-gap | DOC-31..34 | Evidence-driven, no public pull for air-gap. |
| M-15 | Procurement, PoC & Contract Controls | Sealed PoC, anti-lock-in, acceptance gates | AppSpec, BRD/FRD, DOC-25 | No slide-only acceptance; evidence pack required. |
| M-16 | Surface/Gate-to-Gate | Runway/taxi/stand/turnaround effects | AppSpec v8.5, DOC-17, DOC-24 | Connected to airside KPI; optional/phase-gated. |
| M-17 | Environmental/Sustainability | Fuel/CO2/noise/CDO/CCO proxy | AppSpec v8.5, KPI catalog | Methodology and limitation explicit. |
| M-18 | AAM/UAS Integration | Future eVTOL/UAS research corridor | AppSpec v8.5 | 2030+ option; not P0 without decision. |

## 4. Build phases

| Phase | Khối build | Vì sao phải trước | Exit criteria tối thiểu |
| --- | --- | --- | --- |
| 0 | Docs/runtime readiness | Không có source map/runtime truth thì coder sẽ đoán hoặc claim sai. | DOC-35/DOC-39/DOC-37/DOC-38 present, SPEC-GAPS/CONFLICTS ready, local setup log created. |
| 1 | Platform skeleton + guardrails CI | Cưỡng chế H0, contract-first, no secret, no time/no float trước khi logic phình ra. | Docs lint, OpenAPI/AsyncAPI/schema validation, Semgrep/static scanners, Makefile targets. |
| 2 | Data foundation M-10 | FTS phụ thuộc lineage, geospatial/time-series/object-store, audit và manifest. | DDL/Data Dictionary, migration dry-run, seed/reference manifest, object manifest smoke. |
| 3 | Scenario Manager M-02 | Mọi run cần lifecycle, freeze, hash, seed và validation trước engine. | Create/validate/freeze/run state machine + API + tests pass. |
| 4 | Data import/QA M-11/M-10 | AIXM/traffic/weather/FDP/BADA phải qua QA/quarantine trước engine. | Direct-to-storage upload, import job, QA report, quarantine, manifest. |
| 5 | Performance/weather/trajectory M-03/M-04/M-01 | Lõi quỹ đạo và weather sampling là nền cho conflict/KPI. | Deterministic trajectory fixture, performance fallback limitation, weather sample tests. |
| 6 | Separation/CD&R/ASM-App M-05 | Vùng rủi ro H0 cao: no live apply, no hard-code, physics guard. | DETECT_ONLY trước, RECOMMEND_ONLY, AUTO_APPLY_SIMULATED chỉ sau guard pass. |
| 7 | Async orchestration/worker pool M-14 | Monte Carlo/replications cần queue/checkpoint/scatter-gather. | REST 202, progress, cancel/resume, DLQ, scenario.run.completed single emission. |
| 8 | Workload/KPI/report M-07/M-09 | Decision-support cần workload/capacity/KPI có uncertainty. | KPI with CI/limitation, report manifest, export schemas. |
| 9 | Replay/UI M-08/M-13 | Người dùng kiểm tra realism và so sánh alternatives. | Watermark, 2D/3D/4D replay, trace tooltip, UI smoke/perf evidence. |
| 10 | Security/export/audit M-12 | Không được để tới cuối vì data nhạy cảm và audit là acceptance blocker. | L1-L4, ABAC negative tests, masked export, sanitized support, hash-chain audit. |
| 11 | PoC/V&V/DevOps hardening M-15/M-14 | Nghiệm thu bằng sealed scenario, evidence, signed/air-gapped bundle. | FAT/SAT/UAT/PoC pack, signed images/SBOM, observability, runbook. |

## 5. Vertical slice roadmap

| Slice | Priority | Size | Tên | Modules | Depends on | Local profile | DoD rút gọn |
| --- | --- | --- | --- | --- | --- | --- | --- |
| VS-00 | P0 | S | Foundation readback, source map and runtime truth gate | DOC-35, DOC-39 | - | none | foundation-readback.md có chữ ký nội bộ; SPEC-GAPS/CONFLICTS templates tồn tại |
| VS-01 | P0 | M | Repository skeleton and guardrail CI | M-14 | VS-00 | core | make doctor pass; make docs-validate pass |
| VS-02 | P0 | L | Data foundation: DDL, dictionary, object manifest and audit seed | M-10, M-12 | VS-01 | data-dev | Migration dry-run pass; Data dictionary validates |
| VS-03 | P0 | L | Scenario lifecycle: create, validate, freeze and hash | M-02 | VS-02 | core | Create/validate/freeze/run request routes pass contract tests; Frozen scenario immutable |
| VS-04 | P0 | L | Direct-to-storage import and quarantine QA | M-10, M-11, M-12 | VS-02, VS-03 | data-dev | Pre-signed upload issued; Import job status and QA report created |
| VS-05 | P0 | M | AIRAC, rule-set and reference data registry | M-10, M-11, M-05 | VS-02, VS-04 | data-dev | Scenario references exact AIRAC and rule-set hash; Cross-AIRAC policy enforced |
| VS-06 | P0 | L | Aircraft performance and Weather4D sampling | M-03, M-04 | VS-04, VS-05 | engine-dev | Performance lookup pass/fallback audited; Weather interpolation tests pass |
| VS-07 | P0 | XL | Deterministic 4D trajectory core minimal | M-01, M-03, M-04 | VS-06 | engine-dev | Trajectory fixture reproduces by hash; Invariants pass |
| VS-08 | P0 | L | Async run orchestration, worker checkpoint and scatter-gather | M-14, M-01, M-02 | VS-03, VS-07 | core | 202/control-plane works; Cancel/resume/DLQ tested |
| VS-09 | P0 | L | Separation minima resolver and conflict detection DETECT_ONLY | M-05 | VS-05, VS-07 | engine-dev | Conflict detection matches fixtures; DETECT_ONLY mode cannot alter trajectory |
| VS-10 | P0 | XL | Simulated CD&R / ASM-App guard chain | M-05, M-01, M-03 | VS-09, VS-07 | engine-dev | RECOMMEND_ONLY pass; AUTO_APPLY_SIMULATED enabled only when all guards pass |
| VS-11 | P1 | L | Workload and complexity service | M-07 | VS-09 | engine-dev | Workload series generated; Sensitivity +/-10% available |
| VS-12 | P1 | L | KPI package, comparison and CI95 | M-09, M-07 | VS-08, VS-11 | core | KPI package validates; CI95 shown or limitation |
| VS-13 | P0 | L | Report/export package with watermark, lineage and manifest | M-09, M-12 | VS-12 | core | Report preview/package includes watermark; ABAC/masking negative tests pass |
| VS-14 | P1 | XL | Replay, heatmap and PIR UI shell | M-08, M-13 | VS-08, VS-13 | ui-dev | Scenario list/run/replay/report flows render; Watermark visible |
| VS-15 | P0 | XL | Security baseline: ABAC, masking, audit hash-chain and support package | M-12 | VS-02, VS-13, VS-14 | core | ABAC negative tests pass; Masking/export fail closed |
| VS-16 | P1 | L | Observability, release evidence and air-gap package skeleton | M-14 | VS-01, VS-08, VS-15 | full-ci-only | Release evidence pack created; SBOM/signature logs exist |
| VS-17 | P1 | XL | PoC sealed/V&V witness rehearsal | M-15, M-01, M-05, M-09, M-13 | VS-10, VS-13, VS-14, VS-16 | poc-dry-run | Original + salted runs produce expected evidence; Evaluator manifest created |
| VS-18 | P2 | L | Extended surface/environment/AAM option readiness | M-16, M-17, M-18 | VS-12, VS-14 | engine-dev | Option fixtures and schema stubs exist; Core roadmap unaffected |

## 6. Luật chuyển phase

Một phase chỉ được coi là pass khi: artifact bắt buộc trong DOC-37 đã ở trạng thái `MACHINE_VALIDATED` hoặc cao hơn; P0 decision liên quan trong DOC-39 không còn `PENDING` nếu ảnh hưởng trực tiếp; test class tương ứng pass; evidence đã lưu tại `evidence/<slice-id>/`; SPEC-GAPS/RUNTIME-GAPS còn mở được phân loại non-blocker hoặc đã có safe default.

## 7. Output bắt buộc mỗi slice

Mỗi slice M/L/XL phải có `features/<slice-id>-<slug>/mini-spec.md`, `TRACEABILITY.md`, `test-matrix.md`, `security-evidence.md`, `release-evidence/manifest.yaml`, `open-gaps-and-conflicts.md` và log lệnh đã chạy. Slice XS/S có thể dùng TRACEABILITY rút gọn nhưng vẫn phải có evidence.

## 8. Repo-ready artifact đi kèm

File `DOC36_vertical-slices.yaml` là source máy đọc được của roadmap này. CI nên validate file đó trước khi cho phép tạo PR feature mới.
