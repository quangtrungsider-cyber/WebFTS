# DOC-38 — Repository Bootstrap & Scaffold Pack cho VATM FTS

**Phiên bản:** v1.0  
**Ngày:** 2026-05-12  
**Trạng thái:** Generated draft / chờ VATM review & sign-off  
**Boundary:** Decision-support / Non-operational

## 1. Mục đích

DOC-38 cung cấp bootstrap pack để 1 coder có thể tạo repo FTS theo một cấu trúc thống nhất, chạy local profile, tạo feature scaffold, chạy guardrail CI và đóng gói evidence mà không phải tự đoán folder, Makefile, template hay command.

DOC-38 là implementation bootstrap, không phải approval tự động. Nếu DOC-39 P0 decision còn pending, scaffold phải tạo feature ở trạng thái gated/disabled hoặc test-harness-only.

## 2. Root principles

docs-as-code, contract-first, evidence-driven, no-live-writeback, deterministic-core, fail-closed-security

## 3. Repo tree chuẩn

| Path | Purpose |
| --- | --- |
| docs/00-operating-rules | DOC-00, DOC-00.1, H0/H1-H8, conflict/gap policy |
| docs/00-governance | DOC-35..39 meta docs, docs-map, vertical-slices, materialization matrix, decision register |
| docs/01-business-context | DOC-01..04, glossary, C4 context/container |
| docs/02-technical-decisions | DOC-05..07, ADRs, stack, coding standards |
| docs/03-interfaces | DOC-08..11.5 narratives, semantic profile and ICD docs |
| openapi | OpenAPI 3.1 machine contracts |
| asyncapi | AsyncAPI 3.0 event contracts |
| icd | External adapter contracts and mocks |
| schemas/json | JSON schemas for manifests, KPI, report, env, test metadata |
| docs/04-data | DOC-12..16 narratives and data dictionary |
| db/migrations | Forward-only SQL migrations |
| state-machines | XState JSON and transition tables |
| seed | Small seed/reference data only |
| reference-data/airac | AIRAC/reference bundle manifests |
| reference-data/rulesets | Separation/wake/rule-set YAML with hashes |
| docs/05-rules | Rules, BR catalog, notifications, error dictionary |
| docs/06-security | Security checklist, crypto, classification, export/support handling |
| policies | ABAC, Kyverno, log redaction, export policies |
| docs/07-domain | Engine protocol, dataset governance, PoC/V&V |
| engine | Deterministic core and CLI/harness |
| services/api-bff | FastAPI/BFF control plane |
| services/worker | Async run worker/orchestrator |
| services/data-importer | Data QA/quarantine/import compiler |
| services/kpi | KPI/report computation service |
| services/security | ABAC/masking/audit/security helpers |
| apps/web | React/TypeScript UI with generated client |
| generated | Generated clients/types from OpenAPI/AsyncAPI/schema |
| fixtures | Reviewable text fixtures and manifests; no big binaries |
| tests/contracts | Contract tests |
| tests/integration | API+DB+broker+object+worker integration |
| tests/simulation-regression | Deterministic engine regression |
| tests/simulation-invariants | Aviation invariants and physics guard |
| tests/security | ABAC/masking/export/log/audit tests |
| tests/ui | Playwright and accessibility tests |
| tools/scaffold | Feature scaffold generator |
| tools/testdata | Compile/verify/load/reset fixture data |
| tools/evidence | Evidence packer and PoC salting |
| tools/semgrep | No-float/no-time/no-live-writeback/no-secret rules |
| ops/compose | Local/dev compose profiles |
| infra/helm | Helm charts and values |
| infra/observability | OTel/Prometheus/Grafana/alert rules |
| artifacts | Generated local/CI artifacts, gitignored |
| evidence | Curated release/PoC evidence packages |
| runbooks | Ops runbooks and rollback notes |
| witness-scripts | FAT/SAT/UAT/PoC witness scripts |

## 4. Local profiles

| Profile | Bật | Tắt / giả lập | Dùng khi |
| --- | --- | --- | --- |
| ui-dev | Frontend, API/BFF, generated client, WireMock/MSW, auth mock | Engine, full broker, heavy Timescale, MinIO large objects | UI, state rendering, report preview, accessibility, export shell. |
| engine-dev | Engine CLI/harness, unit/property tests, synthetic fixture <=50 flights | UI, Keycloak, full Kafka, large object storage | Trajectory, ASM-App, KPI, deterministic regression. |
| data-dev | PostGIS/Timescale small, object manifest, data QA fixtures | UI heavy, worker pool, live external adapters | Import, schema, dictionary, quarantine, reference data. |
| core | API/BFF, DB, broker, object store, worker, auth mock, small fixtures | GPU UI perf, full 5k/30rep load | Scenario/run/control-plane integration smoke. |
| full-ci-only | Full stack, broker, object, worker pool, perf/security scans | N/A on laptop | Nightly/release/perf/PoC stress. |
| poc-dry-run | PoC fixtures, salting tool, evaluator manifest, evidence pack | Real sensitive data, public network | Internal PoC rehearsal before official witness. |

## 5. Makefile targets tối thiểu

| Target | Mục đích |
| --- | --- |
| doctor | Check host tools, Docker/Podman, Python/Node/Rust, disk, no forbidden internet in airgap mode. |
| bootstrap | Create venv, install tooling, pre-commit hooks, compile generated clients, validate docs map. |
| docs-validate | Validate docs-map, decision register, materialization matrix, markdown front matter. |
| compose-up PROFILE=core | Start local profile via ops/compose/docker-compose.$(PROFILE).yaml. |
| compose-down PROFILE=core | Stop profile and preserve evidence logs. |
| migrate | Run DB migrations and schema smoke. |
| testdata-compile | Compile text fixtures into generated Parquet/Arrow artifacts outside Git source. |
| testdata-load PROFILE=local-dev | Load fixture profile after compile and verify manifest hashes. |
| testdata-verify PROFILE=local-dev | Verify hash, classification, AIRAC, time and no binary fossilization. |
| test-contract | Run OpenAPI/AsyncAPI/schema contract tests. |
| test-integration | Run API+DB+broker+object+worker integration tests. |
| test-simulation-regression PROFILE=regression-core | Run deterministic engine regression. |
| test-invariants PROFILE=regression-core | Run aviation/physics invariants. |
| test-time | Run time/time-travel and no SystemTime path tests. |
| test-ui-e2e | Run Playwright UI/watermark/no-live-lexicon smoke. |
| guardrails-scan | Run Semgrep/no secret/no float/no live write-back/no hard-coded minima scanners. |
| security-evidence | Run negative ABAC/masking/export/log/audit checks and collect evidence. |
| scaffold-feature NAME=x SIZE=M | Generate feature folder with mini-spec, traceability, test/security/evidence templates. |
| evidence-local | Package local setup/smoke logs, redacted env, screenshots, runtime gaps. |
| evidence-pack RELEASE=<sha> | Build release evidence pack with tests, hashes, SBOM, signatures, manifests. |
| poc-dynamic-salt | Apply controlled perturbation to PoC package and write evaluator manifest. |
| poc-sealed-dry-run | Run sealed PoC rehearsal and evidence pack validation. |
| wip-push | Commit/push WIP and write daily-wip-handoff for Drop-the-Laptop rule. |

## 6. Feature scaffold output

Lệnh `make scaffold-feature NAME=<name> SIZE=<XS|S|M|L|XL>` phải tạo:

```text
features/<name>/
  mini-spec.md
  TRACEABILITY.md
  test-matrix.md
  security-evidence.md
  ai-review.md
  open-gaps-and-conflicts.md
  release-evidence/manifest.yaml
  evidence/.gitkeep
```

Với M/L/XL, scaffold cũng phải thêm `risk-register.md`, `runbook-fragment.md`, `rubber-duck-video-link.md` và `daily-wip-handoff.md`.

## 7. Bootstrap acceptance checklist

- [ ] `make doctor` chạy được trên laptop sạch.
- [ ] `make docs-validate` validate DOC-35, DOC-36, DOC-37, DOC-39.
- [ ] `make compose-up PROFILE=core` dựng được API, DB, broker, object store, auth mock và worker skeleton.
- [ ] `make guardrails-scan` có rule no-float/no-system-time/no-live-writeback/no-secret/no-hardcoded-minima.
- [ ] `make scaffold-feature NAME=scenario-lifecycle SIZE=L` tạo đủ templates.
- [ ] `make evidence-local` đóng gói local-setup log và env redacted manifest.
