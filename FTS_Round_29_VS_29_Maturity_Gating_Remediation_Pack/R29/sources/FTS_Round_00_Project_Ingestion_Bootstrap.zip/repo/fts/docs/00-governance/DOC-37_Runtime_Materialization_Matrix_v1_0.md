# DOC-37 — Runtime Materialization Matrix cho VATM FTS

**Phiên bản:** v1.0  
**Ngày:** 2026-05-12  
**Trạng thái:** Generated draft / chờ VATM review & sign-off  
**Boundary:** Decision-support / Non-operational

## 1. Mục đích

DOC-37 là ma trận biến tài liệu DOCX/prose thành artifact repo-ready có thể kiểm tra bằng máy. Mục tiêu là loại bỏ tình trạng “tài liệu có nói” nhưng repo không có OpenAPI, AsyncAPI, DDL, XState, YAML rule, fixture, scanner, test hoặc evidence tương ứng.

Nếu một requirement chỉ còn ở dạng prose, coder không được tuyên bố runtime-ready. Coder phải tạo `RUNTIME-GAP`, `SPEC-GAP` hoặc artifact materialization trước khi code phần phụ thuộc.

## 2. Materialization lifecycle

| State | Ý nghĩa | Hành động được phép |
| --- | --- | --- |
| PROSE_ONLY | Chỉ có DOCX/Markdown mô tả; chưa có artifact máy kiểm được. | Không được claim runtime-ready; có thể dùng để phân tích/mini-spec. |
| TO_MATERIALIZE | Đã xác định artifact path, owner, validation command nhưng file chưa có hoặc chưa đạt schema. | Mở RUNTIME-GAP nếu feature phụ thuộc. |
| DRAFT_GENERATED | Artifact draft đã sinh trong pack/repo, cần review và validate. | Có thể dùng cho bootstrap nhưng chưa ký VATM. |
| MACHINE_VALIDATED | Artifact pass validation/lint/schema/contract test. | Có thể code phụ thuộc nếu P0 decisions không block. |
| RUNTIME_WIRED | Code/service/test thực sự consume artifact. | Runtime truth bắt đầu hình thành; cần evidence. |
| CI_ENFORCED | CI fail nếu artifact drift hoặc missing. | Có thể dùng làm release gate. |
| EVIDENCE_READY | Có logs/reports/screenshots/hashes để reviewer tái chạy. | Có thể đưa vào FAT/SAT/UAT/Poc evidence. |
| VATM_APPROVED | Artifact/decision được VATM/owner ký hoặc chấp thuận có điều kiện. | Có thể làm source chuẩn chính thức. |

## 3. Runtime materialization matrix

| ID | Concern | Source | Repo path | Type | Priority | Required for | Validate | Status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| MAT-001 | governance | DOC-00 | /docs/00-operating-rules/00-hierarchy-of-truth.md | Markdown | P0 | VS-00 | docs-lint | TO_MATERIALIZE |
| MAT-002 | governance | DOC-00.1 | /docs/00-operating-rules/00-docs-as-code-operational-guide.md | Markdown | P0 | VS-00 | docs-lint | TO_MATERIALIZE |
| MAT-003 | governance | DOC-35 | /docs/00-governance/docs-map.yaml | YAML | P0 | VS-00 | docs-map-validate | DRAFT_GENERATED |
| MAT-004 | governance | DOC-36 | /docs/00-governance/vertical-slices.yaml | YAML | P0 | VS-00 | python tools/docs/validate_vertical_slices.py | DRAFT_GENERATED |
| MAT-005 | governance | DOC-37 | /docs/00-governance/runtime-materialization-matrix.yaml | YAML | P0 | VS-00 | runtime-materialization-validate | DRAFT_GENERATED |
| MAT-006 | governance | DOC-38 | /docs/00-governance/repository-bootstrap.md | Markdown | P0 | VS-01 | docs-lint | DRAFT_GENERATED |
| MAT-007 | governance | DOC-39 | /docs/00-governance/decision-register.yaml | YAML | P0 | VS-00 | decision-register-validate | DRAFT_GENERATED |
| MAT-010 | architecture | DOC-05 | /docs/02-technical-decisions/doc-05-adrs/*.md | Markdown/ADR | P0 | VS-01 | docs-lint | TO_MATERIALIZE |
| MAT-011 | architecture | DOC-06 | /stack-lock.yaml | YAML | P0 | VS-01 | python tools/devops/validate_stack_lock.py | TO_MATERIALIZE |
| MAT-012 | architecture | DOC-07 | /tools/semgrep/*.yaml | Semgrep YAML | P0 | VS-01 | guardrails-scan | TO_MATERIALIZE |
| MAT-020 | interfaces | DOC-08 | /openapi/fts-control.yaml | OpenAPI 3.1 YAML | P0 | VS-03,VS-08,VS-13,VS-14 | openapi-validate | TO_MATERIALIZE |
| MAT-021 | interfaces | DOC-09 | /asyncapi/fts-events.yaml | AsyncAPI 3.0 YAML | P0 | VS-08 | asyncapi-validate | TO_MATERIALIZE |
| MAT-022 | interfaces | DOC-10 | /schemas/semantic/fts-kpi-profile.schema.json | JSON Schema | P1 | VS-12 | schema-validate | TO_MATERIALIZE |
| MAT-023 | interfaces | DOC-11 | /icd/*.md | Markdown + JSON Schema | P0 | VS-04 | docs-lint schema-validate | TO_MATERIALIZE |
| MAT-024 | interfaces | DOC-11.5 | /docs/03-interfaces/distributed-sequences.md | Markdown/Mermaid | P0 | VS-08 | docs-lint | TO_MATERIALIZE |
| MAT-030 | data | DOC-12 | /db/migrations/*.sql | SQL | P0 | VS-02 | ddl-validate | TO_MATERIALIZE |
| MAT-031 | data | DOC-13 | /docs/04-data/data-dictionary.yaml | YAML | P0 | VS-02 | python tools/data/validate_dictionary.py | TO_MATERIALIZE |
| MAT-032 | data | DOC-14 | /state-machines/*.xstate.json | XState JSON | P0 | VS-03 | state-machine-validate | TO_MATERIALIZE |
| MAT-033 | data | DOC-15 | /docs/04-data/historical-ingest.md | Markdown | P0 | VS-04 | docs-lint | TO_MATERIALIZE |
| MAT-034 | data | DOC-16 | /seed/** /reference-data/** | YAML/JSON/CSV small | P0 | VS-02,VS-05 | testdata-verify | TO_MATERIALIZE |
| MAT-040 | rules | DOC-17 | /docs/05-rules/simulation-kpi-rules.yaml | YAML | P0 | VS-06,VS-07,VS-09,VS-12 | rules-validate | TO_MATERIALIZE |
| MAT-041 | rules | DOC-18 | /docs/05-rules/business-rules.yaml | YAML | P0 | VS-03,VS-09,VS-10 | rules-validate | TO_MATERIALIZE |
| MAT-042 | rules | DOC-19 | /docs/05-rules/notifications.yaml | YAML | P1 | VS-13 | rules-validate | TO_MATERIALIZE |
| MAT-043 | rules | DOC-19.5 | /docs/05-rules/error-codes.yaml | YAML | P0 | VS-03,VS-13 | rules-validate | TO_MATERIALIZE |
| MAT-044 | rules | DOC-17/DOC-24 | /reference-data/rulesets/separation-ruleset.yaml | YAML | P0 | VS-05,VS-09,VS-10 | ruleset-validate | TO_MATERIALIZE |
| MAT-050 | security | DOC-20 | /docs/06-security/security-checklist.md | Markdown | P0 | VS-15 | docs-lint security-evidence | TO_MATERIALIZE |
| MAT-051 | security | DOC-21 | /docs/06-security/crypto-key-management.md | Markdown/YAML | P0 | VS-02,VS-15 | docs-lint | TO_MATERIALIZE |
| MAT-052 | security | DOC-22 | /docs/06-security/data-classification.yaml | YAML | P0 | VS-02,VS-04,VS-13,VS-15 | python tools/security/validate_classification.py | TO_MATERIALIZE |
| MAT-060 | domain | DOC-23 | /docs/07-domain/simulation-worker-protocol.md | Markdown + schema | P0 | VS-07,VS-08,VS-10 | docs-lint schema-validate | TO_MATERIALIZE |
| MAT-061 | domain | DOC-24 | /docs/07-domain/aviation-dataset-governance.md | Markdown/YAML | P0 | VS-04,VS-05,VS-06 | docs-lint | TO_MATERIALIZE |
| MAT-062 | domain | DOC-25 | /docs/07-domain/poc-vv-validation.md | Markdown | P1 | VS-10,VS-17 | docs-lint | TO_MATERIALIZE |
| MAT-070 | frontend | DOC-26 | /docs/08-frontend/design-system.md | Markdown | P1 | VS-14 | docs-lint | TO_MATERIALIZE |
| MAT-071 | frontend | DOC-27 | /docs/08-frontend/screen-spec.md | Markdown | P1 | VS-13,VS-14 | docs-lint | TO_MATERIALIZE |
| MAT-072 | frontend | DOC-28 | /docs/08-frontend/i18n.yaml | YAML | P1 | VS-14 | python tools/i18n/validate_i18n.py | TO_MATERIALIZE |
| MAT-080 | testing | DOC-29 | /docs/09-testing/test-case-specification.md | Markdown | P0 | ALL | docs-lint | TO_MATERIALIZE |
| MAT-081 | testing | DOC-29 | /docs/09-testing/gherkin/*.feature | Gherkin | P0 | VS-03..VS-17 | pytest-bdd/gherkin-lint | TO_MATERIALIZE |
| MAT-082 | testing | DOC-29 | /docs/09-testing/test-metadata.schema.json | JSON Schema | P0 | VS-01 | schema-validate | TO_MATERIALIZE |
| MAT-083 | testing | DOC-30 | /fixtures/**/manifest.yaml | YAML | P0 | VS-04..VS-17 | testdata-verify | TO_MATERIALIZE |
| MAT-084 | testing | DOC-30.5 | /docs/09-testing/time-time-travel.md | Markdown + Semgrep | P0 | VS-07 | test-time guardrails-scan | TO_MATERIALIZE |
| MAT-090 | devops | DOC-31 | /Makefile | Makefile | P0 | VS-01 | make doctor | DRAFT_GENERATED |
| MAT-091 | devops | DOC-31 | /ops/compose/docker-compose.core.yaml | Docker Compose | P0 | VS-01,VS-03,VS-08 | docker compose config | DRAFT_GENERATED |
| MAT-092 | devops | DOC-32 | /.github/workflows/ci.yml | CI YAML | P0 | VS-01,VS-16 | yamllint + dry-run | DRAFT_GENERATED |
| MAT-093 | devops | DOC-33 | /infra/observability/** | Prometheus/Grafana/OTel YAML | P1 | VS-16 | promtool check rules | TO_MATERIALIZE |
| MAT-094 | devops | DOC-34 | /config/env.schema.json | JSON Schema | P0 | VS-01,VS-16 | python tools/config/validate_env.py | TO_MATERIALIZE |
| MAT-095 | devops | DOC-34 | /infra/helm/** | Helm | P1 | VS-16 | helm lint infra/helm/fts | TO_MATERIALIZE |
| MAT-096 | devops | SOP/DOC-38 | /tools/scaffold/scaffold_feature.py | Python script | P0 | VS-01 + every feature | python tools/scaffold/scaffold_feature.py --help | DRAFT_GENERATED |

## 4. Validation command catalog

| Command | Lệnh đề xuất | Kiểm cái gì |
| --- | --- | --- |
| docs-lint | markdownlint-cli2 docs/**/*.md && python tools/docs/validate_frontmatter.py | Markdown/doc front matter, source IDs, status, owner |
| docs-map-validate | python tools/docs/validate_docs_map.py docs/00-governance/docs-map.yaml | DOC-35 map completeness |
| decision-register-validate | python tools/governance/validate_decision_register.py docs/00-governance/decision-register.yaml | DOC-39 lifecycle/status/signers |
| runtime-materialization-validate | python tools/docs/validate_materialization.py docs/00-governance/runtime-materialization-matrix.yaml | DOC-37 matrix schema and missing artifacts |
| openapi-validate | npx @redocly/cli lint openapi/*.yaml | REST contract |
| asyncapi-validate | npx @asyncapi/cli validate asyncapi/*.yaml | Event contract |
| schema-validate | python tools/schema/validate_json_schemas.py schemas | JSON Schema bundle |
| ddl-validate | sqruff lint db/migrations && python tools/db/validate_migrations.py | SQL migrations |
| state-machine-validate | python tools/state/validate_xstate.py state-machines/*.json | Lifecycle/state machines |
| rules-validate | python tools/rules/validate_rules.py docs/05-rules/*.yaml | Business/calculation/separation/error rules |
| testdata-verify | python tools/testdata/verify.py --profile $(PROFILE) --checks hash,classification,baseline,airac,time,binary-fossilization | Fixture manifests and data policy |
| guardrails-scan | semgrep --config tools/semgrep/ src/ engine/ tests/ | No float/no system time/no live writeback/no secret/log leak |
| test-contract | pytest tests/contracts --junitxml=artifacts/junit-contract.xml | API/event/schema contract tests |
| test-integration | pytest tests/integration --junitxml=artifacts/junit-integration.xml | API+DB+broker+object+worker |
| test-simulation-regression | pytest tests/simulation-regression --profile=$(PROFILE) --junitxml=artifacts/junit-sim.xml | Deterministic engine outputs |
| test-invariants | pytest tests/simulation-invariants --profile=$(PROFILE) --junitxml=artifacts/junit-invariants.xml | Aviation invariants beyond checksum |
| test-time | pytest tests/time --junitxml=artifacts/junit-time.xml | SystemTime/SimulationTime/ValidityTime split |
| test-ui-e2e | playwright test --reporter=html,junit | UI flows/watermark/accessibility |
| security-evidence | make secret-scan log-redaction-scan test-security-negative audit-hash-verify | Security/privacy/audit gates |
| evidence-pack | python tools/evidence/pack.py --release $(RELEASE) --output artifacts/release-evidence-pack.zip | Release evidence pack |

## 5. RUNTIME-GAP rule

Một gap được coi là `RUNTIME-GAP` khi spec/target truth đã có trong DOCX/Markdown nhưng repo chưa có artifact chạy/kiểm được hoặc runtime chưa wire artifact đó. RUNTIME-GAP không phải lỗi nhỏ: nó cấm claim “done/production-ready” cho capability liên quan.

Mỗi RUNTIME-GAP phải có: `id`, `slice`, `missing_artifact`, `source_doc`, `blocked_claim`, `safe_default`, `owner`, `due_date`, `evidence_needed`, `status`.

## 6. Exit checklist của DOC-37

- [ ] Mọi OpenAPI/AsyncAPI/DDL/XState/BR/rule/security/test artifact P0 có repo path và command validate.
- [ ] Mỗi vertical slice trong DOC-36 có materialization refs.
- [ ] Mọi P0 row không còn `PROSE_ONLY` trước khi code feature phụ thuộc.
- [ ] CI fail nếu materialization matrix khai có artifact nhưng file thiếu.
- [ ] RUNTIME-GAP được gom vào release evidence và không bị ẩn trong TODO cá nhân.
