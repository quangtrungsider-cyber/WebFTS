# FTS Round 00 Project Ingestion & Bootstrap Package

Generated: 2026-05-12

## Contents

- `repo/fts/` — bootstrap repository scaffold derived from DOC-38.
- `manifest/SOURCE_INVENTORY.md` — human-readable list of all current project source files.
- `manifest/source_manifest.json` — machine-readable manifest with hashes and ZIP entries.
- `manifest/BUILD_ROADMAP.md` — sequential development roadmap derived from DOC-36.
- `release/RELEASE_NOTE.md` — Round 00 release note.
- `release/CHANGELOG.md` — Round 00 changelog.
- `release/NEXT_ROUND_PLAN.md` — full plan/prompt for Round 01.
- `release/EVIDENCE_MANIFEST.yaml` — evidence manifest.
- `evidence/` — logs from `make doctor` and `make docs-validate`.

## How to verify

```bash
cd repo/fts
make doctor PROFILE=core
make docs-validate
```

## Next round

Run Round 01 / VS-01 to complete repository skeleton and guardrail CI.
