# Changelog — FTS

## [fts-r00-foundation-v0.0.0] — 2026-05-12

### Added

- Created project source inventory and role map.
- Generated `manifest/source_manifest.json` with SHA-256 hashes and complete ZIP entry inventory.
- Initialized bootstrap repository at `repo/fts` from DOC-38 bootstrap scaffold.
- Added governance artifacts from DOC-35, DOC-36, DOC-37 and DOC-39.
- Added minimal validators for docs map, decision register, vertical slices and materialization matrix.
- Added Round 00 release note, changelog, next-round plan and evidence manifest.

### Changed

- Established mandatory end-of-round packaging rule: every round must ship release note, changelog, evidence manifest and next-round plan in a zip.

### Deferred

- Concrete Semgrep guardrail rules.
- Runtime services/API implementation.
- OpenAPI/AsyncAPI/DDL generation and enforcement.
- Docker build and CI execution beyond governance validation.

### Risk / blocker

- DOC-39 OPEN decisions are preserved as blockers or gated defaults until approved evidence is available.
