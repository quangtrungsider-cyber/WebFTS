# Next Round Plan — Round 01 / VS-01 Repository Skeleton & Guardrail CI

**Target slice:** VS-01  
**Priority:** P0  
**Expected release:** `fts-r01-vs01-repo-guardrails-v0.1.0`  
**Boundary:** Decision-support / Non-operational

## 1. Objective

Complete the repository skeleton and guardrail CI foundation so future feature work cannot drift away from the source package. Round 01 should make the local repo usable by one coder and prepare the first CI-grade safety gates.

## 2. Source files to read before implementation

1. `FTS_Tang_0_DOC00_DOC00_1_Quy_tac_van_hanh_Toi_thuong_v2_5.docx`
2. `FTS_Tang_2_DOC05_DOC07_Hoan_thien_v2_7_Production_Hardened.docx`
3. `FTS_Tang_10_DOC31_DOC34_DevOps_Operations_Reference_Ultimate_Enterprise_Ops_Hardened_v1_1.docx`
4. `FTS_Quy_trinh_chuan_1_coder_v1_1_Ultimate_Solo_Dev_Survival_Hardened.docx`
5. `FTS_DOC36_DOC37_DOC38_Implementation_Pack_v1_0.zip`
6. `FTS_DOC35_DOC39_Implementation_Pack_v1_0.zip`

## 3. Implementation tasks

### 3.1 Harden Makefile targets

- Keep `make doctor` as the first local readiness command.
- Keep `make docs-validate` as the first source-of-truth command.
- Add or refine `make guardrails-scan` so it can run without false claims.
- Add deterministic output under `artifacts/` for every validation command.

### 3.2 Concrete guardrail rules

Create concrete scanner rules or script-based checks for:

- no live ATC/ATFM write-back path,
- no `datetime.now()` / `Date.now()` / server wall-clock in domain logic,
- no float/double in deterministic engine decision paths,
- no hard-coded separation minima,
- no raw L3/L4 payload logging,
- no committed secrets.

### 3.3 Scaffold first feature template

Run and verify:

```bash
make scaffold-feature NAME=scenario-lifecycle SIZE=L SLICE=VS-03
```

Expected files:

- `features/scenario-lifecycle/mini-spec.md`
- `features/scenario-lifecycle/TRACEABILITY.md`
- `features/scenario-lifecycle/test-matrix.md`
- `features/scenario-lifecycle/security-evidence.md`
- `features/scenario-lifecycle/open-gaps-and-conflicts.md`
- `features/scenario-lifecycle/release-evidence/manifest.yaml`

### 3.4 CI skeleton hardening

- Keep GitHub Actions workflow or equivalent CI YAML.
- Make job names mirror the gates in DOC-38:
  - docs/contracts,
  - data/engine,
  - UI/security/evidence.
- Avoid CI steps that require unavailable proprietary datasets or live external systems.

### 3.5 Evidence packaging

Round 01 zip must include:

- `release/RELEASE_NOTE.md`
- `release/CHANGELOG.md`
- `release/NEXT_ROUND_PLAN.md`
- `release/EVIDENCE_MANIFEST.yaml`
- validator outputs under `evidence/`
- updated `repo/fts`

## 4. Acceptance criteria

Round 01 is acceptable when:

- `make doctor` passes.
- `make docs-validate` passes.
- `make scaffold-feature NAME=scenario-lifecycle SIZE=L SLICE=VS-03` creates the complete feature skeleton.
- `make guardrails-scan` runs and emits a machine-readable report, even if some checks are advisory in R01.
- Release note and changelog clearly separate completed, deferred and blocked items.

## 5. Suggested user prompt for Round 01

> Thực hiện Round 01 / VS-01 cho app FTS: dựa trên toàn bộ nguồn project và gói Round 00, hoàn thiện repository skeleton + guardrail CI. Tạo các rule/check chống live write-back, system time, float/double decision path, hard-coded minima, raw L3/L4 logging và secret. Chạy `make doctor`, `make docs-validate`, `make scaffold-feature NAME=scenario-lifecycle SIZE=L SLICE=VS-03`, đóng gói release note, changelog, evidence manifest và kế hoạch Round 02 trong file zip.
