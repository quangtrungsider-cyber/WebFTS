# Release Note — FTS Round 00 Project Ingestion & Bootstrap

**Release:** `fts-r00-foundation-v0.0.0`  
**Date:** 2026-05-12  
**Boundary:** Decision-support / Non-operational  
**Implementation slice:** VS-00 foundation; VS-01 bootstrap preparation

## Summary

Round 00 establishes the working baseline for sequential FTS development. It does not claim a production application. It creates a traceable source inventory, imports DOC-35/DOC-36/DOC-37/DOC-39 runtime governance artifacts, prepares the repository skeleton from DOC-38 and defines the mandatory release/changelog/next-round zip pattern.

## Delivered

- Source inventory for all current FTS source files and implementation packs.
- Full JSON source manifest with SHA-256 hashes and ZIP internal entries.
- Sequential build roadmap based on DOC-36 vertical slices.
- Bootstrap repository under `repo/fts`.
- Governance artifacts copied to `repo/fts/docs/00-governance/`:
  - `docs-map.yaml`
  - `decision-register.yaml`
  - `vertical-slices.yaml`
  - `runtime-materialization-matrix.yaml`
- Minimal validation tools for:
  - `make doctor`
  - `make docs-validate`
- Initial `SPEC-GAPS.md`, `CONFLICTS.md` and `foundation-readback.md`.
- Evidence logs from Round 00 validation.

## Validation performed

- `make doctor PROFILE=core`
- `make docs-validate`

## Known limitations

- Application services are placeholders only.
- Guardrail scan rules are listed but not yet implemented as concrete Semgrep policies.
- Docker Compose services are copied from DOC-38, but Round 00 did not build Docker images.
- DOC-39 source decision register still has OPEN decisions; affected feature implementation must remain gated until signoff evidence exists.

## Next release target

Round 01 should complete VS-01: Repository skeleton and guardrail CI.
