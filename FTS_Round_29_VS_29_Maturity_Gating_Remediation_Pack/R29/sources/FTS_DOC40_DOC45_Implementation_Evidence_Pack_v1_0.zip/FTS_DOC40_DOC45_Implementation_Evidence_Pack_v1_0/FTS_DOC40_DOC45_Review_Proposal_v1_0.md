# Rà soát & Đề xuất DOC-40 đến DOC-45

## Kết luận rà soát

Bộ FTS hiện có đã đủ nền tảng đặc tả và governance, nhưng để 1 coder độc lập phát triển không cần hỏi thêm thì cần bổ sung lớp implementation evidence gồm DOC-40 đến DOC-45. Bộ này chuyển các yêu cầu còn rời rạc trong AppSpec/BRD/FRD/Tầng 0–10/SOP/DOC-35..39 thành mini-spec, fixture/oracle, ICD/license, ruleset/calibration, witness script và security accreditation.

## Đề xuất chốt

| Doc | Tên | Mục tiêu | Artifact trọng tâm |
|---|---|---|---|
| DOC-40 | Per-Feature Mini-Spec Library | 18 mini-spec M-01..M-18, ưu tiên P0 đủ API/event/table/rule/test/security/UI/evidence. | `mini-spec-index.yaml`, `M-xx-*.md`, matrix CSV. |
| DOC-41 | Executable Test Fixture & Oracle Pack | Fixture chạy được, dirty-data, deterministic seed, expected hashes. | `dataset-manifest.yaml`, `hash-oracle.yaml`, Gherkin/pytest/Playwright. |
| DOC-42 | External Data Source & Licensing Pack | ICD/parser/quarantine/license/fallback cho nguồn ngoài. | `external-source-index.yaml`, `license-fallback-register.yaml`, ICDs, schemas. |
| DOC-43 | Domain Calibration & Ruleset Approval Pack | Rule/calibration versioned, không hard-code. | `separation-ruleset.yaml`, `wake-rules.yaml`, `workload-weights.yaml`, `calibration-manifest.yaml`. |
| DOC-44 | FAT/SAT/UAT/PoC Witness Script Pack | Nghiệm thu bằng script, scoring, dynamic salt và evidence. | `witness-runbook.yaml`, `scoring-rubric.yaml`, `pass-fail-thresholds.yaml`. |
| DOC-45 | Security Accreditation & Data Handling Pack | Security accreditation, L1-L4, export/support/masking/audit. | `security-control-matrix.yaml`, `data-classification-matrix.yaml`, `security-accreditation-ledger.yaml`. |

## Blocker còn chờ VATM

- Phê duyệt ruleset separation/wake/workload/AMAN-DMAN/weather degradation/BADA fallback.
- Xác nhận source owner và license/fallback cho AIXM, ASTERIX/FDP, Weather4D, BADA/OpenAP, AMDB, emission DB.
- Cung cấp hoặc ký duyệt golden dataset thật thay cho synthetic fixtures.
- Chốt security accreditation scope cho PoC/FAT/SAT/UAT và exception policy.
- Chốt witness panel, scoring thresholds và dynamic salt protocol.
