# <M-ID> — <Feature name>

**Status:** GENERATED_DRAFT_PENDING_VATM_REVIEW_AND_SIGNOFF  
**Owner service:** `<service>`  
**Vertical slice:** `<VS>`

## 1. Scope / out-of-scope / authority
## 2. Contracts touched
## 3. Rule IDs / state IDs / error codes
## 4. Data classification
## 5. Happy path / error path / compensation / replay / time path
## 6. Tests
## 7. Observability
## 8. Migration / rollout / rollback
## 9. Evidence links
