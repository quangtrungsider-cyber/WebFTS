# ATCO Validation Protocol

1. Confirm scenario scope, non-operational watermark and data classification.
2. Review replay, workload breakdown, conflict/hotspot trace and flow behaviour.
3. Score realism, workload plausibility, sequencing plausibility and traceability using Likert form.
4. Record accepted assumptions, rejected assumptions and required rule changes.
5. Run sensitivity ±10% for task weights and relevant rule parameters.
6. Require panel lead and domain owner sign-off before `ATCO_VALIDATED` status.
