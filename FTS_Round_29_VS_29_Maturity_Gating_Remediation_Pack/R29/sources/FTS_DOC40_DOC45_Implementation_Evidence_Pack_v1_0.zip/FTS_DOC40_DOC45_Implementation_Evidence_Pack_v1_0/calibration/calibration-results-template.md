# Calibration Results Template

| Item | Value |
|---|---|
| Calibration set | TBD |
| Scenario / fixture | TBD |
| Ruleset versions | TBD |
| ATCO panel session | TBD |
| Target metrics | TBD |
| Results | TBD |
| Accepted limitations | TBD |
| Required corrections | TBD |
