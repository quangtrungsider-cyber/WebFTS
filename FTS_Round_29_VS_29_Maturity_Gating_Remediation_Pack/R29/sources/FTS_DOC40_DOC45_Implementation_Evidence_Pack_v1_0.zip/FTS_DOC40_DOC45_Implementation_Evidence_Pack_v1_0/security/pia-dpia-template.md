# PIA/DPIA Template

| Section | Required content |
|---|---|
| Processing purpose | Why the data is processed by FTS. |
| Data categories | Traffic, surveillance, weather, performance, personnel/ATCO if any. |
| Data subjects | ATCO/user/personnel if applicable; flight/operator identifiers if sensitive. |
| Legal/contract basis | TBD by VATM legal/data owner. |
| Risk assessment | Confidentiality, integrity, availability, privacy and cross-border risk. |
| Mitigations | Masking, access control, audit, retention, support restrictions. |
| Residual risk | Accepted/rejected with signer. |
