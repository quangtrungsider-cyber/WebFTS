# Threat Model — FTS

## Assets
Scenario data, AIXM/AIRAC, ASTERIX/FDP, traffic/FPL, Weather4D, performance datasets, reports, audit logs, secrets/license tokens, support bundles.

## Primary threats
- Unauthorized export of L3/L4 data.
- BOLA/BFLA access to scenarios, reports or support bundles.
- Secret/license leakage in logs/build artifacts.
- Tampering with sealed scenario, ruleset or evidence hashes.
- Vendor support access outside approved scope.
- SIEM outage causing lost audit evidence.
- Supply-chain risk in container images/dependencies.

## Required mitigations
Classification fail-closed, RBAC/ABAC, masking/de-identification, immutable audit hash chain, evidence hash verification, time-bounded support gateway, SIEM spool, SAST/DAST/SCA/container scan, image signing and SBOM.
