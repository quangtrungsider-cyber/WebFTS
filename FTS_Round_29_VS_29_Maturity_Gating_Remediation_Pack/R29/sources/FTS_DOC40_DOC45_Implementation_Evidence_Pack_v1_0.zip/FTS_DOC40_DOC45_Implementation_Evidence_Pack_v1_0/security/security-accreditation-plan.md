# Security Accreditation Plan

1. Define accreditation boundary and environment: dev, PoC, FAT, SAT, UAT, production-like.
2. Confirm data classification and owner approval for every dataset.
3. Complete threat model and PIA/DPIA.
4. Run secure SDLC controls: SAST, DAST, SCA, secret scan, container scan, IaC scan.
5. Validate RBAC/ABAC, export approval, masking, audit hash chain and SIEM spool.
6. Validate support bundle sanitization and vendor support exceptions.
7. Produce evidence pack and risk acceptance record.
8. Obtain VATM sign-off before using non-synthetic or restricted datasets.
