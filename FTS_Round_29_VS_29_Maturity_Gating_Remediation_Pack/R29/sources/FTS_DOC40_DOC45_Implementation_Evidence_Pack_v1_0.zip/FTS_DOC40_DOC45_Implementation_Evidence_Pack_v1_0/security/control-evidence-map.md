# Control Evidence Map

| Control | Evidence command | Evidence path |
|---|---|---|
| SEC-CLASS-001 | make security-classification-test | evidence/security/classification-policy-test.json |
| SEC-ABAC-001 | make security-authz-test | evidence/security/authz-test-report.json |
| SEC-MASK-001 | make masked-export-test | evidence/security/masked-export-proof.json |
| SEC-AUDIT-001 | make audit-chain-verify | evidence/security/audit-chain-verification.json |
| SEC-SDLC-001 | make security-scan | evidence/security/security-scan-report.json |
