# Data Handling Policy

- All data must have classification before ingestion or export.
- L3/L4 data cannot leave VATM-controlled environments without approved masking and approval record.
- Support bundles must be sanitized and hashed.
- Retention uses hot/warm/cold tiers with legal hold and deletion certificate where allowed.
- No secret, token or private key may be present in source repository, test fixtures, logs or exported reports.
