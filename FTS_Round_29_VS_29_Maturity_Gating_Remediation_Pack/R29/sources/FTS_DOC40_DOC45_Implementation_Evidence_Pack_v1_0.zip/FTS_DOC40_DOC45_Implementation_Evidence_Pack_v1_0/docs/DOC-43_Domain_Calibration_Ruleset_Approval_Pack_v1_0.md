# DOC-43 — Domain Calibration & Ruleset Approval Pack

## 1. Rà soát và đề xuất

FTS có nhiều tham số domain có rủi ro cao nếu coder hard-code: separation minima, wake matrix, workload weights, BADA fallback, AMAN/DMAN, runway/surface rules và weather-capacity degradation. DOC-43 chuyển các rule này thành YAML versioned artifacts, có lifecycle phê duyệt và ATCO validation protocol.

Trạng thái tài liệu: **GENERATED_DRAFT_PENDING_VATM_REVIEW_AND_SIGNOFF**.

## 2. Ruleset artifacts

| Artifact | Path | Status |
|---|---|---|
| Separation profiles | `rules/separation-ruleset.yaml` | PENDING_VATM_SIGNOFF |
| Wake matrix | `rules/wake-rules.yaml` | PENDING_VATM_SIGNOFF |
| Workload task weights | `rules/workload-weights.yaml` | DRAFT_NEEDS_ATCO_PANEL |
| AMAN/DMAN behaviour | `rules/aman-dman-behaviour.yaml` | PENDING_VATM_SIGNOFF |
| Weather capacity degradation | `rules/weather-capacity-degradation.yaml` | PENDING_VATM_SIGNOFF |
| BADA fallback policy | `rules/bada-fallback-policy.yaml` | PENDING_VATM_SIGNOFF |
| Runway capacity rules | `rules/runway-capacity-rules.yaml` | DRAFT |
| Surface rules | `rules/surface-rules.yaml` | DRAFT |
| Report limitation rules | `rules/report-limitation-rules.yaml` | DRAFT |

## 3. Calibration artifacts

| Artifact | Path |
|---|---|
| Calibration manifest | `calibration/calibration-manifest.yaml` |
| Calibration datasets | `calibration/calibration-datasets.yaml` |
| Target metrics | `calibration/target-metrics.yaml` |
| Sensitivity plan | `calibration/sensitivity-plan.yaml` |
| ATCO panel register | `calibration/atco-panel-register.yaml` |
| ATCO validation protocol | `calibration/atco-validation-protocol.md` |

## 4. Approval lifecycle

| State | Meaning | Required signer |
|---|---|---|
| DRAFT | Technical draft only. | Technical owner. |
| SME_REVIEWED | Domain SME reviewed logic. | Domain SME. |
| ATCO_VALIDATED | ATCO panel validated realism. | ATCO panel lead. |
| SECURITY_REVIEWED | Security/data handling reviewed. | Security owner. |
| VATM_APPROVED | Approved for PoC/FAT/SAT/UAT. | VATM authority. |
| SUPERSEDED | Retired for new runs but retained for replay. | Change owner. |

## 5. Validation commands

```bash
make docs43-validate
make ruleset-schema-check
make no-hardcoded-domain-rule-scan
make calibration-manifest-check
make atco-protocol-check
```

## 6. Pass criteria

| Check | Pass condition |
|---|---|
| No hard-code | Domain parameters are read from rulesets and logged in ScenarioRun. |
| Rule trace | Conflict/workload/KPI/report output includes ruleset version. |
| Approval safety | Pending rules trigger limitation banner/report note. |
| Calibration | ATCO validation and sensitivity are required before approval. |
