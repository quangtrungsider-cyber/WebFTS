# Rule Change Control

Every ruleset change requires: change request ID, impacted features, impacted fixtures/oracles, security/data classification check, before/after scenario run evidence, SME review and VATM sign-off decision. Changes after finalized evaluation require correction/supersede record and cannot silently rewrite past evidence.
