# Ruleset Governance

- No separation, wake, workload, BADA fallback, AMAN/DMAN or capacity-degradation logic may be hard-coded.
- Rulesets are versioned artifacts under `/rules` and must be referenced in every ScenarioRun manifest.
- `PENDING_VATM_SIGNOFF` rulesets may be used only for dev/synthetic testing with report limitation.
- Approved rulesets must not be retroactively changed; use supersede/correction trail.
