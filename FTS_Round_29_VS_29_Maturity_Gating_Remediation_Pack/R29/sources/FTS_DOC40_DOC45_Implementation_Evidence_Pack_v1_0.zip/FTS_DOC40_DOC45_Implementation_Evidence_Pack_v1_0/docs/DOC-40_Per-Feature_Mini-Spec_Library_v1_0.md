# DOC-40 — Per-Feature Mini-Spec Library M-01…M-18

## 1. Rà soát và đề xuất

DOC-40 được đề xuất để biến backlog/module FTS thành các mini-spec có thể code ngay. Bộ nguồn đã có AppSpec, BRD/FRD, Tầng 0–10, SOP 1-coder, DOC-35 đến DOC-39; khoảng trống còn lại là từng feature chưa có file mini-spec pre-filled với scope, endpoint, event, table, rule, test, security, UI và evidence. DOC-40 đóng khoảng trống đó.

Trạng thái tài liệu: **GENERATED_DRAFT_PENDING_VATM_REVIEW_AND_SIGNOFF**. Tất cả mục domain/security/legal/data-owner còn ở trạng thái chờ ký trong DOC-39 phải được giữ là blocker/limitation, không được coder tự suy diễn.

## 2. Source basis

- AT04_FTS_AppSpec_VATM_v8_5_NextGen_MasterBlueprint.docx
- VATM_FTS_BRD_FRD_De_xuat_v1_1_Zero_Loophole_Developer_Ready_05_2026.docx
- FTS_Tang_0_DOC00_DOC00_1_Quy_tac_van_hanh_Toi_thuong_v2_5.docx
- FTS_Tang_1_DOC01_DOC04_Hoan_thien_v2_3.docx
- FTS_Tang_2_DOC05_DOC07_Hoan_thien_v2_7_Production_Hardened.docx
- FTS_Tang_3_DOC08_DOC11_5_Interface_Contracts_Hoan_thien_v2_9_Extreme_Scale_Hardened.docx
- FTS_Tang_4_DOC12_DOC16_Data_Specification_Hoan_thien_v3_1_Extreme_Scale_Data_Layer.docx
- FTS_Tang_5_DOC17_DOC19_5_Business_Rules_Calculation_Hoan_thien_v3_3_Ultimate_Logic_Realism_Hardened.docx
- FTS_Tang_6_DOC20_DOC22_Security_Privacy_Implementation_Pack_v1_1_Military_Grade_Hardened.docx
- FTS_Tang_7_DOC23_DOC25_Domain_Simulation_Engine_Protocol_Pack_v1_1_Ultimate_Domain_Physics_Hardened.docx
- FTS_Tang_8_DOC26_DOC28_Frontend_UX_Implementation_Hoan_thien_v3_1_Extreme_Performance_ATCO_Grade_UI.docx
- FTS_Tang_9_DOC29_DOC30_DOC30_5_Testing_Reference_Ultimate_Test_Hardened_v1_1.docx
- FTS_Tang_10_DOC31_DOC34_DevOps_Operations_Reference_Ultimate_Enterprise_Ops_Hardened_v1_1.docx
- FTS_Quy_trinh_chuan_1_coder_v1_1_Ultimate_Solo_Dev_Survival_Hardened.docx
- DOC-35_Master_Index_Source-of-Truth_Map_v1_0.docx
- DOC-36_Implementation_Master_Plan_Vertical_Slice_Roadmap_v1_0.docx
- DOC-37_Runtime_Materialization_Matrix_v1_0.docx
- DOC-38_Repository_Bootstrap_Scaffold_Pack_v1_0.docx
- DOC-39_Decision_Register_VATM_Signoff_Ledger_v1_0.docx

## 3. Nguyên tắc mini-spec bắt buộc

| Nguyên tắc | Áp dụng |
|---|---|
| Không prose-only | Mỗi mini-spec phải có API/event/table/rule/test/evidence cụ thể. |
| Không hard-code domain | Separation, wake, workload, BADA fallback, AMAN/DMAN phải đọc từ ruleset approved hoặc pending-limited. |
| Không fail-open security | Thiếu classification/license/approval phải fail-closed. |
| Evidence-first | Mỗi feature phải khai báo evidence ngay từ mini-spec. |
| One coder executable | Người code đọc mini-spec + artifact path là biết thứ tự migration → contracts → tests → domain → API/event → UI → evidence. |

## 4. Feature inventory

| Module | Feature | Priority | Slice | Owner service |
|---|---|---|---|---|
| M-01 | Simulation Engine & 4D Trajectory | P0 | VS-06/VS-07 | simulation-engine |
| M-02 | Scenario Manager & DOE | P0 | VS-03/VS-04 | scenario-service |
| M-03 | Aircraft Performance Service | P0 | VS-05 | performance-service |
| M-04 | Weather4D Service | P0 | VS-05 | weather-service |
| M-05 | Separation, Wake & CD&R | P0 | VS-06 | rules-service |
| M-06 | AMAN/DMAN & Flow Behaviour | P1 | VS-08 | flow-service |
| M-07 | Workload & Complexity | P0 | VS-09 | workload-service |
| M-08 | Replay, Heatmap & PIR | P0 | VS-11 | replay-service |
| M-09 | KPI & Reporting | P0 | VS-10 | kpi-report-service |
| M-10 | Data Platform & Storage | P0 | VS-02 | data-platform |
| M-11 | External Integration & ICD Layer | P0 | VS-02/VS-05 | integration-adapters |
| M-12 | Security, Privacy & Audit | P0 | VS-00/VS-12 | security-platform |
| M-13 | UI/UX 4D Visualization | P1 | VS-11 | frontend-app |
| M-14 | DevOps & Operations | P0 | VS-01/VS-13 | platform-ops |
| M-15 | Procurement, PoC & Contract Controls | P1 | VS-14 | acceptance-governance |
| M-16 | Surface & Gate-to-Gate | P1 | VS-16 | surface-service |
| M-17 | Environmental & Sustainability | P1/P2 | VS-17 | environment-kpi-service |
| M-18 | AAM/UAS Integration Readiness | P2 | VS-18 | future-airspace-service |

## 5. P0 build order đề xuất

1. M-12 Security/Privacy nền tảng classification và audit.
2. M-10 Data Platform & Storage.
3. M-02 Scenario Manager & DOE.
4. M-11 External Integration & ICD Layer.
5. M-03 Aircraft Performance Service.
6. M-04 Weather4D Service.
7. M-05 Separation, Wake & CD&R.
8. M-01 Simulation Engine & 4D Trajectory.
9. M-07 Workload & Complexity.
10. M-09 KPI & Reporting.
11. M-08 Replay, Heatmap & PIR.
12. M-14 DevOps & Operations evidence hardening.

## 6. Repo artifacts được tạo

| Artifact | Path |
|---|---|
| Mini-spec index | `docs/40-mini-spec-library/mini-spec-index.yaml` |
| Feature priority map | `docs/40-mini-spec-library/feature-priority-map.yaml` |
| Feature to vertical slice map | `docs/40-mini-spec-library/feature-to-vertical-slice-map.yaml` |
| API/event/table/rule matrix | `docs/40-mini-spec-library/api-event-table-rule-matrix.csv` |
| Evidence matrix | `docs/40-mini-spec-library/evidence-requirement-matrix.yaml` |
| M-01..M-18 mini-spec files | `docs/40-mini-spec-library/M-xx-*.md` |
| Templates | `templates/mini-spec-template.md`, `templates/traceability-template.md`, `templates/test-matrix-template.md` |

## 7. Validation commands

```bash
make docs40-validate
make mini-spec-lint
make traceability-check
make api-event-table-rule-matrix-check
make evidence-contract-check
```

## 8. Pass criteria

| Check | Pass condition |
|---|---|
| Completeness | 18/18 mini-spec files exist. |
| P0 readiness | All P0 mini-specs contain API/event/table/rule/test/security/UI/evidence. |
| Traceability | Each rule/test/evidence points to source docs and expected repo path. |
| Sign-off safety | PENDING_VATM_SIGNOFF items are not marked approved. |
| Coder usability | A coder can start a vertical slice without asking for missing endpoint/table/rule/test/evidence. |
