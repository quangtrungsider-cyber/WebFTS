# DOC-42 — External Data Source & Licensing Pack

## 1. Rà soát và đề xuất

FTS phụ thuộc nhiều nguồn ngoài: AIXM/AIRAC, FPL/traffic, ASTERIX/FDP, Weather4D, BADA/OpenAP, AMDB, emission DB, IdP/SIEM. Nếu không có ICD, parser contract, quarantine policy và license/fallback register, coder sẽ bị buộc phải hỏi lại hoặc tự suy diễn. DOC-42 là lớp chốt dữ liệu ngoài cho implementation pack.

Trạng thái tài liệu: **GENERATED_DRAFT_PENDING_VATM_REVIEW_AND_SIGNOFF**.

## 2. External source matrix

| Source ID | Source | Formats | Owner | Classification | Fallback |
|---|---|---|---|---|---|
| AIM-AIXM-AIRAC | AIXM/AIRAC | AIXM 5.1/5.1.1, GeoJSON fallback | VATM_AIM_AIS_OWNER_TBD | L2/L3 | synthetic/masked only for dev |
| TRAFFIC-FPL | Traffic/FPL | ICAO FPL 2012, ADEXP, CSV/Parquet | VATM_ATFM_FDP_OWNER_TBD | L2/L3/L4 | synthetic/masked for dev |
| SUR-ASTERIX-FDP | ASTERIX/FDP/Surveillance | ASTERIX CAT062, CAT021, FDP track/FPL, CSV fallback | VATM_CNS_ATM_DATA_OWNER_TBD | L3/L4 | masked/synthetic only |
| WX-WEATHER4D | Weather4D | GRIB2, NetCDF, SIGMET, METAR/TAF fallback | VATM_MET_OWNER_TBD | L2/L3 | allowed only with limitation |
| PERF-BADA-OPENAP | BADA/OpenAP | BADA Family 4, BADA 3, OpenAP | VATM_PROCUREMENT_LEGAL_TBD | License-restricted | BADA3/OpenAP if declared |
| AMDB-SURFACE | AMDB/Surface | AMDB, AIXM, eTOD, airport geometry | VATM_AIM_AIRPORT_OWNER_TBD | L2/L3 | synthetic/masked for dev |
| EMISSION-DB | Emission DB | CSV/JSON methodology factors | VATM_ENV_KPI_OWNER_TBD | L1/L2 | methodology limitation if factors missing |
| IDP-SIEM | IdP/SIEM | OIDC/SAML, syslog, CEF/LEEF/JSON | VATM_IT_SECURITY_OWNER_TBD | L3 | no credential in fixtures |

## 3. Required artifacts

| Artifact | Path |
|---|---|
| External source index | `docs/42-external-data-source-licensing/external-source-index.yaml` |
| Source owner register | `docs/42-external-data-source-licensing/source-owner-register.yaml` |
| License/fallback register | `docs/42-external-data-source-licensing/license-fallback-register.yaml` |
| Parser contract index | `docs/42-external-data-source-licensing/parser-contract-index.yaml` |
| Quarantine policy | `docs/42-external-data-source-licensing/quarantine-policy.yaml` |
| Classification by source | `docs/42-external-data-source-licensing/data-classification-by-source.yaml` |
| ICD documents | `docs/42-external-data-source-licensing/icd/ICD-INT-*.md` |
| JSON Schemas | `schemas/*.schema.json` |

## 4. Parser/quarantine rules

| Rule | Requirement |
|---|---|
| Source hash | Every import must record source object hash. |
| Classification | Missing classification fails closed. |
| License | Missing/invalid license declaration blocks publish. |
| Quarantine | Quarantined data must not be used by active ScenarioRun. |
| Support bundle | Raw sensitive/proprietary data must be excluded or masked. |

## 5. Validation commands

```bash
make docs42-validate
make icd-lint
make parser-contract-check
make license-fallback-check
make quarantine-policy-check
```

## 6. Pass criteria

| Check | Pass condition |
|---|---|
| Source coverage | All external sources used by P0 features are indexed. |
| Contract coverage | Every source has ICD + schema + parser contract + quarantine policy. |
| License safety | Proprietary/sensitive sources have explicit fallback and export rules. |
| No raw leakage | Raw operational/proprietary samples are absent from repo. |
