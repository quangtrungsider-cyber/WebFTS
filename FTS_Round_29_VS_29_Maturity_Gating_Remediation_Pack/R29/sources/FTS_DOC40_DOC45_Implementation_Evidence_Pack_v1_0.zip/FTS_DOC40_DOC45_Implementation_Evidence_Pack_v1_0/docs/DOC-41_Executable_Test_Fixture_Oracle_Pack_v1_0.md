# DOC-41 — Executable Test Fixture & Oracle Pack

## 1. Rà soát và đề xuất

Tầng 9 đã mô tả testing/V&V, nhưng để coder tự phát triển không cần hỏi thêm thì phải có fixture executable, seed deterministic, expected result và hash oracle. DOC-41 chuyển yêu cầu test thành pack chạy được trong repo.

Trạng thái tài liệu: **GENERATED_DRAFT_PENDING_VATM_REVIEW_AND_SIGNOFF**. Các fixture hiện là synthetic/masked; khi VATM cung cấp dữ liệu golden thật, phải cập nhật manifest, de-identification note, hash và sign-off.

## 2. Artifact inventory

| Artifact | Path |
|---|---|
| Dataset manifest | `fixtures/dataset-manifest.yaml` |
| Fixture catalog | `fixtures/fixture-catalog.yaml` |
| Deterministic seeds | `fixtures/deterministic-seeds.yaml` |
| Hash oracle | `fixtures/hash-oracle.yaml` |
| Dirty data catalog | `fixtures/dirty-data-catalog.yaml` |
| Oracle policy | `fixtures/oracle-policy.yaml` |
| Gherkin suites | `tests/gherkin/*.feature` |
| Pytest skeletons | `tests/pytest/*.py` |
| Playwright skeletons | `tests/playwright/*.spec.ts` |

## 3. Golden fixture catalogue

| Fixture ID | Purpose | Expected oracle |
|---|---|---|
| FTS-GOLDEN-001-PEAK-DAY | Synthetic masked peak-day baseline | Synthetic/masked input + expected hash oracle |
| FTS-GOLDEN-002-DCB-HOTSPOT | Synthetic DCB hotspot and sector saturation | Synthetic/masked input + expected hash oracle |
| FTS-GOLDEN-003-CROSS-BORDER | Synthetic cross-border LoA/handoff workload | Synthetic/masked input + expected hash oracle |
| FTS-GOLDEN-004-MET-ADVERSE | Synthetic convective weather degradation | Synthetic/masked input + expected hash oracle |
| FTS-GOLDEN-005-AIRAC-TRANSITION | Synthetic AIRAC effective-date transition | Synthetic/masked input + expected hash oracle |
| FTS-GOLDEN-006-INTEGRATION-OUTAGE | Synthetic worker/broker/object outage recovery | Synthetic/masked input + expected hash oracle |
| FTS-GOLDEN-007-SEALED-POC | Synthetic sealed PoC benchmark pack | Synthetic/masked input + expected hash oracle |

## 4. Dirty-data fixtures

| Dirty fixture | Expected result |
|---|---|
| missing-fix | Scenario validation rejects orphan reference. |
| invalid-airac | Scenario validation rejects outside effective date. |
| malformed-asterix | Parser contract quarantines dataset. |
| weather-missing-level | Weather4D fails critical missing layer or records limitation. |
| bada-missing-type | Performance fallback uses approved policy and logs limitation. |
| callsign-collision | Integration layer flags collision/deduplication ambiguity. |
| l4-export-attempt | Security layer denies raw export and audits event. |

## 5. Oracle policy

| Oracle type | Applies to | Pass condition |
|---|---|---|
| Bit-equal | Manifest hash, sealed scenario, conflict log golden | Exact SHA-256 or exact serialized output. |
| Epsilon | Weather interpolation, trajectory numeric samples | Domain-defined tolerance, recorded in oracle file. |
| Statistical | Monte Carlo CI95, distribution checks | CI95 or statistical threshold documented. |
| Human-validation | ATCO realism, UAT/PIR feedback | Signed protocol and issue disposition. |

## 6. Validation commands

```bash
make docs41-validate
make fixtures-hash-check
pytest tests/pytest/test_oracle_hashes.py
pytest tests/pytest
npx playwright test tests/playwright
```

## 7. Pass criteria

| Check | Pass condition |
|---|---|
| Manifest integrity | Every fixture file listed with SHA-256. |
| Determinism | Every golden fixture has a seed vector. |
| Dirty-data coverage | Each blocker class has a negative fixture. |
| Executable tests | Hash test can run without external services. |
| Upgrade path | Real VATM golden data can replace synthetic sample by changing manifest + hashes + sign-off only. |
