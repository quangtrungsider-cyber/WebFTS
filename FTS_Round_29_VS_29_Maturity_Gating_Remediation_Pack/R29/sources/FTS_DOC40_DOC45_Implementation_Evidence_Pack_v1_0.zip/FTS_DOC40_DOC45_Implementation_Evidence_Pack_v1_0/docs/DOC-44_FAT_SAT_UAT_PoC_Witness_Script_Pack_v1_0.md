# DOC-44 — FAT/SAT/UAT/PoC Witness Script Pack

## 1. Rà soát và đề xuất

AppSpec/BRD/FRD yêu cầu PoC sealed scenario và nghiệm thu bằng bằng chứng. DOC-44 chuyển yêu cầu này thành witness scripts, scoring rubric, anti-gaming dynamic salt, pass/fail threshold, evidence checklist và sign-off templates.

Trạng thái tài liệu: **GENERATED_DRAFT_PENDING_VATM_REVIEW_AND_SIGNOFF**.

## 2. Gate scope

| Gate | Purpose | Environment | Evidence |
|---|---|---|---|
| PoC | Prove real capability using sealed scenario before deeper scoring or financial opening. | Vendor/VATM-controlled testbed. | Sealed hash, live run log, KPI/conflict/report, scoring. |
| FAT | Verify functions, performance, security and V&V at factory/lab. | Factory/test env. | Test report, CI artifacts, security scan, fixture oracle. |
| SAT | Verify deployment in VATM/on-prem/air-gap context. | VATM target env. | Install log, data import, network, air-gap, backup/restore, performance. |
| UAT | Verify VATM user workflow, realism, reports and limitations. | VATM UAT env. | ATCO/analyst sign-off, issue log, UAT minutes. |
| PIR | Compare before-after or post-study outcomes. | VATM analysis env. | PIR dossier, feedback, recalibration notes. |

## 3. Scoring rubric

| Category | Hard gate | Points | Fail condition |
|---|---|---|---|
| Sealed scenario integrity | True | 0 | Hash mismatch or scenario modified after seal |
| Data import/QA/quarantine | True | 10 | Invalid data accepted silently |
| Scenario lifecycle | True | 10 | Freeze not immutable or missing AIRAC/seed/hash |
| Simulation determinism | True | 15 | Golden replay not reproducible |
| Separation/wake/rules | True | 10 | Rule hard-coded or rule change does not affect output reasonably |
| Workload/KPI/report | True | 10 | KPI lacks formula/source/CI/limitation |
| Replay/UI | False | 10 | UI unusable or replay not traceable |
| Security/export/audit | True | 15 | Raw L3/L4 leakage, missing audit, fail-open ABAC |
| DevOps/Ops evidence | True | 10 | Missing SBOM/signature/security scan/runbook |
| UAT realism | False | 10 | SME/ATCO rejects realism without accepted limitation |

## 4. Required artifacts

| Artifact | Path |
|---|---|
| Witness runbook | `acceptance/witness-runbook.yaml` |
| Scoring rubric | `acceptance/scoring-rubric.yaml` |
| Dynamic salt policy | `acceptance/dynamic-salt-policy.yaml` |
| Pass/fail thresholds | `acceptance/pass-fail-thresholds.yaml` |
| Sealed scenario manifest | `acceptance/sealed-scenario-manifest.yaml` |
| Evidence manifest schema | `acceptance/evidence-manifest.schema.json` |
| Witness scripts | `docs/44-fat-sat-uat-poc-witness/*-witness-script.md` |
| Sign-off templates | `docs/44-fat-sat-uat-poc-witness/signoff-minutes-template.md` |

## 5. Validation commands

```bash
make docs44-validate
make acceptance-rubric-check
make sealed-scenario-hash-check
make evidence-manifest-validate
make witness-script-dry-run
```

## 6. Pass criteria

| Check | Pass condition |
|---|---|
| Hard gates | All hard gates pass before weighted score. |
| Dynamic salt | Salt generated at witness time and recorded without changing objective. |
| Evidence | Evidence manifest contains build/data/ruleset/run/report/security hashes. |
| Sign-off | Minutes include issue disposition and accepted limitations. |
