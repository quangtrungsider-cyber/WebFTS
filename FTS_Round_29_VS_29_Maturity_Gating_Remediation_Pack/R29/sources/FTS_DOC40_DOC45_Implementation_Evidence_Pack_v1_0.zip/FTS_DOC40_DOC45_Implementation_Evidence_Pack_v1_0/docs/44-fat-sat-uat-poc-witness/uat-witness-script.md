# UAT Witness Script

## Steps

1. Pre-brief scope, participants, environment and build.
2. Lock evidence folder and record hashes.
3. Verify environment, image digest, config, license/fallback status.
4. Import relevant data pack and run QA/quarantine.
5. Validate/freeze scenario and record manifest.
6. Execute run and collect logs/events/KPI/replay/report.
7. Check oracle, security/export/audit and UI evidence.
8. Score against `acceptance/scoring-rubric.yaml`.
9. Record issues, limitations and pass/fail result.
10. Sign minutes.
