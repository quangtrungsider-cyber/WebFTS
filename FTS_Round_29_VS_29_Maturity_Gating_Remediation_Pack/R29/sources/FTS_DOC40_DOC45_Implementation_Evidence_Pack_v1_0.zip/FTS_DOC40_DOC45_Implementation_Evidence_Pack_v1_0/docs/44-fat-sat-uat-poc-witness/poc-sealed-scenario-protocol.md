# PoC Sealed Scenario Protocol

1. VATM witness lead prepares sealed scenario data pack and hashes.
2. Vendor is informed of schema and interfaces but not exact salted values before the run.
3. Dynamic salt is generated immediately before witness run and recorded.
4. Scenario is imported, validated, frozen, executed and scored.
5. Hard gates are evaluated before weighted score.
6. Evidence pack is locked and signed.
