# Evidence Checklist

| Evidence | Required for | Present | Notes |
|---|---|---|---|
| Build/version/image digest | PoC/FAT/SAT/UAT |  |  |
| SBOM and security scan | FAT/SAT |  |  |
| Data pack manifest/hash | All |  |  |
| Ruleset versions | All |  |  |
| Scenario freeze hash | All |  |  |
| Run manifest and seed vector | All |  |  |
| KPI/conflict/replay/report hashes | All |  |  |
| Masked export proof | PoC/FAT/SAT/UAT |  |  |
| Sign-off minutes | All |  |  |
