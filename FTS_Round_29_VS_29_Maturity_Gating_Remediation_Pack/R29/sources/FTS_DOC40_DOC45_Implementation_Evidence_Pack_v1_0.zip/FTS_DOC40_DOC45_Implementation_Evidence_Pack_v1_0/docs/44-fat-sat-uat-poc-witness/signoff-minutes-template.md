# Sign-off Minutes

| Field | Value |
|---|---|
| Witness run ID | TBD |
| Gate | PoC/FAT/SAT/UAT/PIR |
| Build version | TBD |
| Data pack hash | TBD |
| Ruleset versions | TBD |
| Result | PASS/FAIL/CONDITIONAL |
| Limitations accepted | TBD |
| Required follow-up | TBD |
| VATM witness lead | TBD |
| Vendor lead | TBD |
