# Witness Governance

Witness runs must be performed with named attendees, locked environment evidence, build/image/config hashes, data pack hashes, ruleset versions, and issue disposition log. Demo-only outcomes without evidence manifest do not satisfy DOC-44.
