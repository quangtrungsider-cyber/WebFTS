# Sample Data Policy

- Raw operational data must not be committed to the repository.
- Synthetic or masked samples are allowed only when classification and de-identification notes are present.
- Proprietary licensed data such as BADA must not be bundled unless the EULA explicitly allows it.
- Support bundles must be sanitized according to DOC-45 masking/de-identification rules.
- Every sample file must appear in a manifest with SHA-256 hash and source declaration.
