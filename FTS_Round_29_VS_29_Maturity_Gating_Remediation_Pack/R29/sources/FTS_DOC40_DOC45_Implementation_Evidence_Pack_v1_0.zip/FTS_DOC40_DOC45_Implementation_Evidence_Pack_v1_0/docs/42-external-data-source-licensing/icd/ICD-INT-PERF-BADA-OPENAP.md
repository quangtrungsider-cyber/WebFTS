# ICD-INT-PERF-BADA-OPENAP — BADA/OpenAP

## 1. Source identity

| Field | Value |
|---|---|
| Source ID | PERF-BADA-OPENAP |
| Source name | BADA/OpenAP |
| Owner | VATM_PROCUREMENT_LEGAL_TBD |
| Accepted formats | BADA Family 4, BADA 3, OpenAP |
| Default classification | License-restricted |
| Fallback policy | BADA3/OpenAP if declared |

## 2. Parser contract

- Input schema: `schemas/perf-bada-openap.schema.json`.
- Parser must validate schema, units, time validity, source hash and classification label.
- Parser must produce `import_job`, `dataset_manifest`, `quality_report` and `quarantine_record` if failed.
- Silent fallback is prohibited.

## 3. Quarantine rules

| Condition | Action |
|---|---|
| Missing license/owner approval | Quarantine and block publish. |
| Invalid schema/unit/time validity | Quarantine and emit validation report. |
| Missing classification | Fail-closed. |
| Critical domain coverage missing | Block scenario freeze or record approved limitation. |

## 4. Evidence

- Parser validation report.
- Source owner approval.
- License/fallback declaration.
- Hash manifest.
- Classification/masking proof for any export.
