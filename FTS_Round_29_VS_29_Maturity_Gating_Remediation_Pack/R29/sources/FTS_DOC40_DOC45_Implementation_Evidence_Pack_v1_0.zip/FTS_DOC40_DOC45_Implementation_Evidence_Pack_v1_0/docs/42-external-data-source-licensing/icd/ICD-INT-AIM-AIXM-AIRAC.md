# ICD-INT-AIM-AIXM-AIRAC — AIXM/AIRAC

## 1. Source identity

| Field | Value |
|---|---|
| Source ID | AIM-AIXM-AIRAC |
| Source name | AIXM/AIRAC |
| Owner | VATM_AIM_AIS_OWNER_TBD |
| Accepted formats | AIXM 5.1/5.1.1, GeoJSON fallback |
| Default classification | L2/L3 |
| Fallback policy | synthetic/masked only for dev |

## 2. Parser contract

- Input schema: `schemas/aim-aixm-airac.schema.json`.
- Parser must validate schema, units, time validity, source hash and classification label.
- Parser must produce `import_job`, `dataset_manifest`, `quality_report` and `quarantine_record` if failed.
- Silent fallback is prohibited.

## 3. Quarantine rules

| Condition | Action |
|---|---|
| Missing license/owner approval | Quarantine and block publish. |
| Invalid schema/unit/time validity | Quarantine and emit validation report. |
| Missing classification | Fail-closed. |
| Critical domain coverage missing | Block scenario freeze or record approved limitation. |

## 4. Evidence

- Parser validation report.
- Source owner approval.
- License/fallback declaration.
- Hash manifest.
- Classification/masking proof for any export.
