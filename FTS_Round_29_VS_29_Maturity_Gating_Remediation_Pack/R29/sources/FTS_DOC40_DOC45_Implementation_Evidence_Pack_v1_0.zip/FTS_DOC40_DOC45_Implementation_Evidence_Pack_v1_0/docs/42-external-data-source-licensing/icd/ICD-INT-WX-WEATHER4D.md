# ICD-INT-WX-WEATHER4D — Weather4D

## 1. Source identity

| Field | Value |
|---|---|
| Source ID | WX-WEATHER4D |
| Source name | Weather4D |
| Owner | VATM_MET_OWNER_TBD |
| Accepted formats | GRIB2, NetCDF, SIGMET, METAR/TAF fallback |
| Default classification | L2/L3 |
| Fallback policy | allowed only with limitation |

## 2. Parser contract

- Input schema: `schemas/wx-weather4d.schema.json`.
- Parser must validate schema, units, time validity, source hash and classification label.
- Parser must produce `import_job`, `dataset_manifest`, `quality_report` and `quarantine_record` if failed.
- Silent fallback is prohibited.

## 3. Quarantine rules

| Condition | Action |
|---|---|
| Missing license/owner approval | Quarantine and block publish. |
| Invalid schema/unit/time validity | Quarantine and emit validation report. |
| Missing classification | Fail-closed. |
| Critical domain coverage missing | Block scenario freeze or record approved limitation. |

## 4. Evidence

- Parser validation report.
- Source owner approval.
- License/fallback declaration.
- Hash manifest.
- Classification/masking proof for any export.
