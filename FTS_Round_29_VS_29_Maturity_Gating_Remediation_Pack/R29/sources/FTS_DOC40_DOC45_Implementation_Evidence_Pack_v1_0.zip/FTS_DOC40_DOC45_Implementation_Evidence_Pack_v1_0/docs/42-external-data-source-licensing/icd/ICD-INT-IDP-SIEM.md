# ICD-INT-IDP-SIEM — IdP/SIEM

## 1. Source identity

| Field | Value |
|---|---|
| Source ID | IDP-SIEM |
| Source name | IdP/SIEM |
| Owner | VATM_IT_SECURITY_OWNER_TBD |
| Accepted formats | OIDC/SAML, syslog, CEF/LEEF/JSON |
| Default classification | L3 |
| Fallback policy | no credential in fixtures |

## 2. Parser contract

- Input schema: `schemas/idp-siem.schema.json`.
- Parser must validate schema, units, time validity, source hash and classification label.
- Parser must produce `import_job`, `dataset_manifest`, `quality_report` and `quarantine_record` if failed.
- Silent fallback is prohibited.

## 3. Quarantine rules

| Condition | Action |
|---|---|
| Missing license/owner approval | Quarantine and block publish. |
| Invalid schema/unit/time validity | Quarantine and emit validation report. |
| Missing classification | Fail-closed. |
| Critical domain coverage missing | Block scenario freeze or record approved limitation. |

## 4. Evidence

- Parser validation report.
- Source owner approval.
- License/fallback declaration.
- Hash manifest.
- Classification/masking proof for any export.
