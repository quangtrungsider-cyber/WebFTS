# ICD-INT-TRAFFIC-FPL — Traffic/FPL

## 1. Source identity

| Field | Value |
|---|---|
| Source ID | TRAFFIC-FPL |
| Source name | Traffic/FPL |
| Owner | VATM_ATFM_FDP_OWNER_TBD |
| Accepted formats | ICAO FPL 2012, ADEXP, CSV/Parquet |
| Default classification | L2/L3/L4 |
| Fallback policy | synthetic/masked for dev |

## 2. Parser contract

- Input schema: `schemas/traffic-fpl.schema.json`.
- Parser must validate schema, units, time validity, source hash and classification label.
- Parser must produce `import_job`, `dataset_manifest`, `quality_report` and `quarantine_record` if failed.
- Silent fallback is prohibited.

## 3. Quarantine rules

| Condition | Action |
|---|---|
| Missing license/owner approval | Quarantine and block publish. |
| Invalid schema/unit/time validity | Quarantine and emit validation report. |
| Missing classification | Fail-closed. |
| Critical domain coverage missing | Block scenario freeze or record approved limitation. |

## 4. Evidence

- Parser validation report.
- Source owner approval.
- License/fallback declaration.
- Hash manifest.
- Classification/masking proof for any export.
