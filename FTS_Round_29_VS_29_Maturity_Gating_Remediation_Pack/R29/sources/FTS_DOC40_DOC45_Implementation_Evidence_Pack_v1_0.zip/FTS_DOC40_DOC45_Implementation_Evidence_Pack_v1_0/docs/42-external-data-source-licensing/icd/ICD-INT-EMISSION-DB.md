# ICD-INT-EMISSION-DB — Emission DB

## 1. Source identity

| Field | Value |
|---|---|
| Source ID | EMISSION-DB |
| Source name | Emission DB |
| Owner | VATM_ENV_KPI_OWNER_TBD |
| Accepted formats | CSV/JSON methodology factors |
| Default classification | L1/L2 |
| Fallback policy | methodology limitation if factors missing |

## 2. Parser contract

- Input schema: `schemas/emission-db.schema.json`.
- Parser must validate schema, units, time validity, source hash and classification label.
- Parser must produce `import_job`, `dataset_manifest`, `quality_report` and `quarantine_record` if failed.
- Silent fallback is prohibited.

## 3. Quarantine rules

| Condition | Action |
|---|---|
| Missing license/owner approval | Quarantine and block publish. |
| Invalid schema/unit/time validity | Quarantine and emit validation report. |
| Missing classification | Fail-closed. |
| Critical domain coverage missing | Block scenario freeze or record approved limitation. |

## 4. Evidence

- Parser validation report.
- Source owner approval.
- License/fallback declaration.
- Hash manifest.
- Classification/masking proof for any export.
