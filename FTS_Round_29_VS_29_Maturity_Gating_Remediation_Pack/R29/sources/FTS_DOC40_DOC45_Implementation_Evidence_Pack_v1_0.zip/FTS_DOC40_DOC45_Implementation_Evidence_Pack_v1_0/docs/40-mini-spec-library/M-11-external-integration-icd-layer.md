# M-11 — External Integration & ICD Layer

**Status:** GENERATED_DRAFT_PENDING_VATM_REVIEW_AND_SIGNOFF  
**Priority:** P0  
**Owner service:** `integration-adapters`  
**Vertical slice:** VS-02/VS-05  

## 1. Scope / out-of-scope / authority

| Field | Value |
|---|---|
| Scope | Adapters and ICD contracts for AIXM/AIRAC, traffic/FPL, ASTERIX/FDP, Weather4D, BADA/OpenAP, AMDB, emission DB, IdP/SIEM. |
| Out-of-scope | Không ingest production raw feeds without license/data-owner approval. |
| Source-of-truth | AppSpec, DOC-08, DOC-09, DOC-10, DOC-11, DOC-42 |
| Authority blocker | Any `PENDING_VATM_SIGNOFF` rule must remain feature limitation and cannot be silently treated as approved. |

## 2. Contracts touched

| Type | Items |
|---|---|
| API endpoints | POST /integrations/{source}/imports, GET /integrations/{source}/status, GET /quarantine/{id} |
| Domain events | external.dataset.received, external.dataset.validated, external.dataset.quarantined, external.dataset.published |
| Tables / objects | external_source, import_job, parser_contract, quarantine_record, license_declaration |
| Screens / UI | Integration registry, Import status, Quarantine report |

## 3. Rule IDs / state IDs / error codes

| Type | Required prefilled values |
|---|---|
| Rule IDs | BR-INT-PARSER-001, BR-INT-QUARANTINE-001, BR-INT-LICENSE-001 |
| State IDs | `draft`, `validated`, `frozen`, `queued`, `running`, `completed`, `failed`, `archived` where applicable |
| Error code convention | `ERR-M11-###`; problem+json response required for API failures |
| Idempotency | Mutating POST endpoints require idempotency key where retry can duplicate state. |

## 4. Data classification

| Payload / data | Default classification | Handling |
|---|---|---|
| Public docs / synthetic fixture | L1/L2 | Commit allowed if no sensitive identifier. |
| Scenario input with masked operational data | L2/L3 | Export only with classification badge and audit. |
| ASTERIX/FDP/callsign/ATCO/military/VIP/restricted areas | L3/L4 | No raw export or vendor support bundle without approval and obfuscation. |
| Secrets/license tokens | Secret | Never log, never commit, never expose to frontend. |

## 5. Happy path / error path / compensation / replay / time path

| Path | Behaviour |
|---|---|
| Happy path | Validate contracts → persist state/event → compute or enqueue work → emit domain event → update evidence. |
| Error path | Fail-closed for missing classification/license/source hash/rule version; return problem+json; audit error. |
| Compensation | No destructive rollback for sealed/frozen/audit records; use correction/supersede event. |
| Replay path | Re-run with same manifest/seed/ruleset must produce deterministic hash or declared numeric tolerance. |
| Time path | Use UTC timestamps; store local offset only for display; scenario AIRAC effective date must be explicit. |

## 6. Tests

| Test class | Required tests |
|---|---|
| Unit | Rule table, parser, validation, hash and classification unit tests. |
| Contract | OpenAPI/AsyncAPI/schema round-trip; problem+json negative cases. |
| Integration | DB migration + event emission + evidence write + audit trail. |
| Security | RBAC/ABAC negative tests, masking, export denial, secret scan where applicable. |
| Performance/time | Determinism/time travel/replay and target latency/FPS/worker SLA where applicable. |
| Named test IDs | TC-INT-AIXM-001, TC-INT-ASTERIX-001, TC-INT-WX-001, TC-INT-PERF-001 |

## 7. Observability

| Signal | Required values |
|---|---|
| Metrics | fts_import_job_duration_seconds, fts_quarantine_total |
| Logs | JSON log with correlation_id, actor, feature_id, source_hash, rule_version where applicable. |
| Traces | Span names follow `fts.integration-adapters.<operation>`. |
| Alerts | Alert on fail-open, unclassified export, queue stall, hash mismatch, missing evidence. |

## 8. Migration / rollout / rollback

- Migration must be additive-first unless approved otherwise.
- Append-only audit, sealed scenario, report export and evidence stores must not have application UPDATE/DELETE path.
- Rollback uses feature flag or forward-fix; sealed/finalized records require correction/supersede trail.
- Any unresolved data, license, rule or security uncertainty must be recorded in `SPEC-GAPS.md` or `RUNTIME-GAPS.md`.

## 9. Evidence links

| Evidence | Required path pattern |
|---|---|
| Feature mini-spec | `docs/40-mini-spec-library/M-11-external-integration-icd-layer.md` |
| Traceability | `features/M-11/TRACEABILITY.md` |
| Test matrix | `features/M-11/TEST-MATRIX.md` |
| Security evidence | `features/M-11/SECURITY-EVIDENCE.md` |
| Runtime evidence | external-source-index.yaml, parser-contract-index.yaml, quarantine-report.json |
