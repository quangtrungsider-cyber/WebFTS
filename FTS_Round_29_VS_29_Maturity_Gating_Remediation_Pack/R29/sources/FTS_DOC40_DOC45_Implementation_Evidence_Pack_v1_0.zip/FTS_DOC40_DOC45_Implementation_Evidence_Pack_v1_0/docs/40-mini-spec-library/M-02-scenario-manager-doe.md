# M-02 — Scenario Manager & DOE

**Status:** GENERATED_DRAFT_PENDING_VATM_REVIEW_AND_SIGNOFF  
**Priority:** P0  
**Owner service:** `scenario-service`  
**Vertical slice:** VS-03/VS-04  

## 1. Scope / out-of-scope / authority

| Field | Value |
|---|---|
| Scope | Study/scenario/experiment lifecycle: create, validate, freeze, run, compare, archive; DOE matrix; immutable scenario bundle. |
| Out-of-scope | Không phê duyệt phương án khai thác thật; không thay thế safety case. |
| Source-of-truth | AppSpec, DOC-12, DOC-13, DOC-29, DOC-36, DOC-39 |
| Authority blocker | Any `PENDING_VATM_SIGNOFF` rule must remain feature limitation and cannot be silently treated as approved. |

## 2. Contracts touched

| Type | Items |
|---|---|
| API endpoints | POST /scenarios, GET /scenarios/{id}, POST /scenarios/{id}/validate, POST /scenarios/{id}/freeze, POST /scenarios/{id}/runs, GET /scenarios/{id}/manifest |
| Domain events | scenario.created, scenario.validation.completed, scenario.frozen, scenario.submitted, scenario.archived |
| Tables / objects | study, scenario, scenario_version, scenario_input_ref, scenario_hash, doe_matrix, scenario_validation_result |
| Screens / UI | Scenario wizard, Validation report, Freeze confirmation, Compare view |

## 3. Rule IDs / state IDs / error codes

| Type | Required prefilled values |
|---|---|
| Rule IDs | BR-SCEN-AIRAC-001, BR-SCEN-FREEZE-001, BR-SCEN-HASH-001, BR-SCEN-DOE-001 |
| State IDs | `draft`, `validated`, `frozen`, `queued`, `running`, `completed`, `failed`, `archived` where applicable |
| Error code convention | `ERR-M02-###`; problem+json response required for API failures |
| Idempotency | Mutating POST endpoints require idempotency key where retry can duplicate state. |

## 4. Data classification

| Payload / data | Default classification | Handling |
|---|---|---|
| Public docs / synthetic fixture | L1/L2 | Commit allowed if no sensitive identifier. |
| Scenario input with masked operational data | L2/L3 | Export only with classification badge and audit. |
| ASTERIX/FDP/callsign/ATCO/military/VIP/restricted areas | L3/L4 | No raw export or vendor support bundle without approval and obfuscation. |
| Secrets/license tokens | Secret | Never log, never commit, never expose to frontend. |

## 5. Happy path / error path / compensation / replay / time path

| Path | Behaviour |
|---|---|
| Happy path | Validate contracts → persist state/event → compute or enqueue work → emit domain event → update evidence. |
| Error path | Fail-closed for missing classification/license/source hash/rule version; return problem+json; audit error. |
| Compensation | No destructive rollback for sealed/frozen/audit records; use correction/supersede event. |
| Replay path | Re-run with same manifest/seed/ruleset must produce deterministic hash or declared numeric tolerance. |
| Time path | Use UTC timestamps; store local offset only for display; scenario AIRAC effective date must be explicit. |

## 6. Tests

| Test class | Required tests |
|---|---|
| Unit | Rule table, parser, validation, hash and classification unit tests. |
| Contract | OpenAPI/AsyncAPI/schema round-trip; problem+json negative cases. |
| Integration | DB migration + event emission + evidence write + audit trail. |
| Security | RBAC/ABAC negative tests, masking, export denial, secret scan where applicable. |
| Performance/time | Determinism/time travel/replay and target latency/FPS/worker SLA where applicable. |
| Named test IDs | TC-SCEN-AIRAC-001, TC-SCEN-ORPHAN-001, TC-SCEN-FREEZE-001, TC-DOE-EXPORT-001 |

## 7. Observability

| Signal | Required values |
|---|---|
| Metrics | fts_scenario_validation_duration_seconds, fts_scenario_freeze_total |
| Logs | JSON log with correlation_id, actor, feature_id, source_hash, rule_version where applicable. |
| Traces | Span names follow `fts.scenario-service.<operation>`. |
| Alerts | Alert on fail-open, unclassified export, queue stall, hash mismatch, missing evidence. |

## 8. Migration / rollout / rollback

- Migration must be additive-first unless approved otherwise.
- Append-only audit, sealed scenario, report export and evidence stores must not have application UPDATE/DELETE path.
- Rollback uses feature flag or forward-fix; sealed/finalized records require correction/supersede trail.
- Any unresolved data, license, rule or security uncertainty must be recorded in `SPEC-GAPS.md` or `RUNTIME-GAPS.md`.

## 9. Evidence links

| Evidence | Required path pattern |
|---|---|
| Feature mini-spec | `docs/40-mini-spec-library/M-02-scenario-manager-doe.md` |
| Traceability | `features/M-02/TRACEABILITY.md` |
| Test matrix | `features/M-02/TEST-MATRIX.md` |
| Security evidence | `features/M-02/SECURITY-EVIDENCE.md` |
| Runtime evidence | scenario-manifest.json, validation-report.json, freeze-audit-event.json |
