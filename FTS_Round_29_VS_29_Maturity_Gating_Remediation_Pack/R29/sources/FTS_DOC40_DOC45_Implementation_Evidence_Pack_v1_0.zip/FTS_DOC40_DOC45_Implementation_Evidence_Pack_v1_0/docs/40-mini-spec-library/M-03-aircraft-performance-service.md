# M-03 — Aircraft Performance Service

**Status:** GENERATED_DRAFT_PENDING_VATM_REVIEW_AND_SIGNOFF  
**Priority:** P0  
**Owner service:** `performance-service`  
**Vertical slice:** VS-05  

## 1. Scope / out-of-scope / authority

| Field | Value |
|---|---|
| Scope | BADA 4 parser/adapter if licensed; BADA 3/OpenAP fallback; aircraft type mapping; performance envelope; fallback limitation logging. |
| Out-of-scope | Không phân phối raw proprietary BADA dataset; không tự chấp thuận license. |
| Source-of-truth | AppSpec, DOC-17, DOC-23, DOC-39, DOC-42 |
| Authority blocker | Any `PENDING_VATM_SIGNOFF` rule must remain feature limitation and cannot be silently treated as approved. |

## 2. Contracts touched

| Type | Items |
|---|---|
| API endpoints | POST /performance-datasets/import, GET /performance-datasets/{id}/status, GET /aircraft-types/{icao}/performance, GET /performance/fallback-policy |
| Domain events | performance.dataset.imported, performance.dataset.validated, performance.fallback.used |
| Tables / objects | performance_dataset, aircraft_type, aircraft_performance_model, performance_envelope, fallback_policy |
| Screens / UI | Dataset status, Fallback banner, Aircraft mapping dashboard |

## 3. Rule IDs / state IDs / error codes

| Type | Required prefilled values |
|---|---|
| Rule IDs | BR-PERF-BADA4-PRIMARY-001, BR-PERF-FALLBACK-001, BR-PERF-ENVELOPE-001 |
| State IDs | `draft`, `validated`, `frozen`, `queued`, `running`, `completed`, `failed`, `archived` where applicable |
| Error code convention | `ERR-M03-###`; problem+json response required for API failures |
| Idempotency | Mutating POST endpoints require idempotency key where retry can duplicate state. |

## 4. Data classification

| Payload / data | Default classification | Handling |
|---|---|---|
| Public docs / synthetic fixture | L1/L2 | Commit allowed if no sensitive identifier. |
| Scenario input with masked operational data | L2/L3 | Export only with classification badge and audit. |
| ASTERIX/FDP/callsign/ATCO/military/VIP/restricted areas | L3/L4 | No raw export or vendor support bundle without approval and obfuscation. |
| Secrets/license tokens | Secret | Never log, never commit, never expose to frontend. |

## 5. Happy path / error path / compensation / replay / time path

| Path | Behaviour |
|---|---|
| Happy path | Validate contracts → persist state/event → compute or enqueue work → emit domain event → update evidence. |
| Error path | Fail-closed for missing classification/license/source hash/rule version; return problem+json; audit error. |
| Compensation | No destructive rollback for sealed/frozen/audit records; use correction/supersede event. |
| Replay path | Re-run with same manifest/seed/ruleset must produce deterministic hash or declared numeric tolerance. |
| Time path | Use UTC timestamps; store local offset only for display; scenario AIRAC effective date must be explicit. |

## 6. Tests

| Test class | Required tests |
|---|---|
| Unit | Rule table, parser, validation, hash and classification unit tests. |
| Contract | OpenAPI/AsyncAPI/schema round-trip; problem+json negative cases. |
| Integration | DB migration + event emission + evidence write + audit trail. |
| Security | RBAC/ABAC negative tests, masking, export denial, secret scan where applicable. |
| Performance/time | Determinism/time travel/replay and target latency/FPS/worker SLA where applicable. |
| Named test IDs | TC-PRF-UNKNOWN-ACFT-001, TC-PRF-FALLBACK-001, TC-PRF-ENVELOPE-001, TC-PRF-LICENSE-001 |

## 7. Observability

| Signal | Required values |
|---|---|
| Metrics | fts_performance_fallback_total, fts_performance_import_duration_seconds |
| Logs | JSON log with correlation_id, actor, feature_id, source_hash, rule_version where applicable. |
| Traces | Span names follow `fts.performance-service.<operation>`. |
| Alerts | Alert on fail-open, unclassified export, queue stall, hash mismatch, missing evidence. |

## 8. Migration / rollout / rollback

- Migration must be additive-first unless approved otherwise.
- Append-only audit, sealed scenario, report export and evidence stores must not have application UPDATE/DELETE path.
- Rollback uses feature flag or forward-fix; sealed/finalized records require correction/supersede trail.
- Any unresolved data, license, rule or security uncertainty must be recorded in `SPEC-GAPS.md` or `RUNTIME-GAPS.md`.

## 9. Evidence links

| Evidence | Required path pattern |
|---|---|
| Feature mini-spec | `docs/40-mini-spec-library/M-03-aircraft-performance-service.md` |
| Traceability | `features/M-03/TRACEABILITY.md` |
| Test matrix | `features/M-03/TEST-MATRIX.md` |
| Security evidence | `features/M-03/SECURITY-EVIDENCE.md` |
| Runtime evidence | performance-import-report.json, fallback-decision-log.json, license-declaration.md |
