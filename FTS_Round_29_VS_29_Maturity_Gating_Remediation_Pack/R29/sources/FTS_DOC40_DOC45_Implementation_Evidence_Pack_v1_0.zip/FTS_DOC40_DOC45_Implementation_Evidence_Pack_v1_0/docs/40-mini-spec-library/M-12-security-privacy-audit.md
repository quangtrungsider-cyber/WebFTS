# M-12 — Security, Privacy & Audit

**Status:** GENERATED_DRAFT_PENDING_VATM_REVIEW_AND_SIGNOFF  
**Priority:** P0  
**Owner service:** `security-platform`  
**Vertical slice:** VS-00/VS-12  

## 1. Scope / out-of-scope / authority

| Field | Value |
|---|---|
| Scope | L1-L4 classification, RBAC/ABAC, masking/obfuscation, immutable audit, export approval, support bundle sanitization, retention/legal hold. |
| Out-of-scope | Không cấp ngoại lệ security không có ledger; không lưu secret trong repo/build logs. |
| Source-of-truth | AppSpec, DOC-20, DOC-21, DOC-22, DOC-39, DOC-45 |
| Authority blocker | Any `PENDING_VATM_SIGNOFF` rule must remain feature limitation and cannot be silently treated as approved. |

## 2. Contracts touched

| Type | Items |
|---|---|
| API endpoints | POST /exports, POST /support-bundles, GET /audit/events, POST /access-reviews, POST /security/exceptions |
| Domain events | export.requested, export.approved, export.downloaded, support.access.granted, audit.hash.verified |
| Tables / objects | classification_policy, abac_policy, export_request, support_case, audit_event, retention_ledger |
| Screens / UI | Classification badge, Export approval modal, Audit viewer, Support case dashboard |

## 3. Rule IDs / state IDs / error codes

| Type | Required prefilled values |
|---|---|
| Rule IDs | BR-SEC-CLASSIFY-001, BR-SEC-ABAC-001, BR-SEC-MASK-001, BR-SEC-AUDIT-HASH-001 |
| State IDs | `draft`, `validated`, `frozen`, `queued`, `running`, `completed`, `failed`, `archived` where applicable |
| Error code convention | `ERR-M12-###`; problem+json response required for API failures |
| Idempotency | Mutating POST endpoints require idempotency key where retry can duplicate state. |

## 4. Data classification

| Payload / data | Default classification | Handling |
|---|---|---|
| Public docs / synthetic fixture | L1/L2 | Commit allowed if no sensitive identifier. |
| Scenario input with masked operational data | L2/L3 | Export only with classification badge and audit. |
| ASTERIX/FDP/callsign/ATCO/military/VIP/restricted areas | L3/L4 | No raw export or vendor support bundle without approval and obfuscation. |
| Secrets/license tokens | Secret | Never log, never commit, never expose to frontend. |

## 5. Happy path / error path / compensation / replay / time path

| Path | Behaviour |
|---|---|
| Happy path | Validate contracts → persist state/event → compute or enqueue work → emit domain event → update evidence. |
| Error path | Fail-closed for missing classification/license/source hash/rule version; return problem+json; audit error. |
| Compensation | No destructive rollback for sealed/frozen/audit records; use correction/supersede event. |
| Replay path | Re-run with same manifest/seed/ruleset must produce deterministic hash or declared numeric tolerance. |
| Time path | Use UTC timestamps; store local offset only for display; scenario AIRAC effective date must be explicit. |

## 6. Tests

| Test class | Required tests |
|---|---|
| Unit | Rule table, parser, validation, hash and classification unit tests. |
| Contract | OpenAPI/AsyncAPI/schema round-trip; problem+json negative cases. |
| Integration | DB migration + event emission + evidence write + audit trail. |
| Security | RBAC/ABAC negative tests, masking, export denial, secret scan where applicable. |
| Performance/time | Determinism/time travel/replay and target latency/FPS/worker SLA where applicable. |
| Named test IDs | TC-SEC-BOLA-001, TC-SEC-MASK-001, TC-SEC-AUDIT-001, TC-SEC-SIEM-SPOOL-001 |

## 7. Observability

| Signal | Required values |
|---|---|
| Metrics | fts_export_denied_total, fts_audit_hash_verify_seconds, fts_siem_spool_depth |
| Logs | JSON log with correlation_id, actor, feature_id, source_hash, rule_version where applicable. |
| Traces | Span names follow `fts.security-platform.<operation>`. |
| Alerts | Alert on fail-open, unclassified export, queue stall, hash mismatch, missing evidence. |

## 8. Migration / rollout / rollback

- Migration must be additive-first unless approved otherwise.
- Append-only audit, sealed scenario, report export and evidence stores must not have application UPDATE/DELETE path.
- Rollback uses feature flag or forward-fix; sealed/finalized records require correction/supersede trail.
- Any unresolved data, license, rule or security uncertainty must be recorded in `SPEC-GAPS.md` or `RUNTIME-GAPS.md`.

## 9. Evidence links

| Evidence | Required path pattern |
|---|---|
| Feature mini-spec | `docs/40-mini-spec-library/M-12-security-privacy-audit.md` |
| Traceability | `features/M-12/TRACEABILITY.md` |
| Test matrix | `features/M-12/TEST-MATRIX.md` |
| Security evidence | `features/M-12/SECURITY-EVIDENCE.md` |
| Runtime evidence | security-control-matrix.yaml, masked-export-proof.json, audit-verification-report.json |
