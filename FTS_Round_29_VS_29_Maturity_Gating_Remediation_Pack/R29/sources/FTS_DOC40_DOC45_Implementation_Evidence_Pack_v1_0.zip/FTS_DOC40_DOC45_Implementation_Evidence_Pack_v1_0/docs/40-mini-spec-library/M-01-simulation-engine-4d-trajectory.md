# M-01 — Simulation Engine & 4D Trajectory

**Status:** GENERATED_DRAFT_PENDING_VATM_REVIEW_AND_SIGNOFF  
**Priority:** P0  
**Owner service:** `simulation-engine`  
**Vertical slice:** VS-06/VS-07  

## 1. Scope / out-of-scope / authority

| Field | Value |
|---|---|
| Scope | Bộ máy mô phỏng 4D deterministic/Monte Carlo; discrete-event scheduler; trajectory propagation; conflict/raw event feed; checkpoint/resume. |
| Out-of-scope | Không dùng làm ATC operational display, không kết nối live ATC, không tự động ra quyết định khai thác. |
| Source-of-truth | AppSpec, DOC-17, DOC-23, DOC-29, DOC-36, DOC-37, DOC-39 |
| Authority blocker | Any `PENDING_VATM_SIGNOFF` rule must remain feature limitation and cannot be silently treated as approved. |

## 2. Contracts touched

| Type | Items |
|---|---|
| API endpoints | POST /runs, GET /runs/{id}, GET /runs/{id}/events, GET /runs/{id}/trajectories, POST /runs/{id}/cancel, POST /runs/{id}/resume |
| Domain events | simulation.run.started, simulation.replication.started, trajectory.generated, conflict.detected, simulation.run.completed, simulation.run.failed |
| Tables / objects | scenario_run, replication_run, trajectory_sample, conflict_event, simulation_checkpoint, run_limitation |
| Screens / UI | Run status/progress, Cancel/resume, Limitation banner, Reproducibility hash |

## 3. Rule IDs / state IDs / error codes

| Type | Required prefilled values |
|---|---|
| Rule IDs | BR-SIM-SEED-001, BR-SIM-DETERMINISM-001, BR-SIM-CHECKPOINT-001, BR-SIM-NO-SILENT-FALLBACK-001 |
| State IDs | `draft`, `validated`, `frozen`, `queued`, `running`, `completed`, `failed`, `archived` where applicable |
| Error code convention | `ERR-M01-###`; problem+json response required for API failures |
| Idempotency | Mutating POST endpoints require idempotency key where retry can duplicate state. |

## 4. Data classification

| Payload / data | Default classification | Handling |
|---|---|---|
| Public docs / synthetic fixture | L1/L2 | Commit allowed if no sensitive identifier. |
| Scenario input with masked operational data | L2/L3 | Export only with classification badge and audit. |
| ASTERIX/FDP/callsign/ATCO/military/VIP/restricted areas | L3/L4 | No raw export or vendor support bundle without approval and obfuscation. |
| Secrets/license tokens | Secret | Never log, never commit, never expose to frontend. |

## 5. Happy path / error path / compensation / replay / time path

| Path | Behaviour |
|---|---|
| Happy path | Validate contracts → persist state/event → compute or enqueue work → emit domain event → update evidence. |
| Error path | Fail-closed for missing classification/license/source hash/rule version; return problem+json; audit error. |
| Compensation | No destructive rollback for sealed/frozen/audit records; use correction/supersede event. |
| Replay path | Re-run with same manifest/seed/ruleset must produce deterministic hash or declared numeric tolerance. |
| Time path | Use UTC timestamps; store local offset only for display; scenario AIRAC effective date must be explicit. |

## 6. Tests

| Test class | Required tests |
|---|---|
| Unit | Rule table, parser, validation, hash and classification unit tests. |
| Contract | OpenAPI/AsyncAPI/schema round-trip; problem+json negative cases. |
| Integration | DB migration + event emission + evidence write + audit trail. |
| Security | RBAC/ABAC negative tests, masking, export denial, secret scan where applicable. |
| Performance/time | Determinism/time travel/replay and target latency/FPS/worker SLA where applicable. |
| Named test IDs | TC-REG-001 bit-equality, TC-SIM-CHK-001 worker restart, TC-SIM-MC-001 N>=30 replication, TC-SIM-LIM-001 fallback limitation |

## 7. Observability

| Signal | Required values |
|---|---|
| Metrics | fts_run_duration_seconds, fts_replication_completed_total, fts_worker_checkpoint_age_seconds, fts_run_limitation_total |
| Logs | JSON log with correlation_id, actor, feature_id, source_hash, rule_version where applicable. |
| Traces | Span names follow `fts.simulation-engine.<operation>`. |
| Alerts | Alert on fail-open, unclassified export, queue stall, hash mismatch, missing evidence. |

## 8. Migration / rollout / rollback

- Migration must be additive-first unless approved otherwise.
- Append-only audit, sealed scenario, report export and evidence stores must not have application UPDATE/DELETE path.
- Rollback uses feature flag or forward-fix; sealed/finalized records require correction/supersede trail.
- Any unresolved data, license, rule or security uncertainty must be recorded in `SPEC-GAPS.md` or `RUNTIME-GAPS.md`.

## 9. Evidence links

| Evidence | Required path pattern |
|---|---|
| Feature mini-spec | `docs/40-mini-spec-library/M-01-simulation-engine-4d-trajectory.md` |
| Traceability | `features/M-01/TRACEABILITY.md` |
| Test matrix | `features/M-01/TEST-MATRIX.md` |
| Security evidence | `features/M-01/SECURITY-EVIDENCE.md` |
| Runtime evidence | run-manifest.json, seed-vector.yaml, input-hash.txt, event-log.parquet, ci-oracle-report.json |
