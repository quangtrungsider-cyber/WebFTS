# M-15 — Procurement, PoC & Contract Controls

**Status:** GENERATED_DRAFT_PENDING_VATM_REVIEW_AND_SIGNOFF  
**Priority:** P1  
**Owner service:** `acceptance-governance`  
**Vertical slice:** VS-14  

## 1. Scope / out-of-scope / authority

| Field | Value |
|---|---|
| Scope | RFP/RFI evidence, sealed PoC, anti-lock-in, milestone gates, payment tied to acceptance, issue disposition. |
| Out-of-scope | Không thay thế legal/procurement approval. |
| Source-of-truth | AppSpec, BRD/FRD, DOC-39, DOC-44 |
| Authority blocker | Any `PENDING_VATM_SIGNOFF` rule must remain feature limitation and cannot be silently treated as approved. |

## 2. Contracts touched

| Type | Items |
|---|---|
| API endpoints | GET /acceptance/evidence, POST /acceptance/witness-runs |
| Domain events | witness.run.started, witness.gate.passed, witness.gate.failed |
| Tables / objects | acceptance_gate, witness_run, issue_disposition, signoff_record |
| Screens / UI | Acceptance evidence viewer |

## 3. Rule IDs / state IDs / error codes

| Type | Required prefilled values |
|---|---|
| Rule IDs | BR-ACC-SEALED-POC-001, BR-ACC-HARD-GATE-001 |
| State IDs | `draft`, `validated`, `frozen`, `queued`, `running`, `completed`, `failed`, `archived` where applicable |
| Error code convention | `ERR-M15-###`; problem+json response required for API failures |
| Idempotency | Mutating POST endpoints require idempotency key where retry can duplicate state. |

## 4. Data classification

| Payload / data | Default classification | Handling |
|---|---|---|
| Public docs / synthetic fixture | L1/L2 | Commit allowed if no sensitive identifier. |
| Scenario input with masked operational data | L2/L3 | Export only with classification badge and audit. |
| ASTERIX/FDP/callsign/ATCO/military/VIP/restricted areas | L3/L4 | No raw export or vendor support bundle without approval and obfuscation. |
| Secrets/license tokens | Secret | Never log, never commit, never expose to frontend. |

## 5. Happy path / error path / compensation / replay / time path

| Path | Behaviour |
|---|---|
| Happy path | Validate contracts → persist state/event → compute or enqueue work → emit domain event → update evidence. |
| Error path | Fail-closed for missing classification/license/source hash/rule version; return problem+json; audit error. |
| Compensation | No destructive rollback for sealed/frozen/audit records; use correction/supersede event. |
| Replay path | Re-run with same manifest/seed/ruleset must produce deterministic hash or declared numeric tolerance. |
| Time path | Use UTC timestamps; store local offset only for display; scenario AIRAC effective date must be explicit. |

## 6. Tests

| Test class | Required tests |
|---|---|
| Unit | Rule table, parser, validation, hash and classification unit tests. |
| Contract | OpenAPI/AsyncAPI/schema round-trip; problem+json negative cases. |
| Integration | DB migration + event emission + evidence write + audit trail. |
| Security | RBAC/ABAC negative tests, masking, export denial, secret scan where applicable. |
| Performance/time | Determinism/time travel/replay and target latency/FPS/worker SLA where applicable. |
| Named test IDs | TC-ACC-POC-001, TC-ACC-SCORING-001 |

## 7. Observability

| Signal | Required values |
|---|---|
| Metrics | fts_witness_gate_pass_total |
| Logs | JSON log with correlation_id, actor, feature_id, source_hash, rule_version where applicable. |
| Traces | Span names follow `fts.acceptance-governance.<operation>`. |
| Alerts | Alert on fail-open, unclassified export, queue stall, hash mismatch, missing evidence. |

## 8. Migration / rollout / rollback

- Migration must be additive-first unless approved otherwise.
- Append-only audit, sealed scenario, report export and evidence stores must not have application UPDATE/DELETE path.
- Rollback uses feature flag or forward-fix; sealed/finalized records require correction/supersede trail.
- Any unresolved data, license, rule or security uncertainty must be recorded in `SPEC-GAPS.md` or `RUNTIME-GAPS.md`.

## 9. Evidence links

| Evidence | Required path pattern |
|---|---|
| Feature mini-spec | `docs/40-mini-spec-library/M-15-procurement-poc-contract-controls.md` |
| Traceability | `features/M-15/TRACEABILITY.md` |
| Test matrix | `features/M-15/TEST-MATRIX.md` |
| Security evidence | `features/M-15/SECURITY-EVIDENCE.md` |
| Runtime evidence | sealed-scenario-manifest.yaml, scoring-rubric.yaml, signoff-minutes.md |
