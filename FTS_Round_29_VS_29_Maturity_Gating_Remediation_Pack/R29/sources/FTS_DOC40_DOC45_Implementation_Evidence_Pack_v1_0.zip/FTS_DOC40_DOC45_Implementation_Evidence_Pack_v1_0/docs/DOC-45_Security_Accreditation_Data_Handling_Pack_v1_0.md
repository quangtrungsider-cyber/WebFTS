# DOC-45 — Security Accreditation & Data Handling Pack

## 1. Rà soát và đề xuất

DOC-45 được đề xuất để chốt security accreditation và data handling trước khi dùng dữ liệu nhạy cảm/operational trong PoC, FAT, SAT hoặc UAT. Nguồn FTS đã có yêu cầu L1-L4, masking/obfuscation, RBAC/ABAC, immutable audit, SIEM, support access và retention; DOC-45 biến các yêu cầu này thành control matrix, data classification matrix, export/support policy, threat model, PIA/DPIA template và accreditation ledger.

Trạng thái tài liệu: **GENERATED_DRAFT_PENDING_VATM_REVIEW_AND_SIGNOFF**.

## 2. Security controls

| Control ID | Area | Requirement | Evidence |
|---|---|---|---|
| SEC-CLASS-001 | Classification | Every dataset/entity/export has L1-L4 label; missing label fails closed | classification-policy-test.json |
| SEC-ABAC-001 | Access control | RBAC/ABAC with role + clearance + purpose; negative tests for BOLA/BFLA | authz-test-report.json |
| SEC-MASK-001 | Masking | PII, ATCO ID, military/VIP callsign and restricted areas masked/obfuscated before export/support | masked-export-proof.json |
| SEC-AUDIT-001 | Audit | Hash-chained immutable audit for export, support, rule change, deployment and sign-off | audit-chain-verification.json |
| SEC-SIEM-001 | SIEM | Forward audit/security events; spool on outage; no event loss | siem-spool-test.json |
| SEC-EXPORT-001 | Export | Export requires reason code, classification decision, watermark, TTL and audit | export-approval-record.json |
| SEC-SUPPORT-001 | Vendor support | Support access time-bounded, recorded, masked dataset only unless exception approved | support-case-audit.json |
| SEC-RET-001 | Retention | Hot/warm/cold retention, legal hold, deletion certificate where allowed | retention-ledger.json |
| SEC-SDLC-001 | Secure SDLC | SAST/DAST/SCA/secret scan/container scan; Critical/High unresolved blocks release | security-scan-report.json |
| SEC-ACCRED-001 | Accreditation | Accreditation package has risk register, threat model, PIA/DPIA, evidence and sign-off | security-accreditation-ledger.yaml |

## 3. Required artifacts

| Artifact | Path |
|---|---|
| Security control matrix | `security/security-control-matrix.yaml` |
| Data classification matrix | `security/data-classification-matrix.yaml` |
| Export approval policy | `security/export-approval-policy.yaml` |
| Vendor support exception policy | `security/vendor-support-exception-policy.yaml` |
| Masking/de-identification rules | `security/masking-deidentification-rules.yaml` |
| Audit event schema | `security/audit-event.schema.json` |
| Accreditation ledger | `security/security-accreditation-ledger.yaml` |
| Threat model | `security/threat-model.md` |
| PIA/DPIA template | `security/pia-dpia-template.md` |
| Data handling policy | `security/data-handling-policy.md` |

## 4. Accreditation gates

| Gate | Required before pass |
|---|---|
| Dev synthetic | Basic auth, classification labels, no secret in repo. |
| PoC synthetic/masked | Export/masking/audit evidence, security scan, support bundle policy. |
| FAT | SAST/DAST/SCA/container scan, RBAC/ABAC negative tests, SBOM/signature evidence. |
| SAT | On-prem/air-gap security, SIEM forwarding/spool, backup/restore, support access control. |
| UAT restricted data | Data owner approval, PIA/DPIA, retention/legal hold, exception ledger if any. |

## 5. Validation commands

```bash
make docs45-validate
make security-control-matrix-check
make classification-policy-test
make masked-export-test
make audit-chain-verify
make security-accreditation-pack
```

## 6. Pass criteria

| Check | Pass condition |
|---|---|
| Classification | Missing classification fails closed. |
| Export | L3/L4 raw export is denied unless approved exception exists. |
| Audit | Export/support/rule-change/deployment audit chain verifies. |
| Accreditation | Scope-specific accreditation package has evidence and sign-off ledger. |
| Support | Vendor support is time-bounded, masked and audited unless exception approved. |
