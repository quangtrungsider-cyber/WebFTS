import { test, expect } from '@playwright/test';
test('replay viewer can load timeline shell', async ({ page }) => {
  await page.goto('/replay/example');
  await expect(page.getByText('Timeline')).toBeVisible();
});
