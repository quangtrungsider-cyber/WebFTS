import { test, expect } from '@playwright/test';
test('run progress page shows non-operational watermark', async ({ page }) => {
  await page.goto('/runs/example');
  await expect(page.getByText('NON-OPERATIONAL')).toBeVisible();
});
