import { test, expect } from '@playwright/test';
test('report export requires reason code', async ({ page }) => {
  await page.goto('/reports/example');
  await expect(page.getByLabel('Reason code')).toBeVisible();
});
