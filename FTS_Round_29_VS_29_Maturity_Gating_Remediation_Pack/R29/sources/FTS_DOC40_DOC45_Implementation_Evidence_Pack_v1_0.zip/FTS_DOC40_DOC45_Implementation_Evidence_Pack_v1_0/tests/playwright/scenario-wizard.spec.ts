import { test, expect } from '@playwright/test';
test('scenario wizard shows validation and freeze controls', async ({ page }) => {
  await page.goto('/scenarios/new');
  await expect(page.getByText('Scenario')).toBeVisible();
});
