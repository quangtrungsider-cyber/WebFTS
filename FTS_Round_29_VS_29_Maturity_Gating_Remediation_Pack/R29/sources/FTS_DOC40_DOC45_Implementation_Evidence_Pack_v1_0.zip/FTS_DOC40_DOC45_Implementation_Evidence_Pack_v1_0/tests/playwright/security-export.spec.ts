import { test, expect } from '@playwright/test';
test('classification badge visible before export', async ({ page }) => {
  await page.goto('/exports/new');
  await expect(page.getByText('Classification')).toBeVisible();
});
