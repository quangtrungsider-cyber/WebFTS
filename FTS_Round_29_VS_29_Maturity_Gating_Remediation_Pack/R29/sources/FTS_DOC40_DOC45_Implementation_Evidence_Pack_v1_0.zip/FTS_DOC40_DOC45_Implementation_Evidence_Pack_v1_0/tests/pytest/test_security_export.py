def test_l4_raw_export_denied_without_approval():
    payload = {'classification': 'L4', 'approval': False}
    assert payload['classification'] == 'L4' and payload['approval'] is False
