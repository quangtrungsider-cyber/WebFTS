def test_kpi_vector_has_ci95_flag():
    expected = {'ci95_required': True}
    assert expected['ci95_required'] is True
