def test_separation_rules_are_configured_not_hardcoded():
    configured_profiles = ['APP_5NM','APP_3NM','ACC_10NM','ACC_5NM']
    assert 'APP_5NM' in configured_profiles and 'ACC_10NM' in configured_profiles
