def test_invalid_airac_expected_error():
    # Wire to scenario-service when implemented.
    assert 'ERR-SCEN-AIRAC'.startswith('ERR-SCEN')
