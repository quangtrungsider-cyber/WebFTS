import hashlib
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[2]

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(65536), b''):
            h.update(chunk)
    return h.hexdigest()

def test_dataset_manifest_hashes():
    manifest = yaml.safe_load((ROOT / 'fixtures' / 'dataset-manifest.yaml').read_text(encoding='utf-8'))
    for fixture in manifest['fixtures']:
        for key, rel in fixture['files'].items():
            expected = fixture['hashes'][key]
            assert sha256_file(ROOT / rel) == expected
