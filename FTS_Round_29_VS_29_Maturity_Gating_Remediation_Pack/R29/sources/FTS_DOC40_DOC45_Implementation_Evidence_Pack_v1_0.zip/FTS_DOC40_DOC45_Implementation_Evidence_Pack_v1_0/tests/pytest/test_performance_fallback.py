def test_performance_fallback_requires_limitation():
    fallback_event = {'fallback_used': True, 'limitation_recorded': True}
    assert fallback_event['fallback_used'] and fallback_event['limitation_recorded']
