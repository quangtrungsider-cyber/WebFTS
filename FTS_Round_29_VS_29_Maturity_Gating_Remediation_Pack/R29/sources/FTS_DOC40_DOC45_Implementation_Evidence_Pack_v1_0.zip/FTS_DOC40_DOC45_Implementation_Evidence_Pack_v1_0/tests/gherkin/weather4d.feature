Feature: Weather4D interpolation
  Scenario: Known point interpolation
    Given fixture weather grid with known point
    When flight weather profile is sampled
    Then the output matches the expected epsilon oracle
