Feature: Masked export
  Scenario: Deny raw L4 export
    Given dirty fixture "l4-export-attempt"
    When a user without L4 approval requests export
    Then export is denied
    And audit event export.denied is recorded
