Feature: Sealed PoC witness
  Scenario: Run sealed scenario with dynamic salt
    Given sealed fixture "FTS-GOLDEN-007-SEALED-POC"
    And witness dynamic salt is applied
    When the scenario is run
    Then sealed manifest hashes are verified
    And score is computed using scoring-rubric.yaml
