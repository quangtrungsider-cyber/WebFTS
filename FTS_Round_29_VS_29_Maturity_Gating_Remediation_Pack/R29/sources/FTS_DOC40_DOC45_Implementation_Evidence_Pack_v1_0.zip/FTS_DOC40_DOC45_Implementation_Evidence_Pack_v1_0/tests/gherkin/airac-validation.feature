Feature: AIRAC effective date validation
  Scenario: Reject scenario outside active AIRAC period
    Given dirty fixture "invalid-airac"
    When scenario validation runs
    Then validation fails with ERR-SCEN-AIRAC
