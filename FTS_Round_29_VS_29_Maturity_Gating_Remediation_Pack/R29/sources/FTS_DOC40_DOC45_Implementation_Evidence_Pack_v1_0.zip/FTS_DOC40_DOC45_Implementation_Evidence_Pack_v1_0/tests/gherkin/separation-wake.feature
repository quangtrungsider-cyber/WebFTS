Feature: Separation and wake rules
  Scenario: Different profile changes conflict outcome
    Given a frozen scenario with APP_5NM and APP_3NM profiles
    When both runs complete with the same seed
    Then conflict logs use the declared rule profile
    And capacity/conflict deltas are non-identical or documented as limitation
