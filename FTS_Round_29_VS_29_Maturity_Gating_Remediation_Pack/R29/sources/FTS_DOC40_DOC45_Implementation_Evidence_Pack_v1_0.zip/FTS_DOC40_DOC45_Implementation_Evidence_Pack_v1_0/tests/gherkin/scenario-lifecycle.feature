Feature: Scenario lifecycle
  Scenario: Freeze valid scenario with manifest hash
    Given a synthetic fixture "FTS-GOLDEN-001-PEAK-DAY"
    When the scenario is validated and frozen
    Then the scenario manifest hash is recorded
    And further edits are rejected with ERR-SCEN-FROZEN
