# FPL 22/02/2026 Vietnam Baseline Scenario Pack

## Scope

This pack creates a near-realistic baseline simulation scenario for WebFTS/BlueSky from the uploaded FPL message workbook `msg22022026(1).xlsx`.

Coverage:

- FIR Ha Noi / VVHN
- FIR Ho Chi Minh / VVHM
- Vietnam domestic flights
- International arrivals/departures involving Vietnam airports
- Overflights through VVHN/VVHM where identifiable from FPL/EET/route data

**Decision-support / Non-operational.**

## Main outputs

```text
WebATM/static/data/traffic/scenario/fpl_20260222_vietnam_baseline.scn
WebATM/static/data/traffic/scenario/fpl_20260222_vietnam_baseline_latlon_compatible.scn
WebATM/static/data/traffic/normalized/fpl_20260222_normalized.csv
WebATM/static/data/traffic/reports/fpl_20260222_manifest.csv
WebATM/static/data/traffic/reports/fpl_20260222_quality_report.csv
WebATM/static/data/traffic/reports/fpl_20260222_missing_waypoints_or_procedures.csv
```

## Summary

```text
Parsed FPL messages: 7615
Unique FPL records all DOF: 2991
Unique FPL records with DOF/260222: 2213
Vietnam-related flights retained: 2162
Flights emitted to scenario: 2077
Flights requiring review / missing initial coordinate: 85
```

Flight type counts:

```text
{'domestic': 712, 'overflight': 817, 'international_departure': 309, 'international_arrival': 324}
```

Related FIR counts:

```text
{'VVHM': 1670, 'VVHN': 371, 'VVHM+VVHN': 121}
```

## How to install into WebFTS

From the extracted pack root, copy into the WebFTS project root:

```bash
cp -r WebATM/static/data/traffic "/d/Coding/Dự án FTS/WebFTS v1/WebATM/static/data/"
```

Then load this scenario in WebFTS/BlueSky:

```text
WebATM/static/data/traffic/scenario/fpl_20260222_vietnam_baseline.scn
```

If waypoint names are not available in the BlueSky nav database, try the coordinate-oriented variant:

```text
WebATM/static/data/traffic/scenario/fpl_20260222_vietnam_baseline_latlon_compatible.scn
```

## Procedure selection logic

For each flight:

- DEP at a Vietnam airport: attempt to select a matching SID/PBN nominal track.
- ARR at a Vietnam airport: attempt to select a matching STAR/PBN nominal track.
- ARR at a Vietnam airport: attempt to select an IAP/RNAV/RNP/ILS nominal track where available.
- Protection areas are not used.
- If no SID/STAR/IAP match is found, the flight is kept and flagged in the review report.

## Review files

Use:

```text
fpl_20260222_quality_report.csv
fpl_20260222_missing_waypoints_or_procedures.csv
```

to review missing waypoints, missing procedures and flights not emitted to `.scn`.
