/**
 * VATM Vietnam Airspace/ATS Overlay Controls for WebATM / MapLibre
 *
 * Adds toggle buttons for:
 * - Đường bay VN: ATS/RNAV routes from ENR 3.1 + ENR 3.3
 * - FIR/ACC: VVHN/VVHM FIR boundaries and ACC sector boundaries
 * - TMA/APP: TMA, APP, TSN Point Merge sectors
 *
 * Decision-support / Non-operational.
 */
import type maplibregl from "maplibre-gl";

type LayerSpec = { id: string; type: "line" | "fill" | "circle" | "symbol" };

type GroupSpec = {
  key: string;
  label: string;
  active: boolean;
  sources: Array<{ id: string; data: string }>;
  layers: LayerSpec[];
};

const GROUPS: GroupSpec[] = [
  {
    key: "routes",
    label: "🛫 Đường bay VN",
    active: false,
    sources: [
      { id: "vatm-ats-routes", data: "/static/data/vietnam_ats_routes.geojson" },
      { id: "vatm-ats-waypoints", data: "/static/data/vietnam_ats_waypoints.geojson" },
    ],
    layers: [
      { id: "vatm-ats-routes-line", type: "line" },
      { id: "vatm-ats-routes-label", type: "symbol" },
      { id: "vatm-ats-waypoints-dot", type: "circle" },
      { id: "vatm-ats-waypoints-label", type: "symbol" },
    ],
  },
  {
    key: "fir-acc",
    label: "🛰 FIR/ACC",
    active: false,
    sources: [
      { id: "vatm-fir-boundaries", data: "/static/data/vietnam_fir_boundaries.geojson" },
      { id: "vatm-acc-sectors", data: "/static/data/vietnam_acc_sector_boundaries.geojson" },
      { id: "vatm-control-points", data: "/static/data/vietnam_control_points.geojson" },
    ],
    layers: [
      { id: "vatm-fir-fill", type: "fill" },
      { id: "vatm-fir-outline", type: "line" },
      { id: "vatm-fir-label", type: "symbol" },
      { id: "vatm-acc-sector-fill", type: "fill" },
      { id: "vatm-acc-sector-line", type: "line" },
      { id: "vatm-acc-sector-label", type: "symbol" },
      { id: "vatm-control-points-dot", type: "circle" },
      { id: "vatm-control-points-label", type: "symbol" },
    ],
  },
  {
    key: "tma-app",
    label: "🎯 TMA/APP",
    active: false,
    sources: [
      { id: "vatm-tma-app", data: "/static/data/vietnam_tma_app_control_areas.geojson" },
    ],
    layers: [
      { id: "vatm-tma-app-fill", type: "fill" },
      { id: "vatm-tma-app-line", type: "line" },
      { id: "vatm-tma-app-label", type: "symbol" },
    ],
  },
];

export function installVietnamAirspaceOverlayControls(map: maplibregl.Map): void {
  map.on("load", () => {
    addSourcesAndLayers(map);
    createToolbar(map);
    GROUPS.forEach((group) => setGroupVisibility(map, group, group.active));
  });
}

function addSourcesAndLayers(map: maplibregl.Map): void {
  GROUPS.flatMap((g) => g.sources).forEach((src) => {
    if (!map.getSource(src.id)) {
      map.addSource(src.id, { type: "geojson", data: src.data });
    }
  });

  // ATS routes
  addLayer(map, {
    id: "vatm-ats-routes-line",
    type: "line",
    source: "vatm-ats-routes",
    paint: { "line-color": "#22d3ee", "line-width": 1.8, "line-opacity": 0.75 },
  });
  addLayer(map, {
    id: "vatm-ats-routes-label",
    type: "symbol",
    source: "vatm-ats-routes",
    layout: { "symbol-placement": "line", "text-field": ["get", "route_id"], "text-size": 11, "text-allow-overlap": false },
    paint: { "text-color": "#e0f2fe", "text-halo-color": "#020617", "text-halo-width": 1.4 },
  });
  addLayer(map, {
    id: "vatm-ats-waypoints-dot",
    type: "circle",
    source: "vatm-ats-waypoints",
    paint: { "circle-radius": 3, "circle-color": "#facc15", "circle-stroke-color": "#111827", "circle-stroke-width": 1 },
  });
  addLayer(map, {
    id: "vatm-ats-waypoints-label",
    type: "symbol",
    source: "vatm-ats-waypoints",
    layout: { "text-field": ["get", "name"], "text-size": 10, "text-offset": [0, 1.1], "text-allow-overlap": false },
    paint: { "text-color": "#fef9c3", "text-halo-color": "#020617", "text-halo-width": 1.4 },
  });

  // FIR / ACC sectors
  addLayer(map, {
    id: "vatm-fir-fill",
    type: "fill",
    source: "vatm-fir-boundaries",
    paint: { "fill-color": ["match", ["get", "name"], "HA NOI FIR (VVHN)", "#38bdf8", "HO CHI MINH FIR (VVHM)", "#34d399", "#64748b"], "fill-opacity": 0.08 },
  });
  addLayer(map, {
    id: "vatm-fir-outline",
    type: "line",
    source: "vatm-fir-boundaries",
    paint: { "line-color": "#e0f2fe", "line-width": 2.2, "line-dasharray": [3, 2], "line-opacity": 0.95 },
  });
  addLayer(map, {
    id: "vatm-fir-label",
    type: "symbol",
    source: "vatm-fir-boundaries",
    layout: { "text-field": ["get", "name"], "text-size": 13, "text-allow-overlap": false },
    paint: { "text-color": "#e0f2fe", "text-halo-color": "#020617", "text-halo-width": 1.8 },
  });
  addLayer(map, {
    id: "vatm-acc-sector-fill",
    type: "fill",
    source: "vatm-acc-sectors",
    filter: ["==", ["geometry-type"], "Polygon"],
    paint: { "fill-color": "#a78bfa", "fill-opacity": 0.07 },
  });
  addLayer(map, {
    id: "vatm-acc-sector-line",
    type: "line",
    source: "vatm-acc-sectors",
    paint: { "line-color": "#a78bfa", "line-width": 1.5, "line-dasharray": [2, 2], "line-opacity": 0.8 },
  });
  addLayer(map, {
    id: "vatm-acc-sector-label",
    type: "symbol",
    source: "vatm-acc-sectors",
    layout: { "text-field": ["get", "name"], "text-size": 10, "text-allow-overlap": false },
    paint: { "text-color": "#ddd6fe", "text-halo-color": "#020617", "text-halo-width": 1.5 },
  });
  addLayer(map, {
    id: "vatm-control-points-dot",
    type: "circle",
    source: "vatm-control-points",
    paint: { "circle-radius": 2.5, "circle-color": "#f97316", "circle-stroke-color": "#020617", "circle-stroke-width": 1 },
  });
  addLayer(map, {
    id: "vatm-control-points-label",
    type: "symbol",
    source: "vatm-control-points",
    layout: { "text-field": ["get", "name"], "text-size": 9, "text-offset": [0, 1], "text-allow-overlap": false },
    paint: { "text-color": "#fed7aa", "text-halo-color": "#020617", "text-halo-width": 1.5 },
  });

  // TMA/APP
  addLayer(map, {
    id: "vatm-tma-app-fill",
    type: "fill",
    source: "vatm-tma-app",
    paint: { "fill-color": "#22c55e", "fill-opacity": 0.08 },
  });
  addLayer(map, {
    id: "vatm-tma-app-line",
    type: "line",
    source: "vatm-tma-app",
    paint: { "line-color": "#22c55e", "line-width": 1.8, "line-opacity": 0.9 },
  });
  addLayer(map, {
    id: "vatm-tma-app-label",
    type: "symbol",
    source: "vatm-tma-app",
    layout: { "text-field": ["get", "name"], "text-size": 11, "text-allow-overlap": false },
    paint: { "text-color": "#bbf7d0", "text-halo-color": "#020617", "text-halo-width": 1.5 },
  });
}

function addLayer(map: maplibregl.Map, layer: any): void {
  if (!map.getLayer(layer.id)) map.addLayer(layer);
}

function createToolbar(map: maplibregl.Map): void {
  const container = map.getContainer();
  if (container.querySelector(".vatm-airspace-toolbar")) return;

  const toolbar = document.createElement("div");
  toolbar.className = "vatm-airspace-toolbar";
  toolbar.style.cssText = `
    position: absolute;
    top: 14px;
    left: 56px;
    z-index: 20;
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    max-width: 540px;
    pointer-events: auto;
  `;

  GROUPS.forEach((group) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.dataset.group = group.key;
    btn.textContent = group.label;
    btn.style.cssText = buttonCss(group.active);
    btn.onclick = () => {
      group.active = !group.active;
      setGroupVisibility(map, group, group.active);
      btn.style.cssText = buttonCss(group.active);
    };
    toolbar.appendChild(btn);
  });

  container.appendChild(toolbar);
}

function buttonCss(active: boolean): string {
  return `
    padding: 8px 12px;
    border-radius: 999px;
    border: 1px solid ${active ? "rgba(34, 211, 238, 0.85)" : "rgba(148, 163, 184, 0.35)"};
    background: ${active ? "linear-gradient(135deg, rgba(20,184,166,.95), rgba(14,165,233,.95))" : "rgba(15, 23, 42, 0.82)"};
    color: ${active ? "#ffffff" : "#dbeafe"};
    font-size: 12px;
    font-weight: 700;
    letter-spacing: .02em;
    box-shadow: 0 10px 24px rgba(2, 6, 23, .32);
    backdrop-filter: blur(10px);
    cursor: pointer;
  `;
}

function setGroupVisibility(map: maplibregl.Map, group: GroupSpec, visible: boolean): void {
  group.layers.forEach((layer) => {
    if (map.getLayer(layer.id)) {
      map.setLayoutProperty(layer.id, "visibility", visible ? "visible" : "none");
    }
  });
}
