# VATM Vietnam ATS/FIR/ACC/TMA overlays for WebATM

Gói này giúp vẽ lên bản đồ WebATM/MapLibre:

1. Đường hàng không Việt Nam từ ENR 3.1 và ENR 3.3.
2. FIR Hà Nội (VVHN) và FIR Hồ Chí Minh (VVHM).
3. Ranh giới phân khu ACC Hà Nội / ACC Hồ Chí Minh theo dữ liệu ENR 2.1, dùng dạng đơn giản hóa để phục vụ hiển thị.
4. Một số vùng TMA/APP/TWR quan trọng: Tân Sơn Nhất, Nội Bài, Đà Nẵng, Cam Ranh.
5. TSN Point Merge System theo RWY 25L/R và 07L/R.

## File dữ liệu

Copy các file sau vào `WebATM/static/data/`:

```bash
mkdir -p WebATM/static/data
cp vietnam_ats_routes.geojson WebATM/static/data/
cp vietnam_ats_waypoints.geojson WebATM/static/data/
cp vietnam_fir_boundaries.geojson WebATM/static/data/
cp vietnam_acc_sector_boundaries.geojson WebATM/static/data/
cp vietnam_tma_app_control_areas.geojson WebATM/static/data/
cp vietnam_control_points.geojson WebATM/static/data/
```

## File code

Copy file TypeScript vào thư mục map của frontend:

```bash
cp VietnamAirspaceOverlayControls.ts frontend/src/ui/map/
```

Mở `frontend/src/ui/map/MapDisplay.ts`, thêm import:

```ts
import { installVietnamAirspaceOverlayControls } from "./VietnamAirspaceOverlayControls";
```

Sau khi tạo `this.map`, gọi:

```ts
installVietnamAirspaceOverlayControls(this.map);
```

Nếu trong dự án đã có `map.on("load", ...)`, vẫn có thể gọi hàm trên ngay sau khi `this.map = new maplibregl.Map(...)`. Hàm tự đăng ký `load` event.

## Build lại

```bash
cd frontend
npm run build
cd ..
python WebATM.py
```

Mở `http://localhost:8082`.

Trên bản đồ sẽ có 3 nút:

- 🛫 Đường bay VN
- 🛰 FIR/ACC
- 🎯 TMA/APP

## Lưu ý dữ liệu

- Đây là lớp hiển thị bản đồ để phục vụ PoC / FTS / decision-support, không dùng làm dữ liệu điều hành bay trực tiếp.
- Các đoạn biên giới quốc gia/FIR được đơn giản hóa bằng đoạn thẳng khi PDF mô tả "along boundary" mà không liệt kê toàn bộ vertex.
- Với bài toán chính thức, nên thay bằng AIXM/eAIP source hoặc shapefile/geojson đã được VATM/AIM xác nhận.

Decision-support / Non-operational.
